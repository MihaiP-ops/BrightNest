import axios from 'axios';
import { config, logger } from '../config/environment';

const API_URL = config.apiUrl;

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests if available
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Add response interceptor for error handling and logging
api.interceptors.response.use(
  (response) => {
    logger.debug('API Response:', response.config.url, response.status);
    return response;
  },
  (error) => {
    logger.error('API Error:', error.config?.url, error.response?.status, error.message);
    
    // Handle token expiration
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      // Only redirect if not already on login page
      if (!window.location.pathname.includes('/signin')) {
        window.location.href = '/signin';
      }
    }
    
    return Promise.reject(error);
  }
);

// Auth API
export const auth = {
  register: async (data: { email: string; password: string; full_name: string }) => {
    const response = await api.post('/auth/register', data);
    return response.data;
  },

  login: async (data: { username: string; password: string }) => {
    const formData = new URLSearchParams();
    formData.append('username', data.username);
    formData.append('password', data.password);
    
    const response = await axios.post(`${API_URL}/auth/login`, formData, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });
    return response.data;
  },

  getProfile: async () => {
    const response = await api.get('/auth/me');
    return response.data;
  },
};

// Children API
export const children = {
  create: async (data: { name: string; age: number; photo_url?: string }) => {
    const response = await api.post('/children', data);
    return response.data;
  },

  getAll: async () => {
    const response = await api.get('/children');
    return response.data;
  },

  getOne: async (id: number) => {
    const response = await api.get(`/children/${id}`);
    return response.data;
  },

  update: async (id: number, data: { name: string; age: number; photo_url?: string }) => {
    const response = await api.put(`/children/${id}`, data);
    return response.data;
  },

  delete: async (id: number) => {
    await api.delete(`/children/${id}`);
  },
};

// Habits API
export const habits = {
  create: async (data: { name: string; description?: string; total_days: number; child_id: number }) => {
    const response = await api.post('/habits', data);
    return response.data;
  },

  getChildHabits: async (childId: number) => {
    const response = await api.get(`/habits/child/${childId}`);
    return response.data;
  },

  getChildHabitsWithCompletions: async (childId: number) => {
    const response = await api.get(`/habits/child/${childId}/with-completions`);
    return response.data;
  },

  complete: async (habitId: number, completionDate?: string) => {
    const params = completionDate ? `?completion_date=${completionDate}` : '';
    const response = await api.post(`/habits/${habitId}/complete${params}`);
    return response.data;
  },

  getProgress: async (habitId: number, days: number = 7) => {
    const response = await api.get(`/habits/${habitId}/progress?days=${days}`);
    return response.data;
  },

  update: async (habitId: number, data: { name: string; description?: string; total_days: number }) => {
    const response = await api.put(`/habits/${habitId}`, data);
    return response.data;
  },

  delete: async (habitId: number) => {
    await api.delete(`/habits/${habitId}`);
  },
};

// Check-ins API
export const checkIns = {
  create: async (data: { child_id: number; emotion_rating: number; notes?: string }) => {
    const response = await api.post('/checkins', data);
    return response.data;
  },

  getChildCheckIns: async (childId: number, days: number = 7) => {
    const response = await api.get(`/checkins/child/${childId}?days=${days}`);
    return response.data;
  },

  getChildCheckInsWithTips: async (childId: number, days: number = 7) => {
    const response = await api.get(`/checkins/child/${childId}/with-tips?days=${days}`);
    return response.data;
  },

  getSummary: async (childId: number, days: number = 7) => {
    const response = await api.get(`/checkins/child/${childId}/summary?days=${days}`);
    return response.data;
  },
};

// Feedback API
export const feedback = {
  submit: async (data: { content: string; rating?: number }) => {
    const response = await api.post('/feedback', data);
    return response.data;
  },

  getMyFeedback: async () => {
    const response = await api.get('/feedback/my');
    return response.data;
  },
};

// AI Insights API
export const aiInsights = {
  getTip: async (childId: number, emotionRating: number, notes: string = '') => {
    // Add cache-busting parameter to ensure fresh responses
    const timestamp = Date.now();
    // Add notes for AI personalization if provided
    const params = notes && notes.length > 15 
      ? `?notes=${encodeURIComponent(notes)}&t=${timestamp}` 
      : `?t=${timestamp}`;
    const response = await api.get(`/ai-insights/tip/${childId}/${emotionRating}${params}`);
    return response.data;
  },

  getHabitSuggestion: async (childId: number, emotionRating: number, notes: string = '') => {
    const timestamp = Date.now();
    // Limit notes length to avoid URL issues and only include first 200 chars
    const truncatedNotes = notes.length > 200 ? notes.substring(0, 200) : notes;
    const params = truncatedNotes ? `?notes=${encodeURIComponent(truncatedNotes)}&t=${timestamp}` : `?t=${timestamp}`;
    const response = await api.get(`/ai-insights/habit-suggestion/${childId}/${emotionRating}${params}`);
    return response.data;
  },

  createTip: async (data: { age_group: string; emotion_rating: number; tip_text: string; tip_category?: string }) => {
    const response = await api.post('/ai-insights/tips', data);
    return response.data;
  },

  createHabitSuggestion: async (data: { age_group: string; emotion_rating: number; habit_name: string; habit_description?: string; keywords?: string }) => {
    const response = await api.post('/ai-insights/habit-suggestions', data);
    return response.data;
  },

  listTips: async (ageGroup?: string, emotionRating?: number) => {
    const params = new URLSearchParams();
    if (ageGroup) params.append('age_group', ageGroup);
    if (emotionRating) params.append('emotion_rating', emotionRating.toString());
    const queryString = params.toString() ? `?${params.toString()}` : '';
    const response = await api.get(`/ai-insights/tips${queryString}`);
    return response.data;
  },
};

// Reports API
export const reports = {
  getChildProgress: async (childId: number, period: 'week' | 'month' | 'quarter' = 'week') => {
    const response = await api.get(`/reports/child/${childId}/progress?period=${period}`);
    return response.data;
  },

  downloadChildProgressPDF: async (childId: number, period: 'week' | 'month' | 'quarter' = 'week') => {
    const response = await api.get(`/reports/child/${childId}/progress/pdf?period=${period}`, {
      responseType: 'blob',
    });
    
    // Create blob link to download
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    
    // Extract filename from response headers or create default
    const contentDisposition = response.headers['content-disposition'];
    let filename = `progress_report_${period}.pdf`;
    if (contentDisposition) {
      const filenameMatch = contentDisposition.match(/filename="(.+)"/);
      if (filenameMatch) {
        filename = filenameMatch[1];
      }
    }
    
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  },

  getChildSummary: async (childId: number, days: number = 30) => {
    const response = await api.get(`/reports/child/${childId}/summary?days=${days}`);
    return response.data;
  },
};

// Resources API
export const resources = {
  getCategories: async () => {
    const response = await api.get('/resources/categories/');
    return response.data;
  },

  getResources: async (params: {
    category_id?: number;
    resource_type?: string;
    min_age?: number;
    max_age?: number;
    tags?: string;
    is_featured?: boolean;
    search?: string;
    limit?: number;
    offset?: number;
  } = {}) => {
    const queryParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        queryParams.append(key, value.toString());
      }
    });
    const queryString = queryParams.toString();
    const response = await api.get(`/resources/${queryString ? '?' + queryString : ''}`);
    return response.data;
  },

  getResource: async (resourceId: number) => {
    const response = await api.get(`/resources/${resourceId}`);
    return response.data;
  },

  getRecommendations: async (childId: number, limit: number = 5) => {
    const response = await api.get(`/resources/recommendations/${childId}?limit=${limit}`);
    return response.data;
  },

  updateRecommendationFeedback: async (recommendationId: number, isHelpful: boolean) => {
    const response = await api.post(`/resources/recommendations/${recommendationId}/feedback`, {
      is_helpful: isHelpful
    });
    return response.data;
  },

  toggleBookmark: async (recommendationId: number) => {
    const response = await api.post(`/resources/recommendations/${recommendationId}/bookmark`);
    return response.data;
  },
};

export default api; 