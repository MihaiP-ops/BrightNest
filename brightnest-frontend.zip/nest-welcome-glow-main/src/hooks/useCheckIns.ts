
import { useState, useEffect } from 'react';
import { checkIns as checkInsApi } from '@/lib/api';

// Type definitions matching backend schema
type CheckIn = {
  id: number;
  child_id: number;
  emotion_rating: number;
  notes: string | null;
  created_at: string;
};

type CheckInInsert = {
  child_id: number;
  emotion_rating: number;
  notes?: string;
};

export const useCheckIns = (childId?: string) => {
  const [checkIns, setCheckIns] = useState<CheckIn[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (childId) {
      fetchCheckIns();
    }
  }, [childId]);

  const fetchCheckIns = async () => {
    if (!childId) {
      setLoading(false);
      return;
    }

    try {
      console.log("useCheckIns: Loading check-ins for child ID:", childId);
      const data = await checkInsApi.getChildCheckIns(parseInt(childId), 30);
      console.log("useCheckIns: Check-ins loaded successfully for child", childId, ":", data);
      console.log("useCheckIns: Data breakdown:", {
        totalCheckIns: data.length,
        emotions: data.map(c => ({ date: c.created_at, emotion: c.emotion_rating, notes: c.notes?.substring(0, 50) + '...' }))
      });
      setCheckIns(data);
    } catch (error) {
      console.error('Error fetching check-ins:', error);
      setCheckIns([]);
    } finally {
      setLoading(false);
    }
  };

  const addCheckIn = async (checkIn: CheckInInsert) => {
    try {
      console.log("useCheckIns: Creating check-in:", checkIn);
      const newCheckIn = await checkInsApi.create(checkIn);
      console.log("useCheckIns: Check-in created:", newCheckIn);
      
      setCheckIns(prev => [newCheckIn, ...prev]);
      return newCheckIn;
    } catch (error) {
      console.error('Error adding check-in:', error);
      throw error;
    }
  };

  return {
    checkIns,
    loading,
    addCheckIn,
    refetch: fetchCheckIns
  };
};
