
import React, { createContext, useContext, useState, useEffect } from 'react';

interface OnboardingContextType {
  isFirstTimeUser: boolean;
  setIsFirstTimeUser: (value: boolean) => void;
  skipOnboarding: () => void;
  restartOnboarding: () => void;
}

const OnboardingContext = createContext<OnboardingContextType | undefined>(undefined);

export const OnboardingProvider = ({ children }: { children: React.ReactNode }) => {
  const [isFirstTimeUser, setIsFirstTimeUser] = useState<boolean>(() => {
    // Try to get the value from localStorage
    const stored = localStorage.getItem('isFirstTimeUser');
    // If it doesn't exist in localStorage, default to true
    return stored === null ? true : stored === 'true';
  });

  // Update localStorage whenever isFirstTimeUser changes
  useEffect(() => {
    localStorage.setItem('isFirstTimeUser', isFirstTimeUser.toString());
  }, [isFirstTimeUser]);

  const skipOnboarding = () => {
    setIsFirstTimeUser(false);
  };

  const restartOnboarding = () => {
    setIsFirstTimeUser(true);
  };

  return (
    <OnboardingContext.Provider value={{ 
      isFirstTimeUser, 
      setIsFirstTimeUser, 
      skipOnboarding,
      restartOnboarding 
    }}>
      {children}
    </OnboardingContext.Provider>
  );
};

export const useOnboarding = () => {
  const context = useContext(OnboardingContext);
  if (context === undefined) {
    throw new Error('useOnboarding must be used within an OnboardingProvider');
  }
  return context;
};
