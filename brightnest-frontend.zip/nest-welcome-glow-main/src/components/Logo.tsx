
import React from "react";

export const Logo = ({ showTitle = false }) => {
  return (
    <div className="flex flex-col items-center">
      <div className="relative w-28 h-28 flex items-center justify-center mx-auto">
        {/* Using the uploaded bird in nest image */}
        <img 
          src="/lovable-uploads/e6dc01ff-b184-448d-b3ca-5fece1d2d478.png"
          alt="BrightNest Logo" 
          className="w-full h-full object-contain rounded-full"
        />
      </div>
      
      {showTitle && (
        <div className="text-[#323D52] text-2xl font-bold mt-2 mb-6">BrightNest</div>
      )}
    </div>
  );
};
