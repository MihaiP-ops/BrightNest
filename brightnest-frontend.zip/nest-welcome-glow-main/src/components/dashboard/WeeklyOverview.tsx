
import { BarChart3 } from "lucide-react";

interface WeeklyOverviewProps {
  weekData: {
    day: string;
    completed: number;
    total: number;
  }[];
}

export const WeeklyOverview = ({ weekData }: WeeklyOverviewProps) => {
  return (
    <div className="rounded-xl border border-[#E5E7EB] bg-white p-6 shadow-sm">
      <div className="flex items-center gap-2 mb-6">
        <BarChart3 className="h-6 w-6 text-[#323D52]" />
        <h2 className="text-2xl font-semibold text-[#323D52]">Weekly Overview</h2>
      </div>
      
      <div className="grid grid-cols-7 gap-4">
        {weekData.map((dayData) => {
          const completionRatio = dayData.total > 0 ? (dayData.completed / dayData.total) : 0;
          const barHeight = 180 * completionRatio;
          const isEmpty = dayData.total === 0;
          
          return (
            <div key={dayData.day} className="flex flex-col items-center">
              <div className="w-full h-48 bg-[#F3F4F6] rounded-md flex items-end justify-center">
                {!isEmpty && (
                  <div 
                    className="w-full bg-[#9b87f5] rounded-md flex items-center justify-center text-white"
                    style={{ height: `${barHeight}px` }}
                  >
                    {dayData.completed}/{dayData.total}
                  </div>
                )}
                {isEmpty && (
                  <div className="text-[#AEAEB2] text-sm mt-16">
                    0/0
                  </div>
                )}
              </div>
              <div className="mt-2 text-sm text-[#6B7280]">{dayData.day}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
