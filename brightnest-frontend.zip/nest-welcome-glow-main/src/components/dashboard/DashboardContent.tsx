import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { HabitCard } from "./HabitCard";
import { RewardCard } from "./RewardCard";
import { WeeklyOverview } from "./WeeklyOverview";
import { AnalyticsCard } from "./AnalyticsCard";
import { EmotionsTab } from "./EmotionsTab";
import { MoodHabitInsightCard } from "./MoodHabitInsightCard";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { FileText } from "lucide-react";
import { habits as habitsApi } from "@/lib/api";

interface Habit {
  id: number;
  name: string;
  progress: number;
  total: number;
  childId: string;
  completedDaysDetail?: string[];  // Add the new field
}

interface DashboardContentProps {
  childId: string;
  habits: Habit[];
}

export const DashboardContent = ({ childId, habits }: DashboardContentProps) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("habits");
  const [localHabits, setLocalHabits] = useState(habits);

  // Update local habits when the habits prop changes
  useEffect(() => {
    setLocalHabits(habits);
  }, [habits]);

  // Handle habit progress updates - refresh data from backend
  const handleHabitUpdate = async (habitId: number, newProgress: number) => {
    try {
      // Refetch the habits data to get updated completion details
      const updatedHabits = await habitsApi.getChildHabitsWithCompletions(parseInt(childId));
      
      // Transform the data to match the expected format
      const transformedHabits = updatedHabits.map((habit: any) => ({
        id: habit.id,
        name: habit.name,
        progress: habit.completed_days || 0,
        total: habit.total_days,
        childId: habit.child_id.toString(),
        completedDaysDetail: habit.completed_days_detail || []
      }));
      
      setLocalHabits(transformedHabits);
    } catch (error) {
      console.error("Failed to refresh habit data:", error);
      // Fallback to local update if API call fails
      setLocalHabits(prevHabits => 
        prevHabits.map(habit => 
          habit.id === habitId 
            ? { ...habit, progress: newProgress }
            : habit
        )
      );
    }
  };
  
  // Transform habits data to the format expected by HabitCard
  const habitCardsData = localHabits.map(habit => {
    // Use actual completed days from backend if available
    const completedDays = habit.completedDaysDetail || [];
    
    // Calculate how many times per day this habit should be done
    const timesPerDay = Math.round(habit.total / 7); // total completions per week / 7 days
    const frequencyText = timesPerDay > 1 ? `${timesPerDay} times per day` : 'once per day';
    
    return {
      id: habit.id,
      name: habit.name,
      description: `Complete this habit ${frequencyText}`,
      currentProgress: completedDays.length, // Number of days completed (0-7)
      totalDays: 7, // Always show 7 days for weekly view
      completedDays: completedDays,
      currentStreak: completedDays.length // Use actual completed days count for streak
    };
  });

  // Calculate analytics data using local habits
  const totalHabits = localHabits.length;
  const totalCompletions = localHabits.reduce((sum, habit) => sum + habit.progress, 0);
  const totalPossibleCompletions = localHabits.reduce((sum, habit) => sum + habit.total, 0);
  const completionRate = totalPossibleCompletions > 0 
    ? Math.round((totalCompletions / totalPossibleCompletions) * 100) 
    : 0;
  const bestStreak = localHabits.length > 0 
    ? Math.max(...localHabits.map(h => Math.min(h.progress, 7)))
    : 0;

  // Create week data for the overview chart  
  const weekData = [
    { day: "Sun", completed: 0, total: 0 },
    { day: "Mon", completed: 0, total: 0 },
    { day: "Tue", completed: 0, total: 0 },
    { day: "Wed", completed: 0, total: 0 },
    { day: "Thu", completed: 0, total: 0 },
    { day: "Fri", completed: 0, total: 0 },
    { day: "Sat", completed: 0, total: 0 },
  ];

  // Populate weekData using local habits
  localHabits.forEach(habit => {
    for (let i = 0; i < 7; i++) {
      weekData[i].total += 1;
      if (i < habit.progress) {
        weekData[i].completed += 1;
      }
    }
  });

  return (
    <div className="w-full max-w-4xl mx-auto">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-white/70 backdrop-blur-sm border border-[#E5E7EB]">
          <TabsTrigger 
            value="habits" 
            className="data-[state=active]:bg-[#F1F0FB] data-[state=active]:text-[#9b87f5] text-[#323D52]"
          >
            Habits
          </TabsTrigger>
          <TabsTrigger 
            value="emotions" 
            className="data-[state=active]:bg-[#F1F0FB] data-[state=active]:text-[#9b87f5] text-[#323D52]"
          >
            Emotions
          </TabsTrigger>
          <TabsTrigger 
            value="analytics" 
            className="data-[state=active]:bg-[#F1F0FB] data-[state=active]:text-[#9b87f5] text-[#323D52]"
          >
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="habits" className="mt-4 space-y-4">
          {habitCardsData.length === 0 ? (
            <Alert className="bg-[#F1F0FB]/50 border-[#7E69AB]/20">
              <AlertTitle className="text-[#323D52]">No habits added yet</AlertTitle>
              <AlertDescription className="text-[#323D52]/80">
                Click the "Add New Habit" button to start tracking habits for this child.
              </AlertDescription>
            </Alert>
          ) : (
            habitCardsData.map((habit) => (
              <HabitCard
                key={habit.id}
                id={habit.id}
                name={habit.name}
                description={habit.description}
                currentProgress={habit.currentProgress}
                totalDays={habit.totalDays}
                completedDays={habit.completedDays}
                currentStreak={habit.currentStreak}
                onHabitUpdate={handleHabitUpdate}
              />
            ))
          )}
          
          {habitCardsData.length > 0 && (
            <RewardCard
              progressDays={totalCompletions}
              totalDays={totalPossibleCompletions}
              reward={totalCompletions >= totalPossibleCompletions / 2 ? "New sticker" : "Keep going!"}
            />
          )}
        </TabsContent>

        <TabsContent value="emotions" className="mt-4 space-y-4">
          <MoodHabitInsightCard childId={childId} habits={localHabits} />
          <EmotionsTab childId={childId} />
        </TabsContent>

        <TabsContent value="analytics" className="mt-4 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">Analytics Overview</h3>
            <Button 
              onClick={() => navigate(`/reports/${childId}`)}
              variant="outline"
              className="flex items-center gap-2"
            >
              <FileText className="w-4 h-4" />
              View Progress Report
            </Button>
          </div>
          
          <WeeklyOverview weekData={weekData} />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <AnalyticsCard title="Total Habits" value={totalHabits} />
            <AnalyticsCard title="Completion Rate" value={`${completionRate}%`} />
            <AnalyticsCard title="Best Streak" value={bestStreak} />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};
