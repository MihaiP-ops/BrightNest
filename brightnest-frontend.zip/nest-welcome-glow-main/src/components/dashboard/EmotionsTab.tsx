
import { Lightbulb, Moon, Users, School, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from "recharts";
import { useCheckIns } from "@/hooks/useCheckIns";
import { generateAIInsight, generateMoodData, generateTriggers } from "@/utils/emotionAnalysis";
import { useState, useEffect } from "react";

interface EmotionsTabProps {
  childId: string;
}

export const EmotionsTab = ({ childId }: EmotionsTabProps) => {
  const { checkIns, loading } = useCheckIns(childId);
  const [lastUpdated, setLastUpdated] = useState<string>('');

  // Get child name from mock data - in real app this would come from child profile
  const getChildName = (id: string) => {
    const childNames: { [key: string]: string } = {
      "1": "Bella",
      "2": "Toby", 
      "3": "Emma"
    };
    return childNames[id] || "Child";
  };

  const childName = getChildName(childId);

  // Update last updated timestamp when check-ins change
  useEffect(() => {
    if (checkIns.length > 0) {
      setLastUpdated(new Date().toLocaleString());
    }
  }, [checkIns]);

  // Generate real-time data
  const aiInsight = generateAIInsight(checkIns, childName);
  const moodData = generateMoodData(checkIns);
  const triggerData = generateTriggers(checkIns);

  const chartConfig = {
    mood: {
      label: "Mood",
      color: "#5E9FA3",
    },
  };

  // Add default triggers if no data exists
  const displayTriggers = triggerData.length > 0 ? triggerData : [
    { name: "No triggers identified yet", count: 0 }
  ];

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-center py-8">
          <div className="text-[#323D52]">Loading emotions data...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* AI Insight Card */}
      <Card className="bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-200">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full bg-yellow-200 flex items-center justify-center">
              <Lightbulb className="w-6 h-6 text-yellow-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-[#323D52] mb-2">AI Insight</h3>
              <p className="text-[#323D52]/80">{aiInsight}</p>
              {lastUpdated && (
                <div className="flex items-center gap-2 mt-3 text-xs text-[#323D52]/60">
                  <Clock className="w-3 h-3" />
                  <span>Last updated: {lastUpdated}</span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Mood Over Time Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-[#323D52]">Mood Over Time</CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={moodData}>
                <XAxis 
                  dataKey="day" 
                  axisLine={false}
                  tickLine={false}
                  className="text-sm"
                />
                <YAxis 
                  domain={[1, 5]}
                  tickFormatter={(value) => {
                    const emojiMap: { [key: number]: string } = {
                      1: "😢", 2: "🙁", 3: "😐", 4: "🙂", 5: "😊"
                    };
                    return emojiMap[value] || "😐";
                  }}
                  axisLine={false}
                  tickLine={false}
                  className="text-sm"
                />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line 
                  type="monotone" 
                  dataKey="mood" 
                  stroke="#5E9FA3" 
                  strokeWidth={3}
                  dot={{ fill: "#5E9FA3", strokeWidth: 2, r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Top Triggers Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-[#323D52]">Top Emotional Triggers</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {displayTriggers.map((trigger, index) => {
              // Map trigger names to icons and colors
              const getTriggerIcon = (name: string) => {
                if (name.toLowerCase().includes('nursery') || name.toLowerCase().includes('school')) {
                  return { icon: School, color: "#F28B9A" };
                }
                if (name.toLowerCase().includes('bedtime') || name.toLowerCase().includes('sleep')) {
                  return { icon: Moon, color: "#AED9E0" };
                }
                if (name.toLowerCase().includes('sibling') || name.toLowerCase().includes('conflict')) {
                  return { icon: Users, color: "#D6C7F7" };
                }
                return { icon: Users, color: "#E0E0E0" };
              };

              const { icon: IconComponent, color } = getTriggerIcon(trigger.name);
              const maxCount = Math.max(...displayTriggers.map(t => t.count)) || 1;
              
              return (
                <div key={index} className="flex items-center gap-4">
                  <div 
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: `${color}40` }}
                  >
                    <IconComponent 
                      className="w-4 h-4" 
                      style={{ color: color }}
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm font-medium text-[#323D52]">
                        {trigger.name}
                      </span>
                      <span className="text-sm text-[#323D52]/60">
                        {trigger.count > 0 ? `${trigger.count}x` : ''}
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="h-2 rounded-full transition-all duration-300"
                        style={{ 
                          backgroundColor: color,
                          width: trigger.count > 0 ? `${(trigger.count / maxCount) * 100}%` : '0%'
                        }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
