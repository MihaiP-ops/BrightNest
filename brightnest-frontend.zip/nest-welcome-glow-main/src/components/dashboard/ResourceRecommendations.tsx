import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BookOpen, ExternalLink, Sparkles, ThumbsUp, ThumbsDown } from 'lucide-react';
import { resources } from '@/lib/api';

interface ResourceRecommendation {
  id: number;
  reason: string;
  confidence_score: number;
  resource: {
    id: number;
    title: string;
    description: string;
    resource_type: string;
    category: {
      name: string;
      color: string;
    };
    read_time_minutes?: number;
  };
}

interface ResourceRecommendationsProps {
  childId: number;
}

export const ResourceRecommendations: React.FC<ResourceRecommendationsProps> = ({ childId }) => {
  const [recommendations, setRecommendations] = useState<ResourceRecommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadRecommendations();
  }, [childId]);

  const loadRecommendations = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await resources.getRecommendations(childId, 3);
      setRecommendations(data);
    } catch (err) {
      console.error('Error loading recommendations:', err);
      setError('Unable to load recommendations at this time.');
    } finally {
      setLoading(false);
    }
  };

  const handleFeedback = async (recommendationId: number, isHelpful: boolean) => {
    try {
      await resources.updateRecommendationFeedback(recommendationId, isHelpful);
      // Update local state to reflect feedback
      setRecommendations(prev =>
        prev.map(rec =>
          rec.id === recommendationId
            ? { ...rec, userFeedback: isHelpful }
            : rec
        )
      );
    } catch (err) {
      console.error('Error submitting feedback:', err);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-blue-500" />
            Recommended Resources
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-16 bg-gray-200 rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-blue-500" />
            Recommended Resources
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <BookOpen className="h-8 w-8 text-gray-300 mx-auto mb-2" />
            <p className="text-sm text-gray-500">{error}</p>
            <Button variant="outline" size="sm" onClick={loadRecommendations} className="mt-2">
              Try Again
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (recommendations.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-blue-500" />
            Recommended Resources
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <BookOpen className="h-8 w-8 text-gray-300 mx-auto mb-2" />
            <p className="text-sm text-gray-500 mb-3">
              No personalized recommendations available yet.
            </p>
            <Link to="/resource-hub">
              <Button variant="outline" size="sm">
                Browse All Resources
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-blue-500" />
            Recommended for You
          </CardTitle>
          <Link to="/resource-hub">
            <Button variant="ghost" size="sm">
              View All <ExternalLink className="h-3 w-3 ml-1" />
            </Button>
          </Link>
        </div>
        <CardDescription>
          AI-curated resources based on your child's recent patterns
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {recommendations.map((recommendation) => (
          <div key={recommendation.id} className="border rounded-lg p-3 hover:bg-gray-50 transition-colors">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <Badge 
                    variant="secondary" 
                    className="text-xs"
                    style={{ 
                      backgroundColor: recommendation.resource.category.color + '20', 
                      color: recommendation.resource.category.color 
                    }}
                  >
                    {recommendation.resource.category.name}
                  </Badge>
                  {recommendation.resource.read_time_minutes && (
                    <span className="text-xs text-gray-500">
                      {recommendation.resource.read_time_minutes} min
                    </span>
                  )}
                </div>
                <h4 className="font-medium text-sm leading-tight mb-1">
                  {recommendation.resource.title}
                </h4>
                <p className="text-xs text-gray-600 mb-2">
                  {recommendation.resource.description.length > 100
                    ? recommendation.resource.description.substring(0, 100) + '...'
                    : recommendation.resource.description}
                </p>
                <p className="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded">
                  💡 {recommendation.reason}
                </p>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">Was this helpful?</span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 px-2"
                  onClick={() => handleFeedback(recommendation.id, true)}
                >
                  <ThumbsUp className="h-3 w-3" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 px-2"
                  onClick={() => handleFeedback(recommendation.id, false)}
                >
                  <ThumbsDown className="h-3 w-3" />
                </Button>
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link to={`/resource-hub?resource=${recommendation.resource.id}`}>
                  Read More
                </Link>
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}; 