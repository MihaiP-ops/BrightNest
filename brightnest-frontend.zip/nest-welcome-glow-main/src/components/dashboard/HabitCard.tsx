
import { Star, Check } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useState, useEffect } from "react";
import { habits as habitsApi } from "@/lib/api";
import { toast } from "sonner";

interface HabitCardProps {
  id: number;
  name: string;
  description: string;
  currentProgress: number;
  totalDays: number;
  completedDays: string[];
  currentStreak: number;
  onHabitUpdate?: (habitId: number, newProgress: number) => void;
}

export const HabitCard = ({ 
  id,
  name, 
  description, 
  currentProgress, 
  totalDays, 
  completedDays, 
  currentStreak,
  onHabitUpdate
}: HabitCardProps) => {
  const [isCompleting, setIsCompleting] = useState(false);
  const [localCompletedDays, setLocalCompletedDays] = useState(completedDays);
  const [localProgress, setLocalProgress] = useState(currentProgress);
  
  const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const progressPercentage = (localProgress / totalDays) * 100;

  // Update local state when props change
  useEffect(() => {
    setLocalCompletedDays(completedDays);
    setLocalProgress(currentProgress);
  }, [completedDays, currentProgress]);

  const handleDayClick = async (day: string, dayIndex: number) => {
    if (isCompleting) return;

    const isCurrentlyCompleted = localCompletedDays.includes(day);

    try {
      setIsCompleting(true);

      if (!isCurrentlyCompleted) {
        // Calculate the date for the clicked day
        const today = new Date();
        const currentDayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday, etc.
        const daysFromToday = dayIndex - currentDayOfWeek;
        const targetDate = new Date(today);
        targetDate.setDate(today.getDate() + daysFromToday);
        
        // Format as YYYY-MM-DD
        const completionDate = targetDate.toISOString().split('T')[0];
        
        // Mark as completed for the specific date
        await habitsApi.complete(id, completionDate);
        
        const newCompletedDays = [...localCompletedDays, day];
        const newProgress = localProgress + 1;
        
        setLocalCompletedDays(newCompletedDays);
        setLocalProgress(newProgress);
        
        if (onHabitUpdate) {
          onHabitUpdate(id, newProgress);
        }
        
        toast.success(`Great job! "${name}" completed for ${day}! 🎉`);
      } else {
        // Allow un-completing habits
        const newCompletedDays = localCompletedDays.filter(d => d !== day);
        const newProgress = Math.max(0, localProgress - 1);
        
        setLocalCompletedDays(newCompletedDays);
        setLocalProgress(newProgress);
        
        if (onHabitUpdate) {
          onHabitUpdate(id, newProgress);
        }
        
        toast.info(`"${name}" unmarked for ${day}`);
      }
    } catch (error: any) {
      console.error("Failed to update habit:", error);
      
      // Handle specific error cases
      if (error.response?.status === 400) {
        const errorMessage = error.response?.data?.detail || "Invalid request";
        if (errorMessage.includes("already completed")) {
          toast.info(`"${name}" is already completed for ${day}`);
        } else {
          toast.error(errorMessage);
        }
      } else {
        toast.error("Failed to update habit. Please try again.");
      }
    } finally {
      setIsCompleting(false);
    }
  };
  
  return (
    <div className="rounded-xl border border-[#E5E7EB] bg-white p-6 shadow-sm">
      <div className="flex items-start gap-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#F1F0FB]">
          <Star className="h-6 w-6 text-[#9b87f5]" />
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-semibold text-[#323D52]">{name}</h3>
          <p className="text-[#6B7280] mt-1">{description}</p>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-7 gap-2">
        {daysOfWeek.map((day, index) => {
          const isCompleted = localCompletedDays.includes(day);
          const isCurrent = day === daysOfWeek[new Date().getDay()];
          
          return (
            <div key={day} className="flex flex-col items-center">
              <div className="text-sm text-[#6B7280] mb-2">{day}</div>
              <button
                onClick={() => handleDayClick(day, index)}
                disabled={isCompleting}
                className={`
                  w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 cursor-pointer
                  ${isCompleted ? 'bg-[#9b87f5] text-white shadow-md hover:bg-[#8b77e5]' : 
                    isCurrent ? 'border-2 border-[#9b87f5] bg-transparent hover:bg-[#9b87f5]/10' : 
                    'bg-[#F3F4F6] hover:bg-[#E5E7EB] border border-[#D1D5DB]'}
                  hover:scale-105
                  ${isCompleting ? 'opacity-50' : ''}
                `}
                title={
                  isCompleted ? 'Click to unmark' :
                  isCurrent ? 'Today - Click to mark as completed' :
                  'Click to mark as completed'
                }
              >
                {isCompleted && <Check className="h-5 w-5" />}
                {isCompleting && isCurrent && !isCompleted && (
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-[#9b87f5] border-t-transparent"></div>
                )}
              </button>
            </div>
          );
        })}
      </div>

      <div className="mt-6 flex items-center justify-between">
        <div className="text-sm font-medium">Progress</div>
        <div className="text-sm font-medium">{localProgress}/{totalDays} days</div>
      </div>
      <Progress className="h-2 mt-2" value={progressPercentage} />

      <div className="mt-4 flex items-center text-[#F59E0B]">
        <Star className="h-5 w-5 mr-2 fill-[#F59E0B] text-[#F59E0B]" />
        <div className="font-medium">{currentStreak} day streak!</div>
      </div>
    </div>
  );
};
