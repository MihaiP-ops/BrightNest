
import { Card } from "@/components/ui/card";

interface AnalyticsCardProps {
  title: string;
  value: string | number;
}

export const AnalyticsCard = ({ title, value }: AnalyticsCardProps) => {
  return (
    <Card className="p-6 flex flex-col items-center justify-center">
      <h3 className="text-lg text-[#6B7280]">{title}</h3>
      <p className="text-4xl font-bold text-[#323D52] mt-2">{value}</p>
    </Card>
  );
};
