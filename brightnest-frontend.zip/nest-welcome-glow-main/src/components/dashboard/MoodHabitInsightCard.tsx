
import { TrendingUp, Info } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useCheckIns } from "@/hooks/useCheckIns";
import { generateMoodHabitInsight } from "@/utils/emotionAnalysis";

interface MoodHabitInsightCardProps {
  childId: string;
  habits: any[];
}

export const MoodHabitInsightCard = ({ childId, habits }: MoodHabitInsightCardProps) => {
  const { checkIns, loading } = useCheckIns(childId);

  // Get child name from mock data
  const getChildName = (id: string) => {
    const childNames: { [key: string]: string } = {
      "1": "Bella",
      "2": "Toby",
      "3": "Emma"
    };
    return childNames[id] || "Child";
  };

  const childName = getChildName(childId);
  const insight = generateMoodHabitInsight(checkIns, habits, childName);

  if (loading) {
    return (
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-100 border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="text-[#323D52]">Loading mood + habit insights...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-r from-blue-50 to-indigo-100 border-blue-200">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-3 text-[#323D52]">
          <div className="w-10 h-10 rounded-full bg-blue-200 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-blue-600" />
          </div>
          📈 Mood + Habit Insight
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-[#323D52]/80 mb-3">{insight}</p>
        <div className="flex items-center gap-2 text-xs text-[#323D52]/60">
          <Info className="w-3 h-3" />
          <span>This insight is based on your child's daily check-ins and completed routines.</span>
        </div>
      </CardContent>
    </Card>
  );
};
