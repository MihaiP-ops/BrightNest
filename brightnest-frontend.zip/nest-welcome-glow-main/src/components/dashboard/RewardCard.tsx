
import { Star } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface RewardCardProps {
  progressDays: number;
  totalDays: number;
  reward: string;
}

export const RewardCard = ({ progressDays, totalDays, reward }: RewardCardProps) => {
  const progressPercentage = (progressDays / totalDays) * 100;
  
  return (
    <div className="rounded-xl border border-[#E5E7EB] bg-white p-6 shadow-sm mt-4">
      <div className="flex items-center">
        <Star className="h-6 w-6 text-[#9b87f5] mr-3" />
        <h3 className="text-xl font-semibold text-[#323D52]">Next Reward</h3>
      </div>

      <div className="mt-4 flex items-center justify-between">
        <div className="text-sm font-medium">Progress to reward:</div>
        <div className="text-sm font-medium">{progressDays}/{totalDays} days</div>
      </div>
      <Progress className="h-2 mt-2" value={progressPercentage} />

      <div className="mt-4 text-[#323D52]">
        <div className="font-medium">Reward: {reward}</div>
      </div>
    </div>
  );
};
