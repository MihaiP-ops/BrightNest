
import React from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { useNavigate } from 'react-router-dom';

export const SettingsOption = () => {
  const { restartOnboarding } = useOnboarding();
  const navigate = useNavigate();

  const handleRestartOnboarding = () => {
    restartOnboarding();
    navigate('/onboarding');
  };

  return (
    <button 
      onClick={handleRestartOnboarding}
      className="text-[#323D52] hover:bg-gray-100 px-4 py-2 rounded-md w-full text-left"
    >
      Review App Introduction
    </button>
  );
};
