
import { useEffect, useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";

interface CelebrationMessageProps {
  show: boolean;
  habitName: string;
  onComplete: () => void;
}

export const CelebrationMessage = ({ show, habitName, onComplete }: CelebrationMessageProps) => {
  useEffect(() => {
    if (show) {
      const timer = setTimeout(() => {
        onComplete();
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, [show, onComplete]);

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black/20 flex items-center justify-center z-40 p-4">
      <Card className="bg-gradient-to-br from-green-50 to-emerald-100 border-green-200 shadow-xl animate-scale-in max-w-sm w-full">
        <CardContent className="p-6 text-center">
          <div className="space-y-3">
            <div className="text-4xl animate-bounce">🎉</div>
            <h3 className="text-lg font-bold text-green-800">
              Great job!
            </h3>
            <p className="text-green-700 font-medium">
              {habitName} completed this week!
            </p>
            <div className="text-2xl">⭐</div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
