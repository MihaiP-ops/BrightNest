
import { useNavigate } from "react-router-dom";
import { Logo } from "@/components/Logo";
import { useOnboarding } from "@/contexts/OnboardingContext";
import { useEffect } from "react";

export const WelcomeScreen = () => {
  const navigate = useNavigate();
  const { isFirstTimeUser } = useOnboarding();

  // If it's the first time user, redirect to onboarding
  useEffect(() => {
    if (isFirstTimeUser) {
      navigate('/onboarding');
    }
  }, [isFirstTimeUser, navigate]);

  return (
    <div className="min-h-screen bg-[#FFF9E5] px-6 py-12 flex flex-col">
      {/* Main Content Container */}
      <div className="flex-1 flex flex-col items-center justify-center max-w-sm mx-auto w-full">
        {/* Logo with BrightNest text */}
        <Logo showTitle={true} />
        
        {/* Tagline - positioned between logo and welcome text */}
        <p className="text-[#1E2B45] text-lg font-semibold text-center my-5 px-4">
          Building emotionally strong children from the very start.
        </p>
        
        {/* Welcome Text */}
        <p className="text-[#323D52] text-3xl font-bold mb-10">
          Welcome
        </p>

        {/* Buttons Container */}
        <div className="w-full space-y-6">
          {/* Sign In Button */}
          <button
            className="w-full bg-[#323D52] text-white py-3.5 px-6 rounded-xl font-medium text-lg hover:opacity-90 transition-opacity"
            onClick={() => navigate('/signin')}
          >
            Sign In
          </button>

          {/* Sign Up Button */}
          <button
            className="w-full bg-[#FFD95A] text-[#323D52] py-3.5 px-6 rounded-xl font-medium text-lg hover:opacity-90 transition-opacity"
            onClick={() => navigate('/signup')}
          >
            Sign Up
          </button>
        </div>
      </div>
    </div>
  );
};
