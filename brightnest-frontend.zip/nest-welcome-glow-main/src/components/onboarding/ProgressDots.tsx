
import React from 'react';

interface ProgressDotsProps {
  currentStep: number;
  totalSteps: number;
}

export const ProgressDots: React.FC<ProgressDotsProps> = ({ currentStep, totalSteps }) => {
  return (
    <div className="flex justify-center space-x-2 mt-8">
      {Array.from({ length: totalSteps }).map((_, index) => (
        <div
          key={index}
          className={`h-2 w-2 rounded-full transition-all duration-300 ${
            index + 1 === currentStep
              ? 'bg-[#003366] w-4'
              : index + 1 < currentStep
              ? 'bg-[#003366] opacity-70'
              : 'bg-[#003366] opacity-30'
          }`}
        />
      ))}
    </div>
  );
};
