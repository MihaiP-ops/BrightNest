
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { ProgressDots } from './ProgressDots';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';

export const Onboarding = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [direction, setDirection] = useState(0);
  const { setIsFirstTimeUser } = useOnboarding();
  const navigate = useNavigate();

  const totalSteps = 5;

  const goToNextStep = () => {
    if (currentStep < totalSteps) {
      setDirection(1);
      setCurrentStep(prev => prev + 1);
    } else {
      // Onboarding complete
      setIsFirstTimeUser(false);
      navigate('/');
    }
  };

  const skipOnboarding = () => {
    // Mark onboarding as complete and navigate to sign in
    setIsFirstTimeUser(false);
    navigate('/signin');
  };

  // Animation variants
  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
    }),
    center: {
      x: 0,
      opacity: 1,
    },
    exit: (direction: number) => ({
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
    }),
  };

  const screens = [
    {
      title: "Welcome to BrightNest",
      content: [
        "Your trusted space to support your child's emotional wellbeing.",
        "No personal data required — just nicknames and smiles."
      ]
    },
    {
      title: "Create Your Private Space",
      content: [
        "Use just an email and a password.",
        "No names or personal details needed.",
        "This helps you save your child's check-ins and habits safely."
      ]
    },
    {
      title: "Add Your Child (We recommend nicknames)",
      content: [
        "To personalize your tips, tell us your child's nickname and age only.",
        "No real names needed."
      ]
    },
    {
      title: "Your Data Is Always Private",
      content: [
        "We don't collect personal names or photos.",
        "You can delete your account and data anytime.",
        "All notes and moods are encrypted and private."
      ]
    },
    {
      title: "Let's Get Started",
      content: [
        "You're ready to start meaningful check-ins that help your child feel seen and supported."
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-[#FFF0C8] flex flex-col">
      {/* Skip Onboarding Button - Now styled like the Next button */}
      <div className="absolute top-4 right-4 z-10">
        <button
          onClick={skipOnboarding}
          className="bg-[#003366] text-white px-4 py-2 rounded-full font-medium hover:opacity-90 transition-opacity"
        >
          Skip Onboarding
        </button>
      </div>
      
      {/* Content Container */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 relative overflow-hidden">
        <AnimatePresence initial={false} mode="wait" custom={direction}>
          <motion.div
            key={currentStep}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 }
            }}
            className="w-full max-w-md"
          >
            <div className="bg-white rounded-lg p-8 shadow-lg">
              <h1 className="text-[#003366] text-2xl font-bold mb-6 text-center">
                {screens[currentStep - 1].title}
              </h1>
              
              <div className="space-y-4">
                {screens[currentStep - 1].content.map((paragraph, idx) => (
                  <p key={idx} className="text-[#003366] text-center">
                    {paragraph}
                  </p>
                ))}
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Next Button */}
      <div className="px-6 py-8 flex flex-col items-center">
        <button
          onClick={goToNextStep}
          className="bg-[#003366] text-white px-8 py-3 rounded-full font-medium hover:opacity-90 transition-opacity w-full max-w-xs"
        >
          {currentStep === totalSteps ? "Get Started" : "Next"}
        </button>
        
        {/* Progress Dots */}
        <ProgressDots currentStep={currentStep} totalSteps={totalSteps} />
      </div>
    </div>
  );
};
