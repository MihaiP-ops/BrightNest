
import { useState } from "react";
import { StarIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

interface FeedbackFormProps {
  onComplete: () => void;
}

interface FeedbackData {
  satisfaction: number | null;
  ease: number | null;
  recommend: number | null;
  comments: string;
  submitted: boolean;
}

export const FeedbackForm = ({ onComplete }: FeedbackFormProps) => {
  const [feedback, setFeedback] = useState<FeedbackData>({
    satisfaction: null,
    ease: null,
    recommend: null,
    comments: "",
    submitted: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (feedback.satisfaction === null || feedback.ease === null || feedback.recommend === null) {
      toast.error("Please complete all rating questions");
      return;
    }

    // Here you would typically save the feedback to a database
    console.log("Feedback submitted:", feedback);
    
    // Show success state
    setFeedback(prev => ({ ...prev, submitted: true }));
    
    // In a real app, you'd send this data to your backend
    setTimeout(() => {
      onComplete();
      toast.success("Thank you for your feedback!");
    }, 2000);
  };

  if (feedback.submitted) {
    return (
      <div className="py-12 flex flex-col items-center">
        <div className="w-20 h-20 rounded-full bg-[#C7F2C4] flex items-center justify-center mb-6">
          <StarIcon size={40} className="text-[#4A8085]" />
        </div>
        <h3 className="text-xl font-bold text-[#323D52] mb-2">Thank You!</h3>
        <p className="text-[#323D52] text-center max-w-md">
          Your feedback helps us improve BrightNest and better support families like yours.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8 py-4">
      {/* Satisfaction Rating */}
      <div className="space-y-3">
        <Label htmlFor="satisfaction" className="text-base font-medium">
          How satisfied are you with the BrightNest app overall?
        </Label>
        <RadioGroup
          id="satisfaction"
          className="flex justify-between"
          value={feedback.satisfaction?.toString() || ""}
          onValueChange={(value) => setFeedback(prev => ({ ...prev, satisfaction: parseInt(value) }))}
        >
          {[1, 2, 3, 4, 5].map((value) => (
            <div key={value} className="flex flex-col items-center">
              <RadioGroupItem value={value.toString()} id={`satisfaction-${value}`} className="sr-only" />
              <Label
                htmlFor={`satisfaction-${value}`}
                className={`flex flex-col items-center cursor-pointer p-2 rounded-md transition-colors ${
                  feedback.satisfaction === value ? 'bg-[#A8DADC]/20 text-[#323D52]' : 'text-gray-500'
                }`}
              >
                <span className="text-2xl mb-1">{value}</span>
                <span className="text-xs text-center">
                  {value === 1 ? "Not satisfied" : value === 5 ? "Very satisfied" : ""}
                </span>
              </Label>
            </div>
          ))}
        </RadioGroup>
      </div>

      {/* Ease of Use Rating */}
      <div className="space-y-3">
        <Label htmlFor="ease" className="text-base font-medium">
          How easy is it to use the app?
        </Label>
        <RadioGroup
          id="ease"
          className="flex justify-between"
          value={feedback.ease?.toString() || ""}
          onValueChange={(value) => setFeedback(prev => ({ ...prev, ease: parseInt(value) }))}
        >
          {[1, 2, 3, 4, 5].map((value) => (
            <div key={value} className="flex flex-col items-center">
              <RadioGroupItem value={value.toString()} id={`ease-${value}`} className="sr-only" />
              <Label
                htmlFor={`ease-${value}`}
                className={`flex flex-col items-center cursor-pointer p-2 rounded-md transition-colors ${
                  feedback.ease === value ? 'bg-[#A8DADC]/20 text-[#323D52]' : 'text-gray-500'
                }`}
              >
                <span className="text-2xl mb-1">{value}</span>
                <span className="text-xs text-center">
                  {value === 1 ? "Very difficult" : value === 5 ? "Very easy" : ""}
                </span>
              </Label>
            </div>
          ))}
        </RadioGroup>
      </div>

      {/* Recommendation Rating */}
      <div className="space-y-3">
        <Label htmlFor="recommend" className="text-base font-medium">
          How likely are you to recommend BrightNest to another parent or carer?
        </Label>
        <RadioGroup
          id="recommend"
          className="flex justify-between"
          value={feedback.recommend?.toString() || ""}
          onValueChange={(value) => setFeedback(prev => ({ ...prev, recommend: parseInt(value) }))}
        >
          {[1, 2, 3, 4, 5].map((value) => (
            <div key={value} className="flex flex-col items-center">
              <RadioGroupItem value={value.toString()} id={`recommend-${value}`} className="sr-only" />
              <Label
                htmlFor={`recommend-${value}`}
                className={`flex flex-col items-center cursor-pointer p-2 rounded-md transition-colors ${
                  feedback.recommend === value ? 'bg-[#A8DADC]/20 text-[#323D52]' : 'text-gray-500'
                }`}
              >
                <span className="text-2xl mb-1">{value}</span>
                <span className="text-xs text-center">
                  {value === 1 ? "Not likely at all" : value === 5 ? "Extremely likely" : ""}
                </span>
              </Label>
            </div>
          ))}
        </RadioGroup>
      </div>

      {/* Comments */}
      <div className="space-y-2">
        <Label htmlFor="comments" className="text-base font-medium">
          Any other comments or suggestions?
        </Label>
        <Textarea
          id="comments"
          value={feedback.comments}
          onChange={(e) => setFeedback(prev => ({ ...prev, comments: e.target.value }))}
          placeholder="Share your thoughts with us..."
          className="min-h-[120px] border-[#AED9E0] focus-visible:ring-[#AED9E0]"
        />
      </div>

      {/* Submit Button */}
      <Button
        type="submit"
        className="w-full bg-[#7E69AB] hover:bg-[#7E69AB]/90 text-white font-medium py-6"
      >
        Submit Feedback
      </Button>
    </form>
  );
};
