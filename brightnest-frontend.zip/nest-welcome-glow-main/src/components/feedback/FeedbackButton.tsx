
import { useState } from 'react';
import { MessageSquare } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { FeedbackForm } from './FeedbackForm';

export const FeedbackButton = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 left-6 z-30 flex items-center gap-2 bg-[#323D52] text-white px-6 py-3 rounded-md shadow-md hover:bg-[#323D52]/90 transition-colors"
        aria-label="Provide feedback"
      >
        <MessageSquare size={18} />
        <span className="text-sm font-medium">Feedback</span>
      </button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="bg-white sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-[#323D52]">Share your feedback</DialogTitle>
            <DialogDescription className="text-[#323D52]">
              Your feedback helps us improve BrightNest for all parents and carers.
            </DialogDescription>
          </DialogHeader>
          <FeedbackForm onComplete={() => setIsOpen(false)} />
        </DialogContent>
      </Dialog>
    </>
  );
};
