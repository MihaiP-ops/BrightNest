import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { OnboardingProvider } from "./contexts/OnboardingContext";
import { AuthProvider } from "./contexts/AuthContext";
import Index from "./pages/Index";
import SignUp from "./pages/SignUp";
import SignIn from "./pages/SignIn";
import LandingPage from "./pages/LandingPage";
import Dashboard from "./pages/Dashboard";
import CheckIn from "./pages/CheckIn";
import CheckInHistory from "./pages/CheckInHistory";
import HabitTracker from "./pages/HabitTracker";
import AddHabit from "./pages/AddHabit";
import MyNest from "./pages/MyNest";
import ChildDashboard from "./pages/ChildDashboard";
import NotFound from "./pages/NotFound";
import OnboardingPage from "./pages/OnboardingPage";
import AboutUs from "./pages/AboutUs";
import ResourceHub from "./pages/ResourceHub";
import ResourceDetail from "./pages/ResourceDetail";
import ProgressReports from "./pages/ProgressReports";
import PrivateRoute from "./components/PrivateRoute";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <BrowserRouter>
        <AuthProvider>
          <OnboardingProvider>
            <Toaster />
            <Sonner />
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<Index />} />
              <Route path="/signup" element={<SignUp />} />
              <Route path="/signin" element={<SignIn />} />
              <Route path="/about-us" element={<AboutUs />} />

              {/* Protected Routes */}
              <Route element={<PrivateRoute />}>
                <Route path="/onboarding" element={<OnboardingPage />} />
                <Route path="/landing" element={<LandingPage />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/check-in" element={<CheckIn />} />
                <Route path="/check-in-history" element={<CheckInHistory />} />
                <Route path="/habit-tracker" element={<HabitTracker />} />
                <Route path="/add-habit" element={<AddHabit />} />
                <Route path="/my-nest" element={<MyNest />} />
                <Route path="/child-dashboard/:childId" element={<ChildDashboard />} />
                <Route path="/reports/:childId" element={<ProgressReports />} />
                <Route path="/resource-hub" element={<ResourceHub />} />
                <Route path="/resource/:id" element={<ResourceDetail />} />
                <Route path="/main-menu" element={<Navigate to="/landing" replace />} />
              </Route>

              {/* 404 Route */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </OnboardingProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
