import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Download, Share2, TrendingUp, Target, Calendar, Sparkles } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { reports } from '@/lib/api';
import { toast } from 'sonner';

interface ProgressData {
  child_id: number;
  child_name: string;
  period: string;
  start_date: string;
  end_date: string;
  mood_trends: Array<{
    date: string;
    avg_mood: number;
    checkin_count: number;
  }>;
  habit_stats: Array<{
    habit_id: number;
    habit_name: string;
    completions: number;
    expected_completions: number;
    completion_rate: number;
  }>;
  insights: Array<{
    type: string;
    title: string;
    description: string;
  }>;
  ai_summary: string;
  summary: {
    avg_mood: number;
    total_checkins: number;
    active_habits: number;
    avg_completion_rate: number;
  };
}

export default function ProgressReports() {
  const { childId } = useParams<{ childId: string }>();
  const navigate = useNavigate();
  const [progressData, setProgressData] = useState<ProgressData | null>(null);
  const [period, setPeriod] = useState<'week' | 'month' | 'quarter'>('week');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (childId) {
      loadProgressData();
    }
  }, [childId, period]);

  const loadProgressData = async () => {
    try {
      setIsLoading(true);
      const data = await reports.getChildProgress(parseInt(childId!), period);
      setProgressData(data);
    } catch (error) {
      console.error('Failed to load progress data:', error);
      toast.error('Failed to load progress report');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadPDF = async () => {
    try {
      await reports.downloadChildProgressPDF(parseInt(childId!), period);
      toast.success('Report downloaded successfully!');
    } catch (error) {
      console.error('Failed to download PDF:', error);
      toast.error('Failed to download report');
    }
  };

  const getInsightBadgeColor = (type: string) => {
    switch (type) {
      case 'positive':
      case 'achievement':
        return 'bg-green-100 text-green-800 hover:bg-green-200';
      case 'alert':
        return 'bg-red-100 text-red-800 hover:bg-red-200';
      case 'suggestion':
        return 'bg-blue-100 text-blue-800 hover:bg-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 hover:bg-gray-200';
    }
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric' 
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-4 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading progress report...</p>
        </div>
      </div>
    );
  }

  if (!progressData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-4 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Failed to load progress report</p>
          <Button onClick={() => navigate(-1)} variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button 
              onClick={() => navigate(-1)} 
              variant="ghost" 
              size="sm"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Progress Report</h1>
              <p className="text-gray-600">
                {progressData.child_name} • {formatDate(progressData.start_date)} - {formatDate(progressData.end_date)}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Select value={period} onValueChange={(value: 'week' | 'month' | 'quarter') => setPeriod(value)}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">Week</SelectItem>
                <SelectItem value="month">Month</SelectItem>
                <SelectItem value="quarter">Quarter</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm">
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
            <Button variant="outline" size="sm" onClick={handleDownloadPDF}>
              <Download className="w-4 h-4 mr-2" />
              Export PDF
            </Button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Mood</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{progressData.summary.avg_mood}</div>
              <p className="text-xs text-muted-foreground">
                out of 5.0
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Check-ins</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{progressData.summary.total_checkins}</div>
              <p className="text-xs text-muted-foreground">
                total recorded
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Habits</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{progressData.summary.active_habits}</div>
              <p className="text-xs text-muted-foreground">
                being tracked
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completion Rate</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{progressData.summary.avg_completion_rate}%</div>
              <p className="text-xs text-muted-foreground">
                average across habits
              </p>
            </CardContent>
          </Card>
        </div>

        {/* AI Summary Section */}
        {progressData.ai_summary && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-purple-600" />
                AI Summary
              </CardTitle>
              <CardDescription>
                Personalized insights generated for {progressData.child_name}'s {period}ly progress
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-lg border-l-4 border-purple-500">
                <div className="prose prose-sm max-w-none text-gray-700 leading-relaxed">
                  {progressData.ai_summary.split('\n').map((paragraph, index) => (
                    <p key={index} className="mb-3 last:mb-0">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Mood Trends Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Mood Trends</CardTitle>
              <CardDescription>Daily mood ratings over time</CardDescription>
            </CardHeader>
            <CardContent>
              {progressData.mood_trends.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={progressData.mood_trends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="date" 
                      tickFormatter={formatDate}
                    />
                    <YAxis domain={[1, 5]} />
                    <Tooltip 
                      labelFormatter={(value) => formatDate(value as string)}
                      formatter={(value: number) => [value, 'Mood']}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="avg_mood" 
                      stroke="#8b5cf6" 
                      strokeWidth={2}
                      dot={{ fill: '#8b5cf6', strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-gray-500">
                  No mood data available for this period
                </div>
              )}
            </CardContent>
          </Card>

          {/* Habit Completion Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Habit Performance</CardTitle>
              <CardDescription>Completion rates by habit</CardDescription>
            </CardHeader>
            <CardContent>
              {progressData.habit_stats.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={progressData.habit_stats}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="habit_name" 
                      tick={{ fontSize: 12 }}
                      interval={0}
                      angle={-45}
                      textAnchor="end"
                      height={80}
                    />
                    <YAxis />
                    <Tooltip 
                      formatter={(value: number) => [`${value}%`, 'Completion Rate']}
                    />
                    <Bar 
                      dataKey="completion_rate" 
                      fill="#10b981"
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-gray-500">
                  No habit data available for this period
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Insights Section */}
        {progressData.insights.length > 0 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>AI Insights</CardTitle>
              <CardDescription>Personalized observations and recommendations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {progressData.insights.map((insight, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                    <Badge className={getInsightBadgeColor(insight.type)}>
                      {insight.type}
                    </Badge>
                    <div>
                      <h4 className="font-medium text-gray-900">{insight.title}</h4>
                      <p className="text-gray-600 text-sm mt-1">{insight.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Detailed Habit Stats */}
        {progressData.habit_stats.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Detailed Habit Statistics</CardTitle>
              <CardDescription>Complete breakdown of habit performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {progressData.habit_stats.map((habit) => (
                  <div key={habit.habit_id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h4 className="font-medium text-gray-900">{habit.habit_name}</h4>
                      <p className="text-sm text-gray-600">
                        {habit.completions} of {habit.expected_completions} expected completions
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-gray-900">{habit.completion_rate}%</div>
                      <div className="w-20 bg-gray-200 rounded-full h-2 mt-1">
                        <div 
                          className="bg-green-500 h-2 rounded-full" 
                          style={{ width: `${Math.min(habit.completion_rate, 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
} 