import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { ArrowLeft, User, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { FeedbackButton } from "@/components/feedback/FeedbackButton";
import { checkIns as checkInsApi, children as childrenApi, aiInsights } from "@/lib/api";

interface Child {
  id: number;
  name: string;
  age: number;
  photo_url?: string;
}

interface CheckIn {
  id: number;
  child_id: number;
  emotion_rating: number;
  notes?: string;
  created_at: string;
  cached_tip?: {
    id: number;
    check_in_id: number;
    ai_tip: string;
    habit_suggestion: string;
    is_tip_personalized: boolean;
    tip_score?: number;
    created_at: string;
    updated_at: string;
  };
}

const emotions = [
  { value: 1, emoji: "😢", label: "Very Sad" },
  { value: 2, emoji: "😕", label: "Sad" },
  { value: 3, emoji: "😐", label: "Okay" },
  { value: 4, emoji: "🙂", label: "Happy" },
  { value: 5, emoji: "😄", label: "Very Happy" }
];

const emojiMap: { [key: number]: { emoji: string; label: string } } = {
  1: { emoji: "😢", label: "Very Sad" },
  2: { emoji: "😕", label: "Sad" },
  3: { emoji: "😐", label: "Okay" },
  4: { emoji: "🙂", label: "Happy" },
  5: { emoji: "😄", label: "Very Happy" },
};

const CheckIn = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const childId = searchParams.get("childId");
  
  const [child, setChild] = useState<Child | null>(null);
  const [children, setChildren] = useState<Child[]>([]);
  const [checkIns, setCheckIns] = useState<CheckIn[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isHistoryLoading, setIsHistoryLoading] = useState(false);
  const [selectedEmotion, setSelectedEmotion] = useState<number | null>(null);
  const [notes, setNotes] = useState("");
  const [aiTips, setAiTips] = useState<{[key: number]: string}>({});
  const [habitSuggestions, setHabitSuggestions] = useState<{[key: number]: string}>({});

  useEffect(() => {
    if (childId) {
      loadChild(parseInt(childId));
      loadCheckIns(parseInt(childId));
    } else {
      loadChildren();
    }
  }, [childId]);

  const loadChildren = async () => {
    try {
      const data = await childrenApi.getAll();
      setChildren(data);
    } catch (error) {
      console.error("Failed to load children:", error);
      toast.error("Failed to load children");
      navigate("/my-nest");
    } finally {
      setIsLoading(false);
    }
  };

  const loadChild = async (id: number) => {
    try {
      const data = await childrenApi.getOne(id);
      setChild(data);
    } catch (error) {
      console.error("Failed to load child:", error);
      toast.error("Failed to load child data");
      navigate("/my-nest");
    } finally {
      setIsLoading(false);
    }
  };

  const loadCheckIns = async (id: number) => {
    setIsHistoryLoading(true);
    try {
      // Use the new endpoint that includes cached AI tips
      const data = await checkInsApi.getChildCheckInsWithTips(id, 30); // Load last 30 days with AI tips
      setCheckIns(data);
      
      // Extract AI tips and habits from cached data for the most recent check-in
      if (data.length > 0) {
        const recentCheckIn = data[0];
        if (recentCheckIn.cached_tip) {
          // Use cached AI tips instead of loading them separately
          setAiTips(prev => ({
            ...prev,
            [recentCheckIn.id]: recentCheckIn.cached_tip.ai_tip
          }));
          
          // Parse the cached habit suggestion (it might be in "Name – Description" format)
          const cachedHabit = recentCheckIn.cached_tip.habit_suggestion;
          
          setHabitSuggestions(prev => ({
            ...prev,
            [recentCheckIn.id]: cachedHabit // Store the full cached suggestion
          }));
        }
      }
    } catch (error) {
      console.error("Failed to load check-ins:", error);
      // Check if it's an authentication error
      if (error.response?.status === 401) {
        toast.error("Please log in again to view check-ins");
        navigate('/signin');
      }
    } finally {
      setIsHistoryLoading(false);
    }
  };

  const loadAIInsights = async (childId: number, emotionRating: number, notes: string, checkInId: number) => {
    console.log("🔍 Loading AI insights for:", { childId, emotionRating, notes, checkInId });
    const token = localStorage.getItem('token');
    console.log("🔑 Auth token present:", !!token);
    if (token) {
      console.log("🔑 Token preview:", token.substring(0, 20) + "...");
      // Test if token is valid by checking profile
      try {
        const profileResponse = await fetch('http://localhost:8000/api/v1/auth/me', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        console.log("🔑 Token validation:", profileResponse.status === 200 ? "Valid" : "Invalid");
        if (profileResponse.status !== 200) {
          console.log("🔑 Token validation error:", await profileResponse.text());
        }
      } catch (e) {
        console.log("🔑 Token validation failed:", e.message);
      }
    }
    
    try {
      // Load AI tip with personalization based on notes
      console.log("📝 Requesting AI tip...");
      console.log("📝 Tip API call params:", { childId, emotionRating, notes: notes?.length || 0 });
      const tipData = await aiInsights.getTip(childId, emotionRating, notes);
      console.log("✅ AI tip received:", tipData);
      setAiTips(prev => ({ ...prev, [checkInId]: tipData.tip }));
      
      // Load habit suggestion
      console.log("🎯 Requesting habit suggestion...");
      console.log("🎯 Habit API call params:", { childId, emotionRating, notes });
      const habitData = await aiInsights.getHabitSuggestion(childId, emotionRating, notes);
      console.log("✅ Habit suggestion received:", habitData);
      const habitText = `${habitData.habit_name} – ${habitData.habit_description}`;
      setHabitSuggestions(prev => ({ ...prev, [checkInId]: habitText }));
    } catch (error) {
      console.error("❌ Failed to load AI insights:", error);
      console.error("❌ Error details:", error.response?.data || error.message);
      console.log("🔄 Using fallback content instead");
      
      // Set fallback content
      setAiTips(prev => ({ ...prev, [checkInId]: generateFallbackTip(emotionRating) }));
      setHabitSuggestions(prev => ({ ...prev, [checkInId]: generateFallbackHabit(emotionRating, notes) }));
    }
  };

  const generateFallbackTip = (emotionRating: number) => {
    if (emotionRating <= 2) {
      return "It's important to acknowledge difficult emotions. Try validating their feelings and offering comfort through your presence and understanding.";
    } else if (emotionRating >= 4) {
      return "Celebrate these positive moments! Ask about what specifically made them happy to reinforce positive experiences.";
    }
    return "Mixed emotions are completely normal. Continue providing consistent support and emotional validation.";
  };

  const generateFallbackHabit = (emotionRating: number, notes: string) => {
    const text = notes.toLowerCase();
    
    // Determine category based on context (similar to backend logic)
    const physicalKeywords = ['tired', 'energy', 'active', 'play', 'run', 'jump', 'dance', 'exercise', 'outdoor', 'park', 'sports', 'movement', 'restless', 'hyper', 'calm down', 'bedtime', 'sleep', 'nap', 'relax', 'stretch', 'yoga', 'walk'];
    const learningKeywords = ['school', 'homework', 'study', 'read', 'book', 'learn', 'curious', 'question', 'creative', 'art', 'draw', 'paint', 'music', 'instrument', 'build', 'explore', 'discover', 'experiment', 'problem', 'challenge', 'academic'];
    const otherKeywords = ['chore', 'clean', 'organize', 'help', 'responsibility', 'independence', 'routine', 'schedule', 'time', 'plan', 'prepare', 'cook', 'garden', 'sibling', 'friend', 'share', 'cooperate', 'listen', 'follow'];
    
    const physicalScore = physicalKeywords.filter(keyword => text.includes(keyword)).length;
    const learningScore = learningKeywords.filter(keyword => text.includes(keyword)).length;
    const otherScore = otherKeywords.filter(keyword => text.includes(keyword)).length;
    
    if (emotionRating <= 2) { // Sad/upset emotions
      if (physicalScore > 0) {
        return "Gentle Movement Break – 5 minutes of stretching or walking to help feel better";
      }
      if (otherScore > 0) {
        return "Helpful Task – Choose one small way to help around the house";
      }
      if (learningScore > 0) {
        return "Creative Expression – Draw or write about how you're feeling";
      }
      return "Calm Breathing – Take 3 deep breaths together when feeling upset";
    } else if (emotionRating >= 4) { // Happy/excited emotions
      if (learningScore > 0) {
        return "Learning Adventure – Explore something new that interests you";
      }
      if (physicalScore > 0) {
        return "Energy Release – Dance, jump, or play actively for 10 minutes";
      }
      if (otherScore > 0) {
        return "Kindness Mission – Do something nice for someone else";
      }
      return "Gratitude Moment – Share one thing you're thankful for today";
    } else { // Neutral emotions
      if (learningScore > physicalScore && learningScore > otherScore) {
        return "Curiosity Quest – Ask questions about something you want to learn";
      }
      if (physicalScore > otherScore) {
        return "Active Play – 15 minutes of movement or outdoor time";
      }
      if (otherScore > 0) {
        return "Responsibility Practice – Complete one helpful task independently";
      }
      return "Daily Check-in – Spend 5 minutes talking about your day";
    }
  };

  const extractShortHabitName = (fullHabitText: string): string => {
    // Clean up the text first - remove any contextual suffixes that might have been added
    let cleanText = fullHabitText.trim();
    
    // Remove common contextual patterns that don't belong in habit names
    cleanText = cleanText.replace(/\s*–\s*(sad|happy|neutral|okay|very sad|very happy),\s*.*$/i, '');
    cleanText = cleanText.replace(/\s*–\s*(after a fall|at bedtime|after school|in the morning|with a sibling|when feeling anxious|when tired|Oct \d+|Dec \d+|Jan \d+|Feb \d+|Mar \d+|Apr \d+|May \d+|Jun \d+|Jul \d+|Aug \d+|Sep \d+|Nov \d+).*$/i, '');
    cleanText = cleanText.replace(/\s*–\s*\d{1,2}\s*(Oct|Dec|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Nov).*$/i, '');
    
    // Prefer explicit "Name – Description" or "Name: Description" formats
    const separators = [' – ', ' — ', ' - ', ': '];
    for (const sep of separators) {
      if (cleanText.includes(sep)) {
        const [name, description] = cleanText.split(sep);
        const cleanedName = name.trim();

        // If the name is already descriptive enough (3+ words), return it
        const nameWordCount = cleanedName.split(/\s+/).length;
        if (nameWordCount >= 3) return cleanedName;

        // Otherwise, enrich with 1-2 distinctive words from the description
        const stopwords = new Set([
          'a','an','the','and','or','but','in','on','at','to','for','of','with','by','from','this','that','these','those','her','his','their','our','your','after','when','each','every','very','more','most','less','into','over','under','about','into','through','together','daily','practice','helps','help','focus','skills','time','child','children','feeling','feelings','emotion','emotions'
        ]);
        const keywords = (description || '')
          .toLowerCase()
          .replace(/[^a-z\s]/g, ' ')
          .split(/\s+/)
          .filter(w => w.length > 3 && !stopwords.has(w))
          .slice(0, 2);

        const enriched = [cleanedName, ...Array.from(new Set(keywords))].join(' ').trim();
        // Cap to 12 words to keep names readable
        return enriched.split(/\s+/).slice(0, 12).join(' ');
      }
    }

    // If it's already short and clean, use as-is
    const words = cleanText.split(/\s+/);
    if (words.length <= 6) return cleanText;

    // Generic fallback: take first 4-5 meaningful words
    const stop = new Set(['a','an','the','and','or','but','in','on','at','to','for','of','with','by','child','children','feeling','feelings']);
    const meaningful = words.filter(w => !stop.has(w.toLowerCase()));
    return meaningful.slice(0, 5).join(' ');
  };


  const handleAddToHabitTracker = (fullHabitText: string, context?: { emotionRating: number; notes?: string; createdAt?: string }) => {
    if (!child) return;
    const cleanHabitName = extractShortHabitName(fullHabitText);

    toast.success("Habit added to tracker!");
    navigate(`/add-habit?habitName=${encodeURIComponent(cleanHabitName)}&childId=${child.id}`);
  };

  const handleSubmit = async () => {
    if (!child || selectedEmotion === null) {
      toast.error("Please select an emotion");
      return;
    }

    try {
      const newCheckIn = await checkInsApi.create({
        child_id: child.id,
        emotion_rating: selectedEmotion,
        notes: notes.trim() || undefined
      });
      
      // Reload check-ins with cached AI tips (this will trigger AI generation for the new check-in)
      await loadCheckIns(child.id);
      
      // Reset the form
      setSelectedEmotion(null);
      setNotes("");
      
      toast.success("Check-in recorded successfully!");
    } catch (error) {
      console.error("Failed to save check-in:", error);
      toast.error("Failed to save check-in");
    }
  };

  const handleChildSelect = (selectedChild: Child) => {
    navigate(`/check-in?childId=${selectedChild.id}`);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FFF9E5] flex items-center justify-center">
        <div className="text-[#323D52] text-lg">Loading...</div>
      </div>
    );
  }

  // Show child selection screen if no childId is provided
  if (!childId) {
    return (
      <div className="min-h-screen bg-[#FFF9E5] px-6 py-12 flex flex-col">
        {/* Header */}
        <header className="mb-8">
          <button 
            onClick={() => navigate(-1)} 
            className="text-[#323D52] hover:opacity-80 transition-opacity flex items-center gap-2"
          >
            <ArrowLeft size={24} />
            Back
          </button>
        </header>

        {/* Main Content */}
        <main className="flex-1 flex flex-col max-w-md mx-auto w-full">
          <h1 className="text-2xl font-bold text-[#323D52] mb-2">Emotional Check-in</h1>
          <p className="text-[#323D52]/80 mb-8">Select a child for their emotional check-in.</p>

          {/* Children List */}
          <div className="space-y-4">
            {children.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-[#323D52]/60 mb-4">No children found in your nest.</p>
                <Button
                  onClick={() => navigate("/my-nest")}
                  className="bg-[#FFD95A] hover:bg-[#FFD95A]/90 text-[#323D52]"
                >
                  Add a Child
                </Button>
              </div>
            ) : (
              children.map((childItem) => (
                <Card 
                  key={childItem.id} 
                  className="p-4 cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => handleChildSelect(childItem)}
                >
                  <div className="flex items-center gap-4">
                    {childItem.photo_url ? (
                      <img 
                        src={childItem.photo_url} 
                        alt={childItem.name}
                        className="w-16 h-16 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-16 h-16 rounded-full bg-[#AED9E0] flex items-center justify-center">
                        <User size={32} className="text-[#323D52]" />
                      </div>
                    )}
                    <div>
                      <h3 className="text-lg font-semibold text-[#323D52]">{childItem.name}</h3>
                      <p className="text-[#323D52]/80">{childItem.age} years old</p>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>
        </main>

        {/* Feedback Button */}
        <FeedbackButton />
      </div>
    );
  }

  if (!child) {
    return (
      <div className="min-h-screen bg-[#FFF9E5] flex items-center justify-center">
        <div className="text-[#323D52] text-lg">Child not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF9E5] px-6 py-12 flex flex-col">
      {/* Header */}
      <header className="mb-8">
        <button 
          onClick={() => navigate(`/child-dashboard/${child.id}`)} 
          className="text-[#323D52] hover:opacity-80 transition-opacity flex items-center gap-2"
        >
          <ArrowLeft size={24} />
          Back
        </button>
      </header>

      <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full">
        {/* Daily Check-in Form */}
        <div className="max-w-md mx-auto w-full mb-8">
          <h1 className="text-2xl font-bold text-[#323D52] mb-2">How is {child.name} feeling?</h1>
          <p className="text-[#323D52]/80 mb-8">Select an emotion that best describes their current mood.</p>

          {/* Emotion Selection */}
          <div className="grid grid-cols-5 gap-4 mb-8">
            {emotions.map((emotion) => (
              <button
                key={emotion.value}
                onClick={() => {
                  console.log("Emotion selected:", emotion.value, emotion.label);
                  setSelectedEmotion(emotion.value);
                }}
                className={`flex flex-col items-center p-4 rounded-lg transition-all ${
                  selectedEmotion === emotion.value
                    ? "bg-[#FFD95A] scale-110"
                    : "bg-white hover:bg-[#FFD95A]/20"
                }`}
              >
                <span className="text-4xl mb-2">{emotion.emoji}</span>
                <span className="text-xs text-[#323D52] text-center">{emotion.label}</span>
              </button>
            ))}
          </div>

          {/* Notes */}
          <div className="mb-8">
            <label className="block text-[#323D52] font-medium mb-2">
              Notes (optional)
            </label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add any additional notes about their mood..."
              className="min-h-[100px]"
            />
          </div>

          {/* Submit Button */}
          <Button
            onClick={() => {
              console.log("Button clicked! Selected emotion:", selectedEmotion);
              handleSubmit();
            }}
            disabled={selectedEmotion === null}
            className="w-full bg-[#FFD95A] hover:bg-[#FFD95A]/90 text-[#323D52] py-6 text-lg"
          >
            {selectedEmotion === null ? "SELECT AN EMOTION FIRST" : "SUBMIT CHECK-IN"}
          </Button>

          {/* Check-in History Button */}
          <Button
            onClick={() => navigate(`/check-in-history?childId=${child.id}`)}
            className="w-full mt-4 bg-[#AED9E0] hover:bg-[#AED9E0]/90 text-[#323D52] py-6 text-lg"
          >
            CHECK IN HISTORY
          </Button>
        </div>

        {/* Most Recent Check-in Section */}
        <div className="w-full">
          <h2 className="text-xl font-bold text-[#323D52] mb-6 text-center">Most Recent Check-in</h2>
          
          {isHistoryLoading ? (
            <div className="text-center py-8 text-[#323D52]">Loading recent check-in...</div>
          ) : checkIns.length === 0 ? (
            <div className="text-center py-8 text-[#323D52]/60">
              No check-ins yet. Your most recent check-in will appear here.
            </div>
          ) : (
            <div className="space-y-6 max-w-2xl mx-auto">
              {checkIns.slice(0, 1).map((checkIn) => {
                const emotionData = emojiMap[checkIn.emotion_rating] || emojiMap[3];
                const suggestedHabit = habitSuggestions[checkIn.id] || generateFallbackHabit(checkIn.emotion_rating, checkIn.notes || '');
                const aiTip = aiTips[checkIn.id] || generateFallbackTip(checkIn.emotion_rating);
                
                return (
                  <Card key={checkIn.id} className="overflow-hidden">
                    {/* Header with emotion and date */}
                    <div className="p-5 flex items-center space-x-5 border-b border-[#AED9E0]/20 bg-[#FFF9E5]">
                      <div className="flex flex-col items-center w-20">
                        <span className="text-4xl">{emotionData.emoji}</span>
                        <span className="text-xs text-[#8E9196] mt-1">{emotionData.label}</span>
                      </div>
                      <div className="flex-1">
                        <span className="text-sm font-bold text-[#FFD95A]">
                          {new Date(checkIn.created_at).toLocaleDateString(undefined, {
                            month: "short",
                            day: "numeric",
                            year: "numeric"
                          })}
                        </span>
                        <div className="text-[#323D52] text-base font-medium">
                          {checkIn.notes || 'No notes added'}
                        </div>
                      </div>
                    </div>
                    
                    {/* Extended content section */}
                    <div className="p-5 bg-white">
                      {/* AI Tip */}
                      <div className="mb-4 bg-[#F1F0FB] p-4 rounded-lg">
                        <h3 className="text-sm uppercase text-[#9b87f5] font-semibold mb-2">SUGGESTED TIP</h3>
                        <p className="text-[#323D52] italic">{aiTip}</p>
                      </div>
                      
                      {/* Suggested Habit */}
                      <div className="bg-[#E6F4F1] p-4 rounded-lg">
                        <h3 className="text-sm uppercase text-[#5E9FA3] font-semibold mb-2">SUGGESTED HABIT</h3>
                        <p className="text-[#323D52] font-medium mb-3">{suggestedHabit}</p>
                        
                        <Button
                          onClick={() => handleAddToHabitTracker(suggestedHabit, { emotionRating: checkIn.emotion_rating, notes: checkIn.notes || '', createdAt: checkIn.created_at })}
                          className="bg-[#5E9FA3] hover:bg-[#4A8085] text-white"
                          size="sm"
                        >
                          <Plus size={16} className="mr-1" /> Add to Habit Tracker
                        </Button>
                      </div>
                    </div>
                  </Card>
                );
              })}
              
              {checkIns.length > 1 && (
                <div className="text-center">
                  <Button
                    onClick={() => navigate(`/check-in-history?childId=${child.id}`)}
                    variant="outline"
                    className="text-[#323D52]"
                  >
                    View All Check-ins ({checkIns.length} total)
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Feedback Button */}
      <FeedbackButton />
    </div>
  );
};

export default CheckIn;
