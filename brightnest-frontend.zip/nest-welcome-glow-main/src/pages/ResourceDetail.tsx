import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  Clock, 
  User, 
  BookOpen, 
  Video, 
  FileText, 
  ExternalLink,
  Calendar
} from 'lucide-react';
import { resources } from '@/lib/api';

interface Resource {
  id: number;
  title: string;
  description: string;
  content: string;
  resource_type: string;
  url?: string;
  file_path?: string;
  thumbnail_url?: string;
  author?: string;
  read_time_minutes?: number;
  difficulty_level?: string;
  is_featured: boolean;
  view_count: number;
  created_at: string;
  category: {
    id: number;
    name: string;
    description: string;
    icon: string;
    color: string;
  };
}

const getResourceIcon = (type: string) => {
  switch (type) {
    case 'article': return BookOpen;
    case 'video': return Video;
    case 'pdf': return FileText;
    default: return BookOpen;
  }
};

const getDifficultyColor = (level?: string) => {
  switch (level?.toLowerCase()) {
    case 'beginner': return 'bg-green-100 text-green-800';
    case 'intermediate': return 'bg-yellow-100 text-yellow-800';
    case 'advanced': return 'bg-red-100 text-red-800';
    default: return 'bg-gray-100 text-gray-800';
  }
};

export default function ResourceDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [resource, setResource] = useState<Resource | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadResource = async () => {
      if (!id) {
        setError('Resource ID not provided');
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const resourceData = await resources.getResource(parseInt(id));
        setResource(resourceData);
      } catch (err) {
        console.error('Error loading resource:', err);
        setError('Failed to load resource');
      } finally {
        setLoading(false);
      }
    };

    loadResource();
  }, [id]);

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-64 bg-gray-200 rounded mb-4"></div>
          <div className="space-y-2">
            <div className="h-4 bg-gray-200 rounded w-full"></div>
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !resource) {
    return (
      <div className="container mx-auto p-6">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/resource-hub')}
          className="flex items-center gap-2 mb-4"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Resource Hub
        </Button>
        <Card>
          <CardContent className="p-8 text-center">
            <h2 className="text-xl font-semibold mb-2">Resource Not Found</h2>
            <p className="text-gray-600 mb-4">{error || 'The requested resource could not be found.'}</p>
            <Button onClick={() => navigate('/resource-hub')}>
              Return to Resource Hub
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const ResourceIcon = getResourceIcon(resource.resource_type);

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      {/* Back Button */}
      <Button 
        variant="ghost" 
        onClick={() => navigate('/resource-hub')}
        className="flex items-center gap-2 mb-6"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Resource Hub
      </Button>

      <div className="space-y-6">
        {/* Header */}
        <div className="space-y-4">
          <div className="flex items-start gap-4">
            <div 
              className="p-3 rounded-lg"
              style={{ backgroundColor: `${resource.category.color}20` }}
            >
              <ResourceIcon 
                className="h-6 w-6" 
                style={{ color: resource.category.color }}
              />
            </div>
            <div className="flex-1 space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <Badge 
                  variant="secondary"
                  style={{ backgroundColor: `${resource.category.color}20`, color: resource.category.color }}
                >
                  {resource.category.name}
                </Badge>
                {resource.difficulty_level && (
                  <Badge className={getDifficultyColor(resource.difficulty_level)}>
                    {resource.difficulty_level}
                  </Badge>
                )}
                {resource.is_featured && (
                  <Badge variant="default" className="bg-yellow-100 text-yellow-800">
                    Featured
                  </Badge>
                )}
              </div>
              <h1 className="text-3xl font-bold text-gray-900">{resource.title}</h1>
              <p className="text-lg text-gray-600">{resource.description}</p>
            </div>
          </div>

          {/* Metadata */}
          <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
            {resource.author && (
              <div className="flex items-center gap-1">
                <User className="h-4 w-4" />
                {resource.author}
              </div>
            )}
            {resource.read_time_minutes && (
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {resource.read_time_minutes} min read
              </div>
            )}
            <div className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              {new Date(resource.created_at).toLocaleDateString()}
            </div>
            <div className="text-gray-400">
              {resource.view_count} views
            </div>
          </div>
        </div>

        {/* Content */}
        <Card>
          <CardContent className="p-8">
            {resource.resource_type === 'video' && resource.url ? (
              <div className="space-y-6">
                <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <Video className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                    <p className="text-gray-600 mb-4">External Video Content</p>
                    <Button asChild>
                      <a href={resource.url} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Watch Video
                      </a>
                    </Button>
                  </div>
                </div>
                {resource.content && (
                  <div className="prose prose-lg max-w-none">
                    <div className="whitespace-pre-wrap">{resource.content}</div>
                  </div>
                )}
              </div>
            ) : resource.resource_type === 'pdf' && resource.file_path ? (
              <div className="space-y-6">
                <div className="bg-gray-50 p-6 rounded-lg text-center">
                  <FileText className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                  <p className="text-gray-600 mb-4">PDF Document</p>
                  <Button asChild>
                    <a href={resource.file_path} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View PDF
                    </a>
                  </Button>
                </div>
                {resource.content && (
                  <div className="prose prose-lg max-w-none">
                    <div className="whitespace-pre-wrap">{resource.content}</div>
                  </div>
                )}
              </div>
            ) : (
              <div className="prose prose-lg max-w-none">
                <div className="whitespace-pre-wrap">{resource.content}</div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* External Link */}
        {resource.url && resource.resource_type === 'article' && (
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">External Resource</h3>
                  <p className="text-sm text-gray-600">View the full article on the original website</p>
                </div>
                <Button variant="outline" asChild>
                  <a href={resource.url} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Visit Source
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
} 