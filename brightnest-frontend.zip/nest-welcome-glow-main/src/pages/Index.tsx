
import { WelcomeScreen } from "@/components/WelcomeScreen";

const Index = () => {
  return <WelcomeScreen />;
};

export default Index;
