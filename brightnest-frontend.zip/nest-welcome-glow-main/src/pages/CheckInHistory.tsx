
import { ArrowLeft, Plus } from "lucide-react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useState, useEffect } from "react";
import { checkIns as checkInsApi } from "@/lib/api";

const emojiMap: { [key: number]: { emoji: string; label: string } } = {
  1: { emoji: "😢", label: "Very Sad" },
  2: { emoji: "😕", label: "Sad" },
  3: { emoji: "😐", label: "Okay" },
  4: { emoji: "🙂", label: "Happy" },
  5: { emoji: "😄", label: "Very Happy" },
};

interface CheckInWithTips {
  id: number;
  child_id: number;
  emotion_rating: number;
  notes?: string;
  created_at: string;
  cached_tip?: {
    id: number;
    check_in_id: number;
    ai_tip: string;
    habit_suggestion: string;
    is_tip_personalized: boolean;
    tip_score?: number;
    created_at: string;
    updated_at: string;
  };
}

export default function CheckInHistory() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const childId = searchParams.get('childId') || '1';
  const [checkIns, setCheckIns] = useState<CheckInWithTips[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCheckInsWithTips();
  }, [childId]);

  const loadCheckInsWithTips = async () => {
    try {
      setLoading(true);
      const data = await checkInsApi.getChildCheckInsWithTips(parseInt(childId));
      setCheckIns(data);
    } catch (error) {
      console.error("Failed to load check-ins with tips:", error);
      toast.error("Failed to load check-in history");
    } finally {
      setLoading(false);
    }
  };

  const extractCleanHabitName = (fullHabitText: string): string => {
    // Clean up the text first - remove any contextual suffixes that might have been added
    let cleanText = fullHabitText.trim();
    
    // Remove common contextual patterns that don't belong in habit names
    cleanText = cleanText.replace(/\s*–\s*(sad|happy|neutral|okay|very sad|very happy),\s*.*$/i, '');
    cleanText = cleanText.replace(/\s*–\s*(after a fall|at bedtime|after school|in the morning|with a sibling|when feeling anxious|when tired|Oct \d+|Dec \d+|Jan \d+|Feb \d+|Mar \d+|Apr \d+|May \d+|Jun \d+|Jul \d+|Aug \d+|Sep \d+|Nov \d+).*$/i, '');
    cleanText = cleanText.replace(/\s*–\s*\d{1,2}\s*(Oct|Dec|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Nov).*$/i, '');
    
    // Prefer explicit "Name – Description" or "Name: Description" formats
    const separators = [' – ', ' — ', ' - ', ': '];
    for (const sep of separators) {
      if (cleanText.includes(sep)) {
        const [name, description] = cleanText.split(sep);
        const cleanedName = name.trim();

        // If the name is already descriptive enough (3+ words), return it
        const nameWordCount = cleanedName.split(/\s+/).length;
        if (nameWordCount >= 3) return cleanedName;

        // Otherwise, enrich with 1-2 distinctive words from the description
        const stopwords = new Set([
          'a','an','the','and','or','but','in','on','at','to','for','of','with','by','from','this','that','these','those','her','his','their','our','your','after','when','each','every','very','more','most','less','into','over','under','about','into','through','together','daily','practice','helps','help','focus','skills','time','child','children','feeling','feelings','emotion','emotions'
        ]);
        const keywords = (description || '')
          .toLowerCase()
          .replace(/[^a-z\s]/g, ' ')
          .split(/\s+/)
          .filter(w => w.length > 3 && !stopwords.has(w))
          .slice(0, 2);

        const enriched = [cleanedName, ...Array.from(new Set(keywords))].join(' ').trim();
        // Cap to 12 words to keep names readable
        return enriched.split(/\s+/).slice(0, 12).join(' ');
      }
    }

    // If it's already short and clean, use as-is
    const words = cleanText.split(/\s+/);
    if (words.length <= 6) return cleanText;

    // Generic fallback: take first 4-5 meaningful words
    const stop = new Set(['a','an','the','and','or','but','in','on','at','to','for','of','with','by','child','children','feeling','feelings']);
    const meaningful = words.filter(w => !stop.has(w.toLowerCase()));
    return meaningful.slice(0, 5).join(' ');
  };

  const handleAddToHabitTracker = (habit: string) => {
    const cleanHabitName = extractCleanHabitName(habit);
    toast.success("Habit added to tracker!");
    navigate(`/add-habit?habitName=${encodeURIComponent(cleanHabitName)}&childId=${childId}`);
  };

  // Fallback functions for when cached tips are not available
  const generateSuggestedHabit = (emotionRating: number, notes: string) => {
    const text = notes.toLowerCase();
    
    // Determine category based on context (similar to backend logic)
    const physicalKeywords = ['tired', 'energy', 'active', 'play', 'run', 'jump', 'dance', 'exercise', 'outdoor', 'park', 'sports', 'movement', 'restless', 'hyper', 'calm down', 'bedtime', 'sleep', 'nap', 'relax', 'stretch', 'yoga', 'walk'];
    const learningKeywords = ['school', 'homework', 'study', 'read', 'book', 'learn', 'curious', 'question', 'creative', 'art', 'draw', 'paint', 'music', 'instrument', 'build', 'explore', 'discover', 'experiment', 'problem', 'challenge', 'academic'];
    const otherKeywords = ['chore', 'clean', 'organize', 'help', 'responsibility', 'independence', 'routine', 'schedule', 'time', 'plan', 'prepare', 'cook', 'garden', 'sibling', 'friend', 'share', 'cooperate', 'listen', 'follow'];
    
    const physicalScore = physicalKeywords.filter(keyword => text.includes(keyword)).length;
    const learningScore = learningKeywords.filter(keyword => text.includes(keyword)).length;
    const otherScore = otherKeywords.filter(keyword => text.includes(keyword)).length;
    
    if (emotionRating <= 2) { // Sad/upset emotions
      if (physicalScore > 0) {
        return "Gentle Movement Break – 5 minutes of stretching or walking to help feel better";
      }
      if (otherScore > 0) {
        return "Helpful Task – Choose one small way to help around the house";
      }
      if (learningScore > 0) {
        return "Creative Expression – Draw or write about how you're feeling";
      }
      return "Calm Breathing – Take 3 deep breaths together when feeling upset";
    } else if (emotionRating >= 4) { // Happy/excited emotions
      if (learningScore > 0) {
        return "Learning Adventure – Explore something new that interests you";
      }
      if (physicalScore > 0) {
        return "Energy Release – Dance, jump, or play actively for 10 minutes";
      }
      if (otherScore > 0) {
        return "Kindness Mission – Do something nice for someone else";
      }
      return "Gratitude Moment – Share one thing you're thankful for today";
    } else { // Neutral emotions
      if (learningScore > physicalScore && learningScore > otherScore) {
        return "Curiosity Quest – Ask questions about something you want to learn";
      }
      if (physicalScore > otherScore) {
        return "Active Play – 15 minutes of movement or outdoor time";
      }
      if (otherScore > 0) {
        return "Responsibility Practice – Complete one helpful task independently";
      }
      return "Daily Check-in – Spend 5 minutes talking about your day";
    }
  };

  const generateAITip = (emotionRating: number, notes: string) => {
    if (emotionRating <= 2) {
      return "It's important to acknowledge difficult emotions. Try validating their feelings and offering comfort through your presence and understanding.";
    } else if (emotionRating >= 4) {
      return "Celebrate these positive moments! Ask about what specifically made them happy to reinforce positive experiences.";
    }
    return "Mixed emotions are completely normal. Continue providing consistent support and emotional validation.";
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F1F0FB] flex flex-col">
        <header className="px-6 pt-8 pb-4 flex items-center space-x-3">
        <button
          onClick={() => navigate("/my-nest")}
          className="text-[#323D52] hover:opacity-80 transition-opacity flex items-center"
        >
          <ArrowLeft size={28} />
        </button>
          <h1 className="text-2xl md:text-3xl font-bold text-[#323D52] flex-1 text-center pr-8">
            CHECK IN HISTORY
          </h1>
        </header>
        <main className="flex-1 px-6 pb-8 flex items-center justify-center">
          <div className="text-[#323D52]">Loading check-in history...</div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F1F0FB] flex flex-col">
      {/* Header */}
      <header className="px-6 pt-8 pb-4 flex items-center space-x-3">
        <button
          onClick={() => navigate("/my-nest")}
          className="text-[#323D52] hover:opacity-80 transition-opacity flex items-center"
          aria-label="Back"
        >
          <ArrowLeft size={28} />
        </button>
        <h1 className="text-2xl md:text-3xl font-bold text-[#323D52] flex-1 text-center pr-8">
          CHECK IN HISTORY
        </h1>
      </header>
      
      {/* Content */}
      <main className="flex-1 px-6 pb-8">
        <div className="max-w-xl mx-auto space-y-6">
          {checkIns.length === 0 ? (
            <p className="text-center text-[#8E9196] mt-16 text-lg font-medium">
              No check-ins yet. Your history will appear here.
            </p>
          ) : (
            <ul className="space-y-6">
              {checkIns.map((checkIn) => {
                const emotionData = emojiMap[checkIn.emotion_rating] || emojiMap[3];
                
                // Use cached tips if available, otherwise fall back to static generation
                const aiTip = checkIn.cached_tip?.ai_tip || generateAITip(checkIn.emotion_rating, checkIn.notes || '');
                const suggestedHabit = checkIn.cached_tip?.habit_suggestion || generateSuggestedHabit(checkIn.emotion_rating, checkIn.notes || '');
                
                return (
                  <li
                    key={checkIn.id}
                    className="bg-[#FFF9E5] rounded-xl shadow-md border border-[#AED9E0]/40 overflow-hidden"
                  >
                    {/* Header with emotion and date */}
                    <div className="p-5 flex items-center space-x-5 border-b border-[#AED9E0]/20">
                      <div className="flex flex-col items-center w-20">
                        <span className="text-4xl">{emotionData.emoji}</span>
                        <span className="text-xs text-[#8E9196] mt-1">{emotionData.label}</span>
                      </div>
                      <div className="flex-1">
                        <span className="text-sm font-bold text-[#FFD95A]">
                          {new Date(checkIn.created_at).toLocaleDateString(undefined, {
                            month: "short",
                            day: "numeric",
                            year: "numeric"
                          })}
                        </span>
                        <div className="text-[#323D52] text-base font-medium">
                          {checkIn.notes || 'No notes added'}
                        </div>
                      </div>
                    </div>
                    
                    {/* Extended content section */}
                    <div className="p-5 bg-white">
                      {/* AI Tip */}
                      <div className="mb-4 bg-[#F1F0FB] p-4 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="text-sm uppercase text-[#9b87f5] font-semibold">
                            {checkIn.cached_tip?.is_tip_personalized ? 'Personalized AI Tip' : 'Suggested Tip'}
                          </h3>
                          {checkIn.cached_tip?.is_tip_personalized && (
                            <span className="text-xs bg-[#9b87f5] text-white px-2 py-1 rounded-full">
                              AI Enhanced
                            </span>
                          )}
                        </div>
                        <p className="text-[#323D52] italic">{aiTip}</p>
                      </div>
                      
                      {/* Suggested Habit */}
                      <div className="bg-[#E6F4F1] p-4 rounded-lg">
                        <h3 className="text-sm uppercase text-[#5E9FA3] font-semibold mb-2">Suggested Habit</h3>
                        <p className="text-[#323D52] font-medium mb-3">{suggestedHabit}</p>
                        
                        <Button
                          onClick={() => handleAddToHabitTracker(suggestedHabit)}
                          className="bg-[#5E9FA3] hover:bg-[#4A8085] text-white"
                          size="sm"
                        >
                          <Plus size={16} className="mr-1" /> Add to Habit Tracker
                        </Button>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </main>
    </div>
  );
}
