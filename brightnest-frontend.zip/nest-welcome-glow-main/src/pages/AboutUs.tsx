
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { FeedbackButton } from "@/components/feedback/FeedbackButton";

const AboutUs = () => {
  const navigate = useNavigate();
  
  const handleGoBack = () => {
    navigate('/main-menu');
  };

  return (
    <div className="min-h-screen bg-[#FFF9E5] flex flex-col px-6 py-12">
      {/* Header */}
      <header>
        <button 
          onClick={handleGoBack} 
          className="text-[#323D52] hover:opacity-80 transition-opacity flex items-center gap-2"
        >
          <ArrowLeft size={24} />
          Back
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col py-8 max-w-md mx-auto w-full">
        <h1 className="text-2xl font-bold text-[#323D52] mb-8 text-center">ABOUT US</h1>
        
        <section className="mb-8">
          <h2 className="text-xl font-semibold text-[#323D52] mb-3">🌱 About BrightNest</h2>
          <p className="text-[#323D52] leading-relaxed mb-4">
            BrightNest was born out of a simple question: 
            "What if we could help children grow up mentally strong, starting from day one?"
          </p>
          <p className="text-[#323D52] leading-relaxed mb-4">
            I've always wanted to create something that made people's lives better. Leave a legacy if you will — especially for those who don't always have the easiest start. BrightNest is my way of supporting children, and the parents, carers, and educators who guide them. BrightNest is my way of making the world a better place.
          </p>
          <p className="text-[#323D52] leading-relaxed">
            This app is for the quiet moments — when you're trying to figure out what your child's mood means, what to do next, or how to make tomorrow a little brighter.
          </p>
        </section>
        
        <section className="mb-8">
          <h2 className="text-xl font-semibold text-[#323D52] mb-3">💛 Our Mission</h2>
          
          <h3 className="font-medium text-[#323D52] mb-2">Right now (MVP):</h3>
          <p className="text-[#323D52] leading-relaxed mb-4">
            To give caregivers and parents a gentle, easy-to-use daily space where they can track how a child feels, receive emotional guidance, and build supportive habits that grow with them.
          </p>
          
          <h3 className="font-medium text-[#323D52] mb-2">In the long run:</h3>
          <p className="text-[#323D52] leading-relaxed">
            To become a trusted early mental health companion — one that uses smart technology to provide real, human-centered guidance, before things ever become overwhelming.
          </p>
        </section>
        
        <section className="mb-8">
          <h2 className="text-xl font-semibold text-[#323D52] mb-3">🌼 Why I Started BrightNest</h2>
          <p className="text-[#323D52] leading-relaxed mb-4">
            Because I believe children are shaped by what happens in their earliest years — and if we can give them support, care and love then, we can help prevent many struggles later in life.
          </p>
          <p className="text-[#323D52] leading-relaxed mb-4">
            Because not every child grows up in a perfect home, and not every parent has all the tools — and that's okay. BrightNest is here to help, every day, in small but powerful ways.
          </p>
          <p className="text-[#323D52] leading-relaxed mb-4">
            Because I have a child of my own. A beautiful daughter that made my life better from the moment she was born and has been making it better every day since. BrightNest is my way of creating a better society for her to grow up in.
          </p>
          <p className="text-[#323D52] leading-relaxed italic">
            With care,<br />
            Mihai Pasol, Founder of BrightNest
          </p>
        </section>
        
        <button 
          onClick={handleGoBack}
          className="mx-auto bg-[#323D52] text-white py-3 px-6 rounded-lg text-center font-semibold hover:bg-[#323D52]/90 transition-colors mt-4"
        >
          Back to Menu
        </button>
      </main>

      {/* Feedback Button */}
      <FeedbackButton />
    </div>
  );
};

export default AboutUs;
