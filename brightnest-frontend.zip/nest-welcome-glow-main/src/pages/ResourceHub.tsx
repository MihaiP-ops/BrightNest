
import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Search, 
  Filter, 
  BookOpen, 
  Video, 
  FileText, 
  Download,
  Clock,
  User,
  Star,
  ExternalLink,
  ArrowLeft
} from 'lucide-react';
import { resources } from '@/lib/api';

interface ResourceCategory {
  id: number;
  name: string;
  description: string;
  icon: string;
  color: string;
}

interface Resource {
  id: number;
  title: string;
  description: string;
  content?: string;
  resource_type: 'article' | 'video' | 'pdf' | 'guide';
  url?: string;
  file_path?: string;
  thumbnail_url?: string;
  category: ResourceCategory;
  min_age?: number;
  max_age?: number;
  tags?: string;
  author?: string;
  read_time_minutes?: number;
  difficulty_level?: string;
  is_featured: boolean;
  view_count: number;
}

const ResourceTypeIcon = ({ type }: { type: string }) => {
  switch (type) {
    case 'article':
      return <BookOpen className="h-4 w-4" />;
    case 'video':
      return <Video className="h-4 w-4" />;
    case 'pdf':
      return <FileText className="h-4 w-4" />;
    case 'guide':
      return <Download className="h-4 w-4" />;
    default:
      return <BookOpen className="h-4 w-4" />;
  }
};

const ResourceCard = ({ resource }: { resource: Resource }) => {
  const handleResourceClick = () => {
    // For videos, open the URL directly (e.g., YouTube)
    if (resource.resource_type === 'video' && resource.url) {
      window.open(resource.url, '_blank');
    }
    // For articles with content, navigate to detail page
    else if (resource.resource_type === 'article' && resource.content) {
      window.location.href = `/resource/${resource.id}`;
    } 
    // For external URLs (guides, PDFs, etc.)
    else if (resource.url) {
      window.open(resource.url, '_blank');
    } 
    // For local files
    else if (resource.file_path) {
      window.open(resource.file_path, '_blank');
    } 
    // Fallback: navigate to detail page for any resource
    else {
      window.location.href = `/resource/${resource.id}`;
    }
  };

  return (
    <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={handleResourceClick}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <ResourceTypeIcon type={resource.resource_type} />
            <Badge variant="secondary" style={{ backgroundColor: resource.category.color + '20', color: resource.category.color }}>
              {resource.category.name}
            </Badge>
            {resource.is_featured && (
              <Badge variant="default" className="bg-yellow-100 text-yellow-800 border-yellow-300">
                <Star className="h-3 w-3 mr-1" />
                Featured
              </Badge>
            )}
          </div>
          {(resource.url || resource.file_path) && (
            <ExternalLink className="h-4 w-4 text-gray-400" />
          )}
        </div>
        <CardTitle className="text-lg leading-tight">{resource.title}</CardTitle>
        <CardDescription className="text-sm">
          {resource.description}
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex items-center justify-between text-xs text-gray-500">
          <div className="flex items-center gap-4">
            {resource.author && (
              <div className="flex items-center gap-1">
                <User className="h-3 w-3" />
                <span>{resource.author}</span>
              </div>
            )}
            {resource.read_time_minutes && (
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                <span>{resource.read_time_minutes} min</span>
              </div>
            )}
          </div>
          <div className="flex items-center gap-2">
            {resource.min_age && resource.max_age && (
              <Badge variant="outline" className="text-xs">
                Ages {resource.min_age}-{resource.max_age}
              </Badge>
            )}
            {resource.difficulty_level && (
              <Badge variant="outline" className="text-xs capitalize">
                {resource.difficulty_level}
              </Badge>
            )}
          </div>
        </div>
        {resource.tags && (
          <div className="flex flex-wrap gap-1 mt-2">
            {resource.tags.split(',').slice(0, 3).map((tag, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {tag.trim()}
              </Badge>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

const CategoryCard = ({ category, isSelected, onClick }: { 
  category: ResourceCategory; 
  isSelected: boolean;
  onClick: () => void;
}) => (
  <Card 
    className={`cursor-pointer transition-all ${isSelected ? 'ring-2 ring-blue-500' : 'hover:shadow-md'}`}
    onClick={onClick}
  >
    <CardContent className="p-4 text-center">
      <div 
        className="w-12 h-12 rounded-full mx-auto mb-2 flex items-center justify-center text-white font-semibold"
        style={{ backgroundColor: category.color }}
      >
        {category.name.charAt(0)}
      </div>
      <h3 className="font-semibold text-sm">{category.name}</h3>
      <p className="text-xs text-gray-500 mt-1">{category.description}</p>
    </CardContent>
  </Card>
);

export default function ResourceHub() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [categories, setCategories] = useState<ResourceCategory[]>([]);
  const [resourcesList, setResourcesList] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState(searchParams.get('search') || '');
  const [selectedCategory, setSelectedCategory] = useState<number | null>(
    searchParams.get('category') ? parseInt(searchParams.get('category')!) : null
  );
  const [resourceType, setResourceType] = useState<string>(searchParams.get('type') || 'all');
  const [minAge, setMinAge] = useState<string>(searchParams.get('min_age') || '');
  const [maxAge, setMaxAge] = useState<string>(searchParams.get('max_age') || '');
  const [showFeatured, setShowFeatured] = useState(searchParams.get('featured') === 'true');

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    loadResources();
  }, [selectedCategory, resourceType, minAge, maxAge, showFeatured, searchTerm]);

  const loadData = async () => {
    try {
      setLoading(true);
      console.log('Loading resource hub data...');
      const [categoriesData, resourcesData] = await Promise.all([
        resources.getCategories(),
        resources.getResources({ limit: 20 })
      ]);
      console.log('Categories loaded:', categoriesData);
      console.log('Resources loaded:', resourcesData);
      setCategories(categoriesData);
      setResourcesList(resourcesData);
    } catch (error) {
      console.error('Error loading resource hub data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadResources = async () => {
    try {
      const params: any = { limit: 20 };
      
      if (selectedCategory) params.category_id = selectedCategory;
      if (resourceType !== 'all') params.resource_type = resourceType;
      if (minAge) params.min_age = parseInt(minAge);
      if (maxAge) params.max_age = parseInt(maxAge);
      if (showFeatured) params.is_featured = true;
      if (searchTerm.trim()) params.search = searchTerm.trim();

      const resourcesData = await resources.getResources(params);
      setResourcesList(resourcesData);
      
      // Update URL params
      const newSearchParams = new URLSearchParams();
      if (selectedCategory) newSearchParams.set('category', selectedCategory.toString());
      if (resourceType !== 'all') newSearchParams.set('type', resourceType);
      if (minAge) newSearchParams.set('min_age', minAge);
      if (maxAge) newSearchParams.set('max_age', maxAge);
      if (showFeatured) newSearchParams.set('featured', 'true');
      if (searchTerm.trim()) newSearchParams.set('search', searchTerm.trim());
      
      setSearchParams(newSearchParams);
    } catch (error) {
      console.error('Error loading resources:', error);
    }
  };

  const handleCategorySelect = (categoryId: number | null) => {
    setSelectedCategory(categoryId);
  };

  const clearFilters = () => {
    setSelectedCategory(null);
    setResourceType('all');
    setMinAge('');
    setMaxAge('');
    setShowFeatured(false);
    setSearchTerm('');
    setSearchParams({});
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-8">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 rounded"></div>
            ))}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-48 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const featuredResources = resourcesList.filter(r => r.is_featured);
  const regularResources = resourcesList.filter(r => !r.is_featured);

  return (
    <div className="container mx-auto p-6 space-y-8">
      {/* Back Button */}
        <Button
        variant="ghost" 
        onClick={() => navigate('/landing')}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 p-0 h-auto"
        >
        <ArrowLeft className="h-4 w-4" />
          Back
        </Button>
        
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-gray-900">Parent Resource Hub</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Discover expert-curated articles, guides, and tools to support your child's development and well-being.
        </p>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search resources by title, description, or tags..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="flex flex-wrap gap-4 items-center">
          <Select value={resourceType} onValueChange={setResourceType}>
            <SelectTrigger className="w-40">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="article">Articles</SelectItem>
              <SelectItem value="video">Videos</SelectItem>
              <SelectItem value="pdf">PDFs</SelectItem>
              <SelectItem value="guide">Guides</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex gap-2">
            <Input
              placeholder="Min age"
              value={minAge}
              onChange={(e) => setMinAge(e.target.value)}
              className="w-20"
              type="number"
            />
            <Input
              placeholder="Max age"
              value={maxAge}
              onChange={(e) => setMaxAge(e.target.value)}
              className="w-20"
              type="number"
            />
          </div>

          <Button
            variant={showFeatured ? "default" : "outline"}
            onClick={() => setShowFeatured(!showFeatured)}
            size="sm"
          >
            <Star className="h-4 w-4 mr-1" />
            Featured
          </Button>

          {(selectedCategory || resourceType !== 'all' || minAge || maxAge || showFeatured || searchTerm) && (
            <Button variant="ghost" onClick={clearFilters} size="sm">
              Clear Filters
            </Button>
                                  )}
                                </div>
                              </div>

      {/* Categories */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Browse by Category</h2>
        <div className="text-sm text-gray-500 mb-2">Debug: {categories.length} categories loaded</div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
          <CategoryCard
            category={{
              id: 0,
              name: 'All',
              description: 'View all resources',
              icon: '',
              color: '#6b7280'
            }}
            isSelected={selectedCategory === null}
            onClick={() => handleCategorySelect(null)}
          />
          {categories.map(category => (
            <CategoryCard
              key={category.id}
              category={category}
              isSelected={selectedCategory === category.id}
              onClick={() => handleCategorySelect(category.id)}
            />
          ))}
                          </div>
                    </div>
                    
      {/* Resources */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList>
          <TabsTrigger value="all">All Resources ({resourcesList.length})</TabsTrigger>
          {featuredResources.length > 0 && (
            <TabsTrigger value="featured">Featured ({featuredResources.length})</TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="all" className="space-y-6">
          {featuredResources.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <Star className="h-5 w-5 mr-2 text-yellow-500" />
                Featured Resources
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {featuredResources.map(resource => (
                  <ResourceCard key={resource.id} resource={resource} />
                ))}
                        </div>
                      </div>
                    )}
                    
          {regularResources.length > 0 && (
                        <div>
              <h3 className="text-lg font-semibold mb-4">All Resources</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {regularResources.map(resource => (
                  <ResourceCard key={resource.id} resource={resource} />
                ))}
                    </div>
                  </div>
                )}

          {resourcesList.length === 0 && (
            <div className="text-center py-12">
              <BookOpen className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No resources found</h3>
              <p className="text-gray-500">Try adjusting your search terms or filters.</p>
        </div>
          )}
        </TabsContent>

        <TabsContent value="featured">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredResources.map(resource => (
              <ResourceCard key={resource.id} resource={resource} />
            ))}
        </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
