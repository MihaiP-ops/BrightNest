import { BarChart3, Users, CalendarCheck, Check, User, ArrowLeft } from "lucide-react";
import { Logo } from "@/components/Logo";
import { Link, useNavigate, useParams } from "react-router-dom";
import { DashboardContent } from "@/components/dashboard/DashboardContent";
import { FeedbackButton } from "@/components/feedback/FeedbackButton";
import { useState, useEffect } from "react";
import { children as childrenApi, habits as habitsApi } from "@/lib/api";
import { toast } from "sonner";

interface Child {
  id: number;
  name: string;
  age: number;
  photo_url?: string;
}

const ChildDashboard = () => {
  const navigate = useNavigate();
  const { childId } = useParams();
  const [child, setChild] = useState<Child | null>(null);
  const [habits, setHabits] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (childId) {
      loadData(parseInt(childId));
    }
  }, [childId]);

  const loadData = async (id: number) => {
    try {
      const [childData, backendHabits] = await Promise.all([
        childrenApi.getOne(id),
        habitsApi.getChildHabitsWithCompletions(id)
      ]);
      setChild(childData);
      
      // Transform backend habits to frontend format
      const transformedHabits = backendHabits.map((habit: any) => ({
        id: habit.id,
        name: habit.name,
        progress: habit.completed_days || 0,
        total: habit.total_days,
        childId: habit.child_id.toString(),
        completedDaysDetail: habit.completed_days_detail || []  // Add detailed completion data
      }));
      
      setHabits(transformedHabits);
    } catch (error) {
      console.error("Failed to load data:", error);
      toast.error("Failed to load data");
      navigate("/my-nest");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoBack = () => {
    navigate('/my-nest');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FFF9E5] flex items-center justify-center">
        <div className="text-[#323D52] text-lg">Loading...</div>
      </div>
    );
  }

  if (!child) {
    return (
      <div className="min-h-screen bg-[#FFF9E5] flex items-center justify-center">
        <div className="text-[#323D52] text-lg">Child not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF9E5] flex flex-col">
      {/* Header with Logo and Profile */}
      <header className="px-6 pt-8 pb-4 flex justify-between items-center">
        <button 
          onClick={handleGoBack} 
          className="text-[#323D52] hover:opacity-80 transition-opacity flex items-center gap-2"
        >
          <ArrowLeft size={24} />
          Back
        </button>
        <div className="w-20">
          <Logo />
        </div>
        <button className="text-[#323D52] hover:opacity-80 transition-opacity">
          <User size={28} />
        </button>
      </header>

      {/* Child Info */}
      <div className="px-6 py-4">
        <h1 className="text-2xl font-bold text-[#323D52]">{child.name}'s Dashboard</h1>
        <p className="text-[#323D52]/60">Age: {child.age}</p>
      </div>

      {/* Quick Actions - Moved to top for better visibility */}
      <div className="px-6 py-4 bg-white/50 border-b border-white/30">
        <div className="flex gap-4 justify-center">
          <button
            onClick={() => navigate(`/add-habit?childId=${childId}`)}
            className="px-6 py-3 bg-[#C7F2C4] text-[#323D52] rounded-lg hover:opacity-90 transition-opacity font-medium shadow-sm"
          >
            Add Habit
          </button>
          <button
            onClick={() => navigate(`/check-in?childId=${childId}`)}
            className="px-6 py-3 bg-[#D6C7F7] text-[#323D52] rounded-lg hover:opacity-90 transition-opacity font-medium shadow-sm"
          >
            New Check-in
          </button>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 px-4 py-6 overflow-auto">
        <DashboardContent childId={childId} habits={habits} />
      </main>

      {/* Feedback Button */}
      <FeedbackButton />

      {/* Bottom Navigation */}
      <nav className="bg-white px-6 py-4 shadow-lg">
        <div className="flex justify-between max-w-sm mx-auto">
          <Link to={`/child-dashboard/${childId}`} className="text-[#323D52] hover:opacity-80 transition-opacity">
            <BarChart3 size={24} />
          </Link>
          <Link to="/my-nest" className="text-[#AED9E0] hover:opacity-80 transition-opacity">
            <Users size={24} />
          </Link>
          <Link to={`/check-in?childId=${childId}`} className="text-[#D6C7F7] hover:opacity-80 transition-opacity">
            <CalendarCheck size={24} />
          </Link>
          <Link to={`/habit-tracker?childId=${childId}`} className="text-[#C7F2C4] hover:opacity-80 transition-opacity">
            <Check size={24} />
          </Link>
        </div>
      </nav>
    </div>
  );
};

export default ChildDashboard;
