import { useState, useEffect } from "react";
import { User, ArrowLeft, UserPlus } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { FeedbackButton } from "@/components/feedback/FeedbackButton";
import { children as childrenApi } from "@/lib/api";

interface Child {
  id: number;
  name: string;
  age: number;
  photo_url?: string;
}

const MyNest = () => {
  const navigate = useNavigate();
  const [children, setChildren] = useState<Child[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isPrivacyDialogOpen, setIsPrivacyDialogOpen] = useState(false);
  const [newChild, setNewChild] = useState<Omit<Child, "id">>({
    name: "",
    age: 0,
    photo_url: ""
  });

  // Load children on component mount
  useEffect(() => {
    loadChildren();
  }, []);

  const loadChildren = async () => {
    try {
      console.log("MyNest: Loading children...");
      const data = await childrenApi.getAll();
      console.log("MyNest: Children loaded successfully:", data);
      setChildren(data);
    } catch (error) {
      console.error("Failed to load children:", error);
      console.error("Error details:", error.response?.data || error.message);
      
      // Check if it's an authentication error
      if (error.response?.status === 401) {
        toast.error("Please log in to view your nest");
        navigate('/signin');
      } else {
        toast.error("Failed to load children");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddChild = async () => {
    if (!newChild.name || newChild.age <= 0) {
      toast.error("Please fill in the name and valid age");
      return;
    }

    try {
      const child = await childrenApi.create(newChild);
      setChildren(prevChildren => [...prevChildren, child]);
      resetChildForm();
      toast.success(`${child.name} has been added to your nest!`);
    } catch (error) {
      console.error("Failed to add child:", error);
      toast.error("Failed to add child");
    }
  };

  const handleDeleteChild = async (childId: number) => {
    try {
      await childrenApi.delete(childId);
      setChildren(prevChildren => prevChildren.filter(child => child.id !== childId));
      toast.success("Child removed from your nest");
    } catch (error) {
      console.error("Failed to delete child:", error);
      toast.error("Failed to remove child");
    }
  };

  const resetChildForm = () => {
    setNewChild({ name: "", age: 0, photo_url: "" });
    setIsDialogOpen(false);
  };

  const handlePrivacyConfirm = () => {
    setIsPrivacyDialogOpen(false);
    setTimeout(() => {
      setIsDialogOpen(true);
    }, 300);
  };

  const handlePrivacyCancel = () => {
    setIsPrivacyDialogOpen(false);
  };

  const openPrivacyDialog = () => {
    setIsPrivacyDialogOpen(true);
  };
  
  const handleChildClick = (childId: number) => {
    navigate(`/child-dashboard/${childId}`);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FFF9E5] flex items-center justify-center">
        <div className="text-[#323D52] text-lg">Loading your nest...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF9E5] flex flex-col px-6 py-12">
      {/* Header */}
      <header>
        <button 
          onClick={() => navigate('/landing')} 
          className="text-[#323D52] hover:opacity-80 transition-opacity flex items-center gap-2"
        >
          <ArrowLeft size={24} />
          Back
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col py-8">
        <h1 className="text-2xl font-bold text-[#323D52] mb-8">MY NEST</h1>
        
        {/* Children Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
          {children.map((child) => (
            <Card 
              key={child.id}
              className="p-4 cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => handleChildClick(child.id)}
            >
              <div className="flex items-center gap-4">
                {child.photo_url ? (
                  <img 
                    src={child.photo_url} 
                    alt={child.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-[#AED9E0] flex items-center justify-center">
                    <User size={32} className="text-[#323D52]" />
                  </div>
                )}
                <div>
                  <h3 className="text-lg font-semibold text-[#323D52]">{child.name}</h3>
                  <p className="text-[#323D52]/80">{child.age} years old</p>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Add Child Button */}
        <Button
          onClick={openPrivacyDialog}
          className="flex items-center gap-2 bg-[#FFD95A] text-[#323D52] hover:bg-[#FFD95A]/90"
        >
          <UserPlus size={20} />
          Add Child
        </Button>
      </main>

      {/* Privacy Dialog */}
      <AlertDialog open={isPrivacyDialogOpen} onOpenChange={setIsPrivacyDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Privacy Notice</AlertDialogTitle>
            <AlertDialogDescription>
              We take your child's privacy seriously. By adding a child to BrightNest, you agree to our privacy policy and consent to the collection and processing of your child's data in accordance with our terms of service.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={handlePrivacyCancel}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handlePrivacyConfirm}>Continue</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Add Child Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Child</DialogTitle>
            <DialogDescription>
              Add your child's details to start tracking their development journey.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={newChild.name}
                onChange={(e) => setNewChild(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Enter child's name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="age">Age</Label>
              <Input
                id="age"
                type="number"
                min="0"
                value={newChild.age || ""}
                onChange={(e) => setNewChild(prev => ({ ...prev, age: parseInt(e.target.value) || 0 }))}
                placeholder="Enter child's age"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="photo">Photo URL (optional)</Label>
              <Input
                id="photo"
                value={newChild.photo_url}
                onChange={(e) => setNewChild(prev => ({ ...prev, photo_url: e.target.value }))}
                placeholder="Enter photo URL"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={resetChildForm}>Cancel</Button>
            <Button onClick={handleAddChild}>Add Child</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Feedback Button */}
      <FeedbackButton />
    </div>
  );
};

export default MyNest;
