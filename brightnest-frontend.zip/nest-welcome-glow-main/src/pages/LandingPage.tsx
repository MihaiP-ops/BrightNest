import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { LogOut, Menu, Heart, CloudSun, Star } from "lucide-react";
import { Logo } from "@/components/Logo";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { FeedbackButton } from "@/components/feedback/FeedbackButton";
import { useAuth } from "@/contexts/AuthContext";

const LandingPage = () => {
  const navigate = useNavigate();
  const { logout, user } = useAuth();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Trigger animation after component mounts
    setIsVisible(true);
  }, []);

  const handleNavigation = (route: string) => {
    navigate(route);
  };

  return (
    <div className="min-h-screen bg-[#FFF9E5] flex flex-col">
      {/* Header */}
      <header className="px-6 pt-8 pb-4 flex justify-between items-center">
        <div className="w-20">
          <Logo />
        </div>
        <div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="text-[#323D52] hover:opacity-80 transition-opacity">
                <Menu size={28} />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 p-2">
              <DropdownMenuItem 
                className="cursor-pointer bg-[#AED9E0] text-[#323D52] font-medium py-3 my-1 rounded-full text-center justify-center hover:bg-[#AED9E0]/90"
                onClick={() => handleNavigation("/my-nest")}
              >
                MY NEST
              </DropdownMenuItem>
              <DropdownMenuSeparator className="my-1" />
              <DropdownMenuItem 
                className="cursor-pointer bg-[#D6C7F7] text-[#323D52] font-medium py-3 my-1 rounded-full text-center justify-center hover:bg-[#D6C7F7]/90"
                onClick={() => handleNavigation("/check-in")}
              >
                CHECK-IN
              </DropdownMenuItem>
              <DropdownMenuSeparator className="my-1" />
              <DropdownMenuItem 
                className="cursor-pointer bg-[#C7F2C4] text-[#323D52] font-medium py-3 my-1 rounded-full text-center justify-center hover:bg-[#C7F2C4]/90"
                onClick={() => handleNavigation("/habit-tracker")}
              >
                HABITS
              </DropdownMenuItem>
              <DropdownMenuSeparator className="my-1" />
              <DropdownMenuItem 
                className="cursor-pointer bg-[#F3D4A0] text-[#323D52] font-medium py-3 my-1 rounded-full text-center justify-center hover:bg-[#F3D4A0]/90"
                onClick={() => handleNavigation("/resource-hub")}
              >
                PARENT RESOURCE HUB
              </DropdownMenuItem>
              <DropdownMenuSeparator className="my-1" />
              <DropdownMenuItem 
                className="cursor-pointer bg-[#FBEACC] text-[#323D52] font-medium py-3 my-1 rounded-full text-center justify-center hover:bg-[#FBEACC]/90"
                onClick={() => handleNavigation("/about-us")}
              >
                ABOUT US
              </DropdownMenuItem>
              <DropdownMenuSeparator className="my-1" />
              <DropdownMenuItem 
                className="cursor-pointer bg-[#FFDEE2] text-[#323D52] font-medium py-3 my-1 rounded-full text-center justify-center hover:bg-[#FFDEE2]/90"
                onClick={logout}
              >
                <LogOut className="mr-2 h-4 w-4" />
                LOG OUT
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      {/* Main Content */}
      <main className={`flex-1 flex flex-col items-center justify-center transition-opacity duration-1000 ease-in-out ${isVisible ? 'opacity-100' : 'opacity-0'} relative z-10`}>
        {/* Welcome Text */}
        <div className="text-center max-w-md animate-fade-in mb-8">
          <h1 className="text-4xl font-bold text-[#F28B9A] mb-4">
            Hi {user?.full_name?.split(' ')[0]},<br/>
            welcome back to<br/>
            BrightNest
          </h1>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-4 w-full max-w-xs animate-fade-in">
          <Button
            onClick={() => handleNavigation("/my-nest")}
            className="w-full bg-[#AED9E0] hover:bg-[#AED9E0]/90 text-[#323D52] font-medium py-6 text-lg rounded-lg shadow-md"
          >
            MY NEST
          </Button>
          <Button
            onClick={() => handleNavigation("/check-in")}
            className="w-full bg-[#33C3F0] hover:bg-[#33C3F0]/90 text-[#323D52] font-medium py-6 text-lg rounded-lg shadow-md"
          >
            CHECK-IN
          </Button>
        </div>
      </main>

      {/* Feedback Button */}
      <FeedbackButton />
    </div>
  );
};

export default LandingPage;
