import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { toast } from "sonner";
import { FeedbackButton } from "@/components/feedback/FeedbackButton";
import { children as childrenApi } from "@/lib/api";

interface Child {
  id: number;
  name: string;
  age: number;
  photo_url?: string;
}

interface HabitTemplate {
  id: string;
  name: string;
  emoji: string;
  category: string;
  defaultFrequency: string;
  defaultTimesPerPeriod: string;
  description: string;
}

const habitTemplates: HabitTemplate[] = [
  {
    id: "brush-teeth",
    name: "Brush teeth",
    emoji: "🦷",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "2",
    description: "Keep those teeth sparkling clean"
  },
  {
    id: "make-bed",
    name: "Make bed",
    emoji: "🛏️",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Start the day by making your bed neat and tidy"
  },
  {
    id: "wash-hands",
    name: "Wash hands",
    emoji: "🧼",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "5",
    description: "Keep hands clean and healthy"
  },
  {
    id: "pack-school-bag",
    name: "Pack school bag",
    emoji: "🎒",
    category: "learning",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Get ready for school the night before"
  },
  {
    id: "read-book",
    name: "Read a book",
    emoji: "📚",
    category: "learning",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Enjoy 15-20 minutes of reading time"
  },
  {
    id: "homework-time",
    name: "Do homework",
    emoji: "✏️",
    category: "learning",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Complete school assignments"
  },
  {
    id: "tidy-up-toys",
    name: "Tidy up toys",
    emoji: "🧸",
    category: "other",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Put toys back where they belong"
  },
  {
    id: "help-with-chores",
    name: "Help with chores",
    emoji: "🧹",
    category: "other",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Lend a helping hand around the house"
  },
  {
    id: "put-dirty-clothes-away",
    name: "Put dirty clothes in hamper",
    emoji: "👕",
    category: "other",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Keep clothes organized and tidy"
  },
  {
    id: "put-on-pjs",
    name: "Put on PJs",
    emoji: "🌙",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Get ready for bedtime"
  },
  {
    id: "morning-cuddle",
    name: "Morning cuddle/check-in",
    emoji: "🤗",
    category: "emotional",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Start the day with love and connection"
  },
  {
    id: "say-thank-you",
    name: "Say thank you",
    emoji: "🙏",
    category: "emotional",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "3",
    description: "Express gratitude to others"
  },
  {
    id: "share-feelings",
    name: "Share feelings",
    emoji: "💭",
    category: "emotional",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Talk about how you're feeling today"
  },
  {
    id: "eat-breakfast",
    name: "Eat breakfast",
    emoji: "🥞",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Fuel up for the day ahead"
  },
  {
    id: "drink-water",
    name: "Drink water",
    emoji: "💧",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "4",
    description: "Stay hydrated throughout the day"
  },
  {
    id: "outdoor-play",
    name: "Play outside",
    emoji: "🌳",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Get fresh air and exercise outdoors"
  },
  {
    id: "mindful-breathing",
    name: "Mindful breathing",
    emoji: "🧘",
    category: "emotional",
    defaultFrequency: "weekly",
    defaultTimesPerPeriod: "3",
    description: "Take deep breaths and find calm"
  },
  {
    id: "kind-words-sibling",
    name: "Kind words to sibling",
    emoji: "💝",
    category: "emotional",
    defaultFrequency: "weekly",
    defaultTimesPerPeriod: "2",
    description: "Share love with brothers and sisters"
  },
  {
    id: "practice-instrument",
    name: "Practice instrument",
    emoji: "🎵",
    category: "learning",
    defaultFrequency: "weekly",
    defaultTimesPerPeriod: "4",
    description: "Practice your musical instrument"
  },
  {
    id: "creative-time",
    name: "Creative time",
    emoji: "🎨",
    category: "learning",
    defaultFrequency: "weekly",
    defaultTimesPerPeriod: "3",
    description: "Draw, paint, or create something beautiful"
  }
];

const HabitTracker = () => {
  const navigate = useNavigate();
  const [children, setChildren] = useState<Child[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadChildren();
  }, []);

  const loadChildren = async () => {
    try {
      const data = await childrenApi.getAll();
      setChildren(data);
    } catch (error) {
      console.error("Failed to load children:", error);
      toast.error("Failed to load children");
    } finally {
      setIsLoading(false);
    }
  };

  const handleBack = () => {
    navigate("/landing");
  };

  const handleTemplateSelect = (template: HabitTemplate) => {
    if (children.length === 0) {
      toast.error("Please add a child to your nest first");
      navigate("/my-nest");
      return;
    }
    
    if (children.length === 1) {
      // If only one child, go directly to add habit with pre-filled template
      navigate(`/add-habit?habitName=${encodeURIComponent(template.name)}&childId=${children[0].id}`);
    } else {
      // If multiple children, just go to add habit page with the template name
      navigate(`/add-habit?habitName=${encodeURIComponent(template.name)}`);
    }
  };

  const handleAddCustomHabit = () => {
    navigate("/add-habit");
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "physical":
        return "bg-blue-50 border-blue-200";
      case "emotional":
        return "bg-purple-50 border-purple-200";
      case "learning":
        return "bg-green-50 border-green-200";
      case "other":
        return "bg-orange-50 border-orange-200";
      default:
        return "bg-gray-50 border-gray-200";
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FFF9E5] flex items-center justify-center">
        <div className="text-[#323D52] text-lg">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF9E5] flex flex-col">
      <header className="px-6 pt-8 pb-4 flex items-center space-x-3">
        <button
          onClick={handleBack}
          className="text-[#323D52] hover:opacity-80 transition-opacity flex items-center"
          aria-label="Back"
        >
          <ArrowLeft size={28} />
        </button>
        <h1 className="text-2xl md:text-3xl font-bold text-[#323D52] flex-1 text-center pr-8">
          HABITS
        </h1>
      </header>

      <main className="flex-1 px-6 pb-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="text-center text-[#323D52] mb-6">
            <p className="text-lg mb-4">Choose from our preset habits to get started quickly!</p>
            <Button 
              onClick={handleAddCustomHabit}
              className="bg-[#5E9FA3] hover:bg-[#4A8085] text-white font-semibold py-3 px-6"
              size="lg"
            >
              <Plus size={20} className="mr-2" />
              Add Custom Habit
            </Button>
          </div>

          {/* Category Sections */}
          {["physical", "emotional", "learning", "other"].map((category) => {
            const categoryHabits = habitTemplates.filter(h => h.category === category);
            const categoryTitle = category.charAt(0).toUpperCase() + category.slice(1);
            
            return (
              <div key={category} className="space-y-4">
                <h2 className="text-xl font-semibold text-[#323D52] capitalize">
                  {categoryTitle} Habits
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {categoryHabits.map((template) => (
                    <Card 
                      key={template.id}
                      className={`${getCategoryColor(category)} hover:shadow-md cursor-pointer transition-all hover:scale-105`}
                      onClick={() => handleTemplateSelect(template)}
                    >
                      <CardContent className="p-6">
                        <div className="text-center space-y-3">
                          <div className="text-4xl">{template.emoji}</div>
                          <h3 className="text-lg font-semibold text-[#323D52]">
                            {template.name}
                          </h3>
                          <p className="text-sm text-[#323D52]/70">
                            {template.description}
                          </p>
                          <div className="text-xs text-[#323D52]/60 mt-2">
                            {template.defaultTimesPerPeriod}x {template.defaultFrequency}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            );
          })}

          {/* Info section */}
          <div className="text-center mt-8 p-6 bg-white/50 rounded-lg">
            <p className="text-[#323D52]/70 text-sm">
              Click on any habit above to add it to your child's routine, or create your own custom habit!
            </p>
          </div>
        </div>
      </main>

      <FeedbackButton />
    </div>
  );
};

export default HabitTracker;
