
import React, { useEffect } from 'react';
import { Onboarding } from '@/components/onboarding/Onboarding';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

const OnboardingPage = () => {
  const { isFirstTimeUser } = useOnboarding();
  const navigate = useNavigate();

  useEffect(() => {
    // If not first time user and they didn't explicitly choose to restart onboarding,
    // redirect to main menu
    if (!isFirstTimeUser) {
      navigate('/main-menu');
    }
  }, [isFirstTimeUser, navigate]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="min-h-screen"
    >
      <Onboarding />
    </motion.div>
  );
};

export default OnboardingPage;
