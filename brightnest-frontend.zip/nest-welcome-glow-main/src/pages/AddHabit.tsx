import { ArrowLeft, Plus } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { habits } from "@/lib/api";

interface HabitTemplate {
  id: string;
  name: string;
  emoji: string;
  category: string;
  defaultFrequency: string;
  defaultTimesPerPeriod: string;
  description: string;
}

const habitTemplates: HabitTemplate[] = [
  {
    id: "brush-teeth",
    name: "Brush teeth",
    emoji: "🦷",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "2",
    description: "Keep those teeth sparkling clean"
  },
  {
    id: "make-bed",
    name: "Make bed",
    emoji: "🛏️",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Start the day by making your bed neat and tidy"
  },
  {
    id: "wash-hands",
    name: "Wash hands",
    emoji: "🧼",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "5",
    description: "Keep hands clean and healthy"
  },
  {
    id: "pack-school-bag",
    name: "Pack school bag",
    emoji: "🎒",
    category: "learning",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Get ready for school the night before"
  },
  {
    id: "read-book",
    name: "Read a book",
    emoji: "📚",
    category: "learning",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Enjoy 15-20 minutes of reading time"
  },
  {
    id: "homework-time",
    name: "Do homework",
    emoji: "✏️",
    category: "learning",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Complete school assignments"
  },
  {
    id: "tidy-up-toys",
    name: "Tidy up toys",
    emoji: "🧸",
    category: "other",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Put toys back where they belong"
  },
  {
    id: "help-with-chores",
    name: "Help with chores",
    emoji: "🧹",
    category: "other",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Lend a helping hand around the house"
  },
  {
    id: "put-dirty-clothes-away",
    name: "Put dirty clothes in hamper",
    emoji: "👕",
    category: "other",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Keep clothes organized and tidy"
  },
  {
    id: "put-on-pjs",
    name: "Put on PJs",
    emoji: "🌙",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Get ready for bedtime"
  },
  {
    id: "morning-cuddle",
    name: "Morning cuddle/check-in",
    emoji: "🤗",
    category: "emotional",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Start the day with love and connection"
  },
  {
    id: "say-thank-you",
    name: "Say thank you",
    emoji: "🙏",
    category: "emotional",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "3",
    description: "Express gratitude to others"
  },
  {
    id: "share-feelings",
    name: "Share feelings",
    emoji: "💭",
    category: "emotional",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Talk about how you're feeling today"
  },
  {
    id: "eat-breakfast",
    name: "Eat breakfast",
    emoji: "🥞",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Fuel up for the day ahead"
  },
  {
    id: "drink-water",
    name: "Drink water",
    emoji: "💧",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "4",
    description: "Stay hydrated throughout the day"
  },
  {
    id: "outdoor-play",
    name: "Play outside",
    emoji: "🌳",
    category: "physical",
    defaultFrequency: "daily",
    defaultTimesPerPeriod: "1",
    description: "Get fresh air and exercise outdoors"
  },
  {
    id: "mindful-breathing",
    name: "Mindful breathing",
    emoji: "🧘",
    category: "emotional",
    defaultFrequency: "weekly",
    defaultTimesPerPeriod: "3",
    description: "Take deep breaths and find calm"
  },
  {
    id: "kind-words-sibling",
    name: "Kind words to sibling",
    emoji: "💝",
    category: "emotional",
    defaultFrequency: "weekly",
    defaultTimesPerPeriod: "2",
    description: "Share love with brothers and sisters"
  },
  {
    id: "practice-instrument",
    name: "Practice instrument",
    emoji: "🎵",
    category: "learning",
    defaultFrequency: "weekly",
    defaultTimesPerPeriod: "4",
    description: "Practice your musical instrument"
  },
  {
    id: "creative-time",
    name: "Creative time",
    emoji: "🎨",
    category: "learning",
    defaultFrequency: "weekly",
    defaultTimesPerPeriod: "3",
    description: "Draw, paint, or create something beautiful"
  }
];

export default function AddHabit() {
  const navigate = useNavigate();
  const location = useLocation();
  
  const [selectedTemplate, setSelectedTemplate] = useState<HabitTemplate | null>(null);
  const [showCustomForm, setShowCustomForm] = useState(false);
  
  // Form state
  const [habitName, setHabitName] = useState("");
  const [frequency, setFrequency] = useState("daily");
  const [reward, setReward] = useState("virtual_pet");
  const [customRewardName, setCustomRewardName] = useState("");
  const [timesPerPeriod, setTimesPerPeriod] = useState("1");
  const [category, setCategory] = useState("emotional");
  const [childId, setChildId] = useState<string | null>(null);

  // Function to determine category based on habit name
  const determineCategoryFromHabitName = (habitName: string): string => {
    const text = habitName.toLowerCase();
    
    // Physical activity keywords
    const physicalKeywords = [
      'movement', 'exercise', 'stretch', 'walk', 'run', 'jump', 'dance', 'play', 'active',
      'energy', 'calm down', 'relax', 'breathing', 'yoga', 'sports', 'outdoor', 'bedtime',
      'sleep', 'nap', 'tired', 'restless', 'hyper'
    ];
    
    // Learning/curiosity keywords
    const learningKeywords = [
      'learn', 'study', 'read', 'book', 'creative', 'art', 'draw', 'paint', 'music',
      'instrument', 'build', 'explore', 'discover', 'experiment', 'question', 'curious',
      'adventure', 'quest', 'academic', 'homework', 'school'
    ];
    
    // Practical life skills keywords
    const otherKeywords = [
      'chore', 'help', 'responsibility', 'independence', 'routine', 'schedule', 'plan',
      'prepare', 'cook', 'garden', 'sibling', 'friend', 'share', 'cooperate', 'listen',
      'follow', 'champion', 'task', 'mission', 'practice', 'organize', 'clean'
    ];
    
    // Emotional keywords
    const emotionalKeywords = [
      'feelings', 'emotion', 'mood', 'gratitude', 'thankful', 'grateful', 'breathing',
      'mindful', 'calm', 'upset', 'sad', 'happy', 'excited', 'proud', 'worried',
      'anxious', 'scared', 'frustrated', 'angry', 'check-in', 'chat', 'expression'
    ];
    
    const physicalScore = physicalKeywords.filter(keyword => text.includes(keyword)).length;
    const learningScore = learningKeywords.filter(keyword => text.includes(keyword)).length;
    const otherScore = otherKeywords.filter(keyword => text.includes(keyword)).length;
    const emotionalScore = emotionalKeywords.filter(keyword => text.includes(keyword)).length;
    
    // Return the category with the highest score
    if (otherScore > physicalScore && otherScore > learningScore && otherScore > emotionalScore) {
      return "other";
    } else if (physicalScore > learningScore && physicalScore > emotionalScore) {
      return "physical";
    } else if (learningScore > emotionalScore) {
      return "learning";
    } else {
      return "emotional"; // Default fallback
    }
  };

  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);
    const habitNameParam = queryParams.get("habitName");
    const childIdParam = queryParams.get("childId");
    
    // Debug logging
    console.log("AddHabit useEffect - childIdParam:", childIdParam);
    console.log("AddHabit useEffect - habitNameParam:", habitNameParam);
    
    // Always set childId if available in URL, even if already set in state
    if (childIdParam) {
      setChildId(childIdParam);
      console.log("AddHabit useEffect - Setting childId to:", childIdParam);
    } else {
      console.log("AddHabit useEffect - No childId found in URL parameters");
    }
    
    if (habitNameParam) {
      setHabitName(habitNameParam);
      setShowCustomForm(true);
      
      // Auto-detect and set the category based on the habit name
      const detectedCategory = determineCategoryFromHabitName(habitNameParam);
      setCategory(detectedCategory);
      console.log("AddHabit useEffect - Auto-detected category:", detectedCategory);
    }
  }, [location.search]); // Remove childId from dependency to avoid infinite loops

  const handleTemplateSelect = (template: HabitTemplate) => {
    console.log("handleTemplateSelect - template:", template.name);
    
    setSelectedTemplate(template);
    setHabitName(template.name);
    setCategory(template.category);
    setFrequency(template.defaultFrequency);
    setTimesPerPeriod(template.defaultTimesPerPeriod);
    setShowCustomForm(true);
    
    // Get childId from current URL if not in state
    const queryParams = new URLSearchParams(location.search);
    const urlChildId = queryParams.get("childId");
    const currentChildId = childId || urlChildId;
    
    // Preserve childId in URL when switching to custom form
    if (currentChildId) {
      const newUrl = `/add-habit?childId=${currentChildId}&habitName=${encodeURIComponent(template.name)}`;
      window.history.replaceState(null, '', newUrl);
      
      // Also update the state if it wasn't set
      if (!childId) {
        setChildId(currentChildId);
        console.log("handleTemplateSelect - setting childId state to:", currentChildId);
      }
    } else {
      console.error("handleTemplateSelect - No childId available!");
    }
  };

  const handleCreateCustom = () => {
    setSelectedTemplate(null);
    setHabitName("");
    setCategory("emotional");
    setFrequency("daily");
    setTimesPerPeriod("1");
    setShowCustomForm(true);
  };

  const handleBackToTemplates = () => {
    setShowCustomForm(false);
    setSelectedTemplate(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!habitName.trim()) {
      toast.error("Please enter a habit name");
      return;
    }
    
    if (reward === "custom" && !customRewardName.trim()) {
      toast.error("Please enter a custom reward name");
      return;
    }

    if (!childId) {
      toast.error("Child ID is required to create a habit");
      return;
    }

    try {
      // Map frequency to total_days for backend
      let totalDays = 7; // Default to weekly
      const timesPerPeriodNum = parseInt(timesPerPeriod) || 1;
      
      switch (frequency) {
        case "daily":
          totalDays = timesPerPeriodNum * 7; // Times per day * 7 days
          break;
        case "weekly":
          totalDays = timesPerPeriodNum; // Times per week
          break;
        case "hourly":
          totalDays = timesPerPeriodNum * 24 * 7; // Times per hour * 24 hours * 7 days
          break;
      }

      // Create habit description with reward info
      let rewardName = "";
      switch (reward) {
        case "virtual_pet":
          rewardName = "Virtual Pet";
          break;
        case "badges":
          rewardName = "Achievement Badge";
          break;
        case "points":
          rewardName = "Points";
          break;
        case "custom":
          rewardName = customRewardName.trim();
          break;
      }

      const description = `Category: ${category}, Frequency: ${frequency} (${timesPerPeriod} times), Reward: ${rewardName}`;

      // Create habit via backend API
      await habits.create({
        name: habitName.trim(),
        description: description,
        total_days: totalDays,
        child_id: parseInt(childId)
      });

      toast.success("New habit created successfully!");
      navigate(`/child-dashboard/${childId}`);
      
    } catch (error) {
      console.error("Failed to create habit:", error);
      toast.error("Failed to create habit. Please try again.");
    }
  };

  const handleBack = () => {
    if (childId) {
      navigate(`/child-dashboard/${childId}`);
    } else {
      navigate("/habit-tracker");
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "physical":
        return "bg-blue-50 border-blue-200";
      case "emotional":
        return "bg-purple-50 border-purple-200";
      case "learning":
        return "bg-green-50 border-green-200";
      case "other":
        return "bg-orange-50 border-orange-200";
      default:
        return "bg-gray-50 border-gray-200";
    }
  };

  if (showCustomForm) {
    return (
      <div className="min-h-screen bg-[#FFF9E5] flex flex-col">
        <header className="px-6 pt-8 pb-4 flex items-center space-x-3">
          <button
            onClick={handleBackToTemplates}
            className="text-[#323D52] hover:opacity-80 transition-opacity flex items-center"
            aria-label="Back to templates"
          >
            <ArrowLeft size={28} />
          </button>
          <h1 className="text-2xl md:text-3xl font-bold text-[#323D52] flex-1 text-center pr-8">
            {selectedTemplate ? `CUSTOMIZE: ${selectedTemplate.emoji} ${selectedTemplate.name.toUpperCase()}` : 'CREATE CUSTOM HABIT'}
          </h1>
        </header>

        <main className="flex-1 px-6 pb-8">
          <div className="max-w-xl mx-auto space-y-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <Card className="bg-white border-[#AED9E0]/40">
                <CardHeader className="pb-3">
                  <h2 className="text-lg font-semibold text-[#323D52]">
                    Habit Name
                  </h2>
                </CardHeader>
                <CardContent>
                  <Input 
                    placeholder="Enter habit name"
                    value={habitName}
                    onChange={(e) => setHabitName(e.target.value)}
                    className="bg-white border-[#AED9E0] focus-visible:ring-[#5E9FA3]"
                  />
                </CardContent>
              </Card>

              <Card className="bg-white border-[#AED9E0]/40">
                <CardHeader className="pb-3">
                  <h2 className="text-lg font-semibold text-[#323D52]">
                    Category
                  </h2>
                </CardHeader>
                <CardContent>
                  <Select 
                    value={category}
                    onValueChange={setCategory}
                  >
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="emotional">Emotional</SelectItem>
                      <SelectItem value="physical">Physical</SelectItem>
                      <SelectItem value="learning">Learning</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  {habitName && (
                    <p className="text-sm text-[#8E9196] mt-2">
                      💡 Category auto-detected from habit name. You can change it if needed.
                    </p>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-white border-[#AED9E0]/40">
                <CardHeader className="pb-3">
                  <h2 className="text-lg font-semibold text-[#323D52]">
                    Frequency
                  </h2>
                </CardHeader>
                <CardContent>
                  <RadioGroup 
                    value={frequency}
                    onValueChange={setFrequency}
                    className="space-y-3"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="hourly" id="hourly" />
                      <Label htmlFor="hourly">Hourly</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="daily" id="daily" />
                      <Label htmlFor="daily">Daily</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="weekly" id="weekly" />
                      <Label htmlFor="weekly">Weekly</Label>
                    </div>
                  </RadioGroup>
                  
                  {frequency === "hourly" && (
                    <div className="mt-4">
                      <Label htmlFor="hours" className="mb-2 block">How many times per hour?</Label>
                      <Select 
                        value={timesPerPeriod}
                        onValueChange={setTimesPerPeriod}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select times per hour" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 time</SelectItem>
                          <SelectItem value="2">2 times</SelectItem>
                          <SelectItem value="3">3 times</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  
                  {frequency === "daily" && (
                    <div className="mt-4">
                      <Label htmlFor="days" className="mb-2 block">How many times per day?</Label>
                      <Select 
                        value={timesPerPeriod}
                        onValueChange={setTimesPerPeriod}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select times per day" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 time</SelectItem>
                          <SelectItem value="2">2 times</SelectItem>
                          <SelectItem value="3">3 times</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  
                  {frequency === "weekly" && (
                    <div className="mt-4">
                      <Label htmlFor="weeks" className="mb-2 block">How many times per week?</Label>
                      <Select 
                        value={timesPerPeriod}
                        onValueChange={setTimesPerPeriod}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select times per week" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 time</SelectItem>
                          <SelectItem value="2">2 times</SelectItem>
                          <SelectItem value="3">3 times</SelectItem>
                          <SelectItem value="4">4 times</SelectItem>
                          <SelectItem value="5">5 times</SelectItem>
                          <SelectItem value="6">6 times</SelectItem>
                          <SelectItem value="7">7 times</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-white border-[#AED9E0]/40">
                <CardHeader className="pb-3">
                  <h2 className="text-lg font-semibold text-[#323D52]">
                    Rewards
                  </h2>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="reward-type" className="mb-2 block">Reward Type</Label>
                    <Select 
                      value={reward} 
                      onValueChange={setReward}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a reward" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="virtual_pet">Virtual Pet</SelectItem>
                        <SelectItem value="badges">Badges</SelectItem>
                        <SelectItem value="points">Points</SelectItem>
                        <SelectItem value="custom">Custom Reward</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {reward === "virtual_pet" && (
                    <div className="bg-[#F1F0FB] p-4 rounded-md">
                      <p className="text-sm text-[#323D52]">
                        Complete this habit every day for 7 days and receive a virtual pet to care for!
                      </p>
                    </div>
                  )}
                  
                  {reward === "badges" && (
                    <div className="bg-[#F1F0FB] p-4 rounded-md">
                      <p className="text-sm text-[#323D52]">
                        Earn special badges for completing this habit consistently! Bronze badge at 7 days, Silver at 14 days, Gold at 30 days!
                      </p>
                    </div>
                  )}
                  
                  {reward === "points" && (
                    <div className="bg-[#F1F0FB] p-4 rounded-md">
                      <p className="text-sm text-[#323D52]">
                        Earn 10 points each time you complete this habit. Redeem points for special rewards!
                      </p>
                    </div>
                  )}
                  
                  {reward === "custom" && (
                    <div>
                      <Label htmlFor="custom-reward" className="mb-2 block">Custom Reward Name</Label>
                      <Input 
                        id="custom-reward"
                        placeholder="e.g. Sticker Time, Movie Night"
                        value={customRewardName}
                        onChange={(e) => setCustomRewardName(e.target.value)}
                        className="bg-white border-[#AED9E0] focus-visible:ring-[#5E9FA3]"
                      />
                    </div>
                  )}
                </CardContent>
              </Card>

              <Button 
                type="submit"
                className="w-full bg-[#5E9FA3] hover:bg-[#4A8085] text-white font-semibold py-6"
                size="lg"
              >
                Create Habit
              </Button>
            </form>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF9E5] flex flex-col">
      <header className="px-6 pt-8 pb-4 flex items-center space-x-3">
        <button
          onClick={handleBack}
          className="text-[#323D52] hover:opacity-80 transition-opacity flex items-center"
          aria-label="Back"
        >
          <ArrowLeft size={28} />
        </button>
        <h1 className="text-2xl md:text-3xl font-bold text-[#323D52] flex-1 text-center pr-8">
          CHOOSE A HABIT
        </h1>
      </header>

      <main className="flex-1 px-6 pb-8">
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="text-center text-[#323D52] mb-6">
            <p className="text-lg">Pick a habit template to get started quickly!</p>
          </div>

          {/* Create Custom Habit Button - Moved to top for better visibility */}
          <div className="flex justify-center mb-6">
            <Button 
              onClick={handleCreateCustom}
              variant="outline"
              className="border-[#5E9FA3] text-[#5E9FA3] hover:bg-[#5E9FA3] hover:text-white font-semibold py-6 px-8"
              size="lg"
            >
              <Plus className="mr-2" size={24} />
              Create Custom Habit
            </Button>
          </div>

          <div className="text-center text-[#323D52] mb-4">
            <p className="text-base text-[#8E9196]">Or choose from our popular templates:</p>
          </div>

          {/* Category Sections */}
          {["physical", "emotional", "learning", "other"].map((category) => {
            const categoryHabits = habitTemplates.filter(h => h.category === category);
            const categoryTitle = category.charAt(0).toUpperCase() + category.slice(1);
            
            return (
              <div key={category} className="space-y-4">
                <h2 className="text-xl font-semibold text-[#323D52] capitalize">
                  {categoryTitle} Habits
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {categoryHabits.map((template) => (
                    <Card 
                      key={template.id}
                      className={`${getCategoryColor(category)} hover:shadow-md cursor-pointer transition-all hover:scale-105`}
                      onClick={() => handleTemplateSelect(template)}
                    >
                      <CardContent className="p-6">
                        <div className="text-center space-y-3">
                          <div className="text-4xl">{template.emoji}</div>
                          <h3 className="text-lg font-semibold text-[#323D52]">
                            {template.name}
                          </h3>
                          <p className="text-sm text-[#323D52]/70">
                            {template.description}
                          </p>
                          <div className="text-xs text-[#323D52]/60 mt-2">
                            {template.defaultTimesPerPeriod}x {template.defaultFrequency}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
}
