
import { BarChart3, Users, CalendarCheck, Check, User, ArrowLeft } from "lucide-react";
import { Logo } from "@/components/Logo";
import { Link, useNavigate } from "react-router-dom";
import { DashboardContent } from "@/components/dashboard/DashboardContent";
import { FeedbackButton } from "@/components/feedback/FeedbackButton";
import { useState, useEffect } from "react";

const Dashboard = () => {
  const navigate = useNavigate();
  const [habits, setHabits] = useState([]);

  // Load global habits (not associated with specific children)
  useEffect(() => {
    const storedHabits = localStorage.getItem('habits');
    if (storedHabits) {
      const allHabits = JSON.parse(storedHabits);
      // Only get habits that aren't associated with a specific child
      const globalHabits = allHabits.filter((habit: any) => !habit.childId);
      setHabits(globalHabits);
    }
  }, []);

  const handleGoBack = () => {
    navigate('/main-menu');
  };

  return (
    <div className="min-h-screen bg-[#FFF9E5] flex flex-col">
      {/* Header with Logo and Profile */}
      <header className="px-6 pt-8 pb-4 flex justify-between items-center">
        <button 
          onClick={handleGoBack} 
          className="text-[#323D52] hover:opacity-80 transition-opacity flex items-center gap-2"
        >
          <ArrowLeft size={24} />
          Back
        </button>
        <div className="w-20">
          <Logo />
        </div>
        <button className="text-[#323D52] hover:opacity-80 transition-opacity">
          <User size={28} />
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 py-6 overflow-auto">
        {/* Pass an empty string for childId and the habits array to DashboardContent */}
        <DashboardContent childId="" habits={habits} />
      </main>

      {/* Feedback Button */}
      <FeedbackButton />

      {/* Bottom Navigation */}
      <nav className="bg-white px-6 py-4 shadow-lg">
        <div className="flex justify-between max-w-sm mx-auto">
          <Link to="/dashboard" className="text-[#323D52] hover:opacity-80 transition-opacity">
            <BarChart3 size={24} />
          </Link>
          <Link to="/my-nest" className="text-[#AED9E0] hover:opacity-80 transition-opacity">
            <Users size={24} />
          </Link>
          <Link to="/check-in" className="text-[#D6C7F7] hover:opacity-80 transition-opacity">
            <CalendarCheck size={24} />
          </Link>
          <Link to="/habit-tracker" className="text-[#C7F2C4] hover:opacity-80 transition-opacity">
            <Check size={24} />
          </Link>
        </div>
      </nav>
    </div>
  );
};

export default Dashboard;
