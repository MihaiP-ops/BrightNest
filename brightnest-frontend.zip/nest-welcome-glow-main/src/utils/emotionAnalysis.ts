
// Local type definitions to match backend API
type CheckIn = {
  id: number;
  child_id: number;
  emotion_rating: number;
  notes: string | null;
  created_at: string;
};

export const generateAIInsight = (checkIns: CheckIn[], childName: string = 'Child') => {
  if (checkIns.length === 0) {
    return `No check-in data available for ${childName} yet. Start logging daily emotions to see personalized insights.`;
  }

  const recentCheckIns = checkIns.slice(0, 7); // Last 7 check-ins
  const lowMoodCount = recentCheckIns.filter(c => c.emotion_rating <= 2).length;
  const highMoodCount = recentCheckIns.filter(c => c.emotion_rating >= 4).length;
  
  // Analyze common patterns
  const notesText = recentCheckIns.map(c => c.notes || '').join(' ').toLowerCase();
  const commonTriggers = [];
  
  if (notesText.includes('nursery') || notesText.includes('school')) {
    commonTriggers.push('school activities');
  }
  if (notesText.includes('tired') || notesText.includes('sleep') || notesText.includes('bedtime')) {
    commonTriggers.push('sleep patterns');
  }
  if (notesText.includes('sibling') || notesText.includes('brother') || notesText.includes('sister')) {
    commonTriggers.push('sibling interactions');
  }

  if (lowMoodCount > highMoodCount) {
    const trigger = commonTriggers[0] || 'certain situations';
    return `${childName} has been experiencing more challenging emotions lately, often related to ${trigger}. Consider extra support during these times.`;
  } else if (highMoodCount > lowMoodCount) {
    const trigger = commonTriggers[0] || 'daily routines';
    return `${childName} has been showing positive emotional patterns, especially around ${trigger}. Keep up the great work!`;
  } else {
    return `${childName} shows balanced emotional patterns with some ups and downs, which is completely normal for child development.`;
  }
};

export const generateMoodData = (checkIns: CheckIn[]) => {
  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  // Initialize all days with neutral mood - will only be overwritten if there's ACTUAL data
  const moodData = daysOfWeek.map(day => ({ day, mood: 3, emoji: '😐' }));
  
  console.log(`generateMoodData: Processing ${checkIns.length} total check-ins`);
  
  // Get the start of the current week (Sunday)
  const now = new Date();
  const currentDay = now.getDay(); // 0 = Sunday, 1 = Monday, etc.
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - currentDay);
  startOfWeek.setHours(0, 0, 0, 0);
  
  const endOfWeek = new Date(startOfWeek);
  endOfWeek.setDate(startOfWeek.getDate() + 6);
  endOfWeek.setHours(23, 59, 59, 999);
  
  console.log(`generateMoodData: Today is ${daysOfWeek[currentDay]} (${now.toLocaleDateString()})`);
  console.log(`generateMoodData: Current week range: ${startOfWeek.toLocaleDateString()} to ${endOfWeek.toLocaleDateString()}`);
  
  // Debug: log all check-ins with their dates
  console.log('generateMoodData: All check-ins:', checkIns.map(c => ({
    date: new Date(c.created_at).toLocaleDateString(),
    day: daysOfWeek[new Date(c.created_at).getDay()],
    mood: c.emotion_rating,
    notes: c.notes?.substring(0, 30) + '...'
  })));
  
  // Filter check-ins to only include this week
  const currentWeekCheckIns = checkIns.filter(checkIn => {
    const checkInDate = new Date(checkIn.created_at);
    const isInCurrentWeek = checkInDate >= startOfWeek && checkInDate <= endOfWeek;
    if (!isInCurrentWeek) {
      console.log(`generateMoodData: Excluding check-in from ${checkInDate.toLocaleDateString()} (outside current week)`);
    }
    return isInCurrentWeek;
  });

  console.log(`generateMoodData: Found ${currentWeekCheckIns.length} check-ins for current week`);

  // Group check-ins by day and take the most recent one for each day
  const checkInsByDay: { [dayIndex: number]: CheckIn } = {};
  
  currentWeekCheckIns.forEach(checkIn => {
    const checkInDate = new Date(checkIn.created_at);
    const dayIndex = checkInDate.getDay();
    
    console.log(`generateMoodData: Processing check-in on ${daysOfWeek[dayIndex]} (${checkInDate.toLocaleDateString()}) with mood ${checkIn.emotion_rating}`);
    
    // Keep the most recent check-in for each day
    if (!checkInsByDay[dayIndex] || new Date(checkIn.created_at) > new Date(checkInsByDay[dayIndex].created_at)) {
      checkInsByDay[dayIndex] = checkIn;
      console.log(`generateMoodData: Updated ${daysOfWeek[dayIndex]} to mood ${checkIn.emotion_rating}`);
    }
  });

  // Only update mood data for days that actually have check-ins
  Object.entries(checkInsByDay).forEach(([dayIndexStr, checkIn]) => {
    const dayIndex = parseInt(dayIndexStr);
    const emojiMap: { [key: number]: string } = {
      1: '😢', 2: '🙁', 3: '😐', 4: '🙂', 5: '😊'
    };
    
    moodData[dayIndex] = {
      day: daysOfWeek[dayIndex],
      mood: checkIn.emotion_rating,
      emoji: emojiMap[checkIn.emotion_rating] || '😐'
    };
  });

  console.log('generateMoodData: Final mood data:', moodData);
  console.log('generateMoodData: Days with actual check-in data:', Object.keys(checkInsByDay).map(k => daysOfWeek[parseInt(k)]));
  console.log('generateMoodData: Days without data (showing default neutral):', 
    daysOfWeek.filter((_, index) => !checkInsByDay[index])
  );
  
  return moodData;
};

export const generateTriggers = (checkIns: CheckIn[]) => {
  const triggers = new Map<string, number>();
  
  checkIns.forEach(checkIn => {
    if (!checkIn.notes) return;
    
    const notes = checkIn.notes.toLowerCase();
    
    if (notes.includes('nursery') || notes.includes('school') || notes.includes('drop-off')) {
      triggers.set('Nursery Drop-off', (triggers.get('Nursery Drop-off') || 0) + 1);
    }
    if (notes.includes('tired') || notes.includes('late') || notes.includes('bedtime') || notes.includes('sleep')) {
      triggers.set('Late Bedtime', (triggers.get('Late Bedtime') || 0) + 1);
    }
    if (notes.includes('sibling') || notes.includes('fight') || notes.includes('conflict')) {
      triggers.set('Sibling Conflict', (triggers.get('Sibling Conflict') || 0) + 1);
    }
    if (notes.includes('anxious') || notes.includes('worry') || notes.includes('nervous')) {
      triggers.set('Anxiety', (triggers.get('Anxiety') || 0) + 1);
    }
  });

  return Array.from(triggers.entries())
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 3);
};

// New function for mood and habit correlation analysis
export const generateMoodHabitInsight = (checkIns: CheckIn[], habits: any[], childName: string = 'Child') => {
  if (checkIns.length < 3 || habits.length === 0) {
    return "Not enough check-ins yet to detect a pattern between mood and routine.";
  }

  // Get last 7 days of data
  const now = new Date();
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  
  const recentCheckIns = checkIns.filter(checkIn => 
    new Date(checkIn.created_at) >= sevenDaysAgo
  );

  if (recentCheckIns.length < 3) {
    return "Not enough recent check-ins to analyze mood and habit patterns.";
  }

  // Simulate habit completion data (in a real app, this would come from actual habit tracking)
  const daysWithFullHabits = [];
  const daysWithPartialHabits = [];

  recentCheckIns.forEach(checkIn => {
    // Mock logic: assume habits are completed better on higher mood days
    if (checkIn.emotion_rating >= 4) {
      daysWithFullHabits.push(checkIn.emotion_rating);
    } else {
      daysWithPartialHabits.push(checkIn.emotion_rating);
    }
  });

  if (daysWithFullHabits.length === 0) {
    return `${childName}'s mood tends to dip when routines are skipped. Try maintaining consistent habits for better emotional balance.`;
  }

  if (daysWithPartialHabits.length === 0) {
    return `${childName} maintains excellent mood with consistent routines. Keep up the great work!`;
  }

  const avgMoodWithHabits = daysWithFullHabits.reduce((a, b) => a + b, 0) / daysWithFullHabits.length;
  const avgMoodWithoutHabits = daysWithPartialHabits.reduce((a, b) => a + b, 0) / daysWithPartialHabits.length;

  if (avgMoodWithHabits > avgMoodWithoutHabits + 0.5) {
    const topHabits = habits.slice(0, 2).map(h => h.name).join(' and ');
    return `${childName}'s mood was higher on days with completed habits — especially ${topHabits}.`;
  } else {
    return `${childName} shows mixed patterns between mood and routines. Keep tracking to identify trends.`;
  }
};
