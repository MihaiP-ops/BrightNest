// Environment configuration for BrightNest Frontend
export interface EnvironmentConfig {
  // API Configuration
  apiUrl: string;
  apiBaseUrl: string;
  
  // App Configuration
  appName: string;
  appVersion: string;
  environment: 'development' | 'staging' | 'production';
  
  // Features
  enableDebug: boolean;
  enableAnalytics: boolean;
  
  // External Services
  sentryDsn?: string;
  googleAnalyticsId?: string;
  
  // Upload Configuration
  maxFileSizeMB: number;
  allowedFileTypes: string[];
  
  // Development/Production specific
  logLevel: 'debug' | 'info' | 'warn' | 'error';
  showDevTools?: boolean;
  enableServiceWorker?: boolean;
}

const getEnvironmentConfig = (): EnvironmentConfig => {
  const env = import.meta.env;
  
  return {
    // API Configuration
    apiUrl: env.VITE_API_URL || 'http://localhost:8000/api/v1',
    apiBaseUrl: env.VITE_API_BASE_URL || 'http://localhost:8000',
    
    // App Configuration
    appName: env.VITE_APP_NAME || 'BrightNest',
    appVersion: env.VITE_APP_VERSION || '1.0.0',
    environment: (env.VITE_ENVIRONMENT as any) || 'development',
    
    // Features
    enableDebug: env.VITE_ENABLE_DEBUG === 'true' || env.VITE_ENVIRONMENT === 'development',
    enableAnalytics: env.VITE_ENABLE_ANALYTICS === 'true' && env.VITE_ENVIRONMENT === 'production',
    
    // External Services
    sentryDsn: env.VITE_SENTRY_DSN,
    googleAnalyticsId: env.VITE_GOOGLE_ANALYTICS_ID,
    
    // Upload Configuration
    maxFileSizeMB: parseInt(env.VITE_MAX_FILE_SIZE_MB || '10'),
    allowedFileTypes: (env.VITE_ALLOWED_FILE_TYPES || 'pdf,jpg,jpeg,png').split(','),
    
    // Development/Production specific
    logLevel: (env.VITE_LOG_LEVEL as any) || (env.VITE_ENVIRONMENT === 'production' ? 'error' : 'debug'),
    showDevTools: env.VITE_SHOW_DEV_TOOLS === 'true',
    enableServiceWorker: env.VITE_ENABLE_SERVICE_WORKER === 'true',
  };
};

export const config = getEnvironmentConfig();

// Helper functions
export const isDevelopment = () => config.environment === 'development';
export const isProduction = () => config.environment === 'production';
export const isStaging = () => config.environment === 'staging';

// Console logging helper that respects environment
export const logger = {
  debug: (...args: any[]) => {
    if (config.enableDebug || ['debug', 'info'].includes(config.logLevel)) {
      console.log('[DEBUG]', ...args);
    }
  },
  info: (...args: any[]) => {
    if (['debug', 'info'].includes(config.logLevel)) {
      console.info('[INFO]', ...args);
    }
  },
  warn: (...args: any[]) => {
    if (['debug', 'info', 'warn'].includes(config.logLevel)) {
      console.warn('[WARN]', ...args);
    }
  },
  error: (...args: any[]) => {
    console.error('[ERROR]', ...args);
  },
};

export default config; 