# 🚀 Quick Deploy: BrightNest to Vercel + Railway

## ⚡ 5-Minute Deployment

### Step 1: Deploy Backend (Railway)
1. Go to [railway.app](https://railway.app) and sign up
2. Click "New Project" → "Deploy from GitHub repo"
3. Select your repository
4. Add PostgreSQL database:
   - Click "New" → "Database" → "PostgreSQL"
5. Set environment variables:
   ```
   ENVIRONMENT=production
   SECRET_KEY=your-super-secret-key-here
   OPENAI_API_KEY=your-openai-api-key
   BACKEND_CORS_ORIGINS=["https://your-app.vercel.app"]
   ```
6. Copy the Railway URL (e.g., `https://your-app-production.up.railway.app`)

### Step 2: Deploy Frontend (Vercel)
1. Go to [vercel.com](https://vercel.com) and sign up
2. Click "New Project" → Import from GitHub
3. Select your repository
4. Set environment variable:
   ```
   VITE_API_URL=https://your-app-production.up.railway.app
   ```
5. Deploy!

### Step 3: Test
- Backend: `https://your-app-production.up.railway.app/health`
- Frontend: `https://your-app.vercel.app`

## 🔧 Configuration Files Created

- ✅ `backend/railway.json` - Railway deployment config
- ✅ `backend/Procfile` - Process definition
- ✅ `vercel.json` - Vercel deployment config
- ✅ `DEPLOYMENT_GUIDE.md` - Detailed instructions
- ✅ `scripts/deploy.sh` - Deployment helper script

## 🎯 What's Ready

- ✅ Database: SQLite (dev) + PostgreSQL (prod)
- ✅ Environment variables: Development + Production
- ✅ CORS: Configured for Vercel domains
- ✅ Health checks: `/health` endpoint
- ✅ Error handling: Production-ready logging

## 🚨 Important Notes

1. **Change the SECRET_KEY** in production!
2. **Add your OpenAI API key** for AI features
3. **Update CORS origins** with your actual Vercel domain
4. **Test thoroughly** before going live

## 📞 Need Help?

- Check `DEPLOYMENT_GUIDE.md` for detailed instructions
- Run `./scripts/deploy.sh` for a deployment checklist
- Check Railway/Vercel logs if something goes wrong

---

**Ready to deploy? Let's go! 🚀**
