# 🚀 BrightNest Deployment Guide

This guide will walk you through deploying BrightNest from development to production.

## 📋 Prerequisites

- Node.js 16+ and npm
- Python 3.9+
- PostgreSQL database
- Domain name (for production)
- OpenAI API key (for AI features)

## 🏗️ Environment Setup

### Development Environment

1. **Backend Setup:**
   ```bash
   cd backend
   cp .env.example .env
   # Edit .env with your local settings
   ```

2. **Frontend Setup:**
   ```bash
   cp .env.example .env.local
   # Edit .env.local with your local settings
   ```

### Production Environment

1. **Backend Production Configuration:**
   ```bash
   # Copy and edit the production template
   cp backend/.env.production backend/.env.prod
   # Update all placeholder values in .env.prod
   ```

2. **Frontend Production Configuration:**
   ```bash
   # Copy and edit the production template
   cp .env.production .env.prod
   # Update all placeholder values in .env.prod
   ```

## 🔧 Configuration Variables

### Backend Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://user:pass@host:5432/db` |
| `SECRET_KEY` | JWT secret key (generate new for production) | `your-secret-key` |
| `OPENAI_API_KEY` | OpenAI API key for AI features | `sk-...` |
| `BACKEND_CORS_ORIGINS` | Allowed frontend domains | `["https://yourdomain.com"]` |
| `SMTP_*` | Email configuration for user notifications | Various |

### Frontend Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `VITE_API_URL` | Backend API URL | `https://api.yourdomain.com/api/v1` |
| `VITE_ENVIRONMENT` | Environment mode | `production` |
| `VITE_SENTRY_DSN` | Error tracking (optional) | `https://...` |

## 🛠️ Deployment Script Usage

We've included a deployment script to help with environment management:

```bash
# Make script executable (first time only)
chmod +x scripts/deploy.sh

# Setup environment files
./scripts/deploy.sh development setup
./scripts/deploy.sh production setup

# Build for specific environment
./scripts/deploy.sh development build
./scripts/deploy.sh production build

# Run tests
./scripts/deploy.sh production test

# Check production readiness
./scripts/deploy.sh production check

# Full deployment pipeline
./scripts/deploy.sh production full
```

## 🌍 Production Deployment Options

### Option 1: Railway (Recommended)

**Backend Deployment:**
1. Connect your GitHub repository to Railway
2. Set up PostgreSQL database add-on
3. Configure environment variables in Railway dashboard
4. Deploy backend service

**Frontend Deployment:**
1. Use Vercel or Netlify for frontend
2. Connect GitHub repository
3. Set build command: `npm run build`
4. Set environment variables

### Option 2: Heroku

**Backend:**
```bash
# Install Heroku CLI and login
heroku create your-app-backend
heroku addons:create heroku-postgresql:hobby-dev
heroku config:set SECRET_KEY=your-secret-key
heroku config:set OPENAI_API_KEY=your-openai-key
# ... set other variables
git push heroku main
```

**Frontend:**
```bash
heroku create your-app-frontend
heroku buildpacks:set https://github.com/mars/create-react-app-buildpack.git
heroku config:set VITE_API_URL=https://your-app-backend.herokuapp.com/api/v1
git push heroku main
```

### Option 3: DigitalOcean App Platform

1. Create new app from GitHub repository
2. Configure build and run commands
3. Set up managed PostgreSQL database
4. Configure environment variables

## 🔒 Security Checklist

Before going live, ensure:

- [ ] New SECRET_KEY generated for production
- [ ] Database credentials are secure
- [ ] CORS origins are restricted to your domain
- [ ] DEBUG is set to false in production
- [ ] SSL/HTTPS is enabled
- [ ] Environment variables are not exposed in frontend build
- [ ] API rate limiting is configured
- [ ] Error tracking is set up (Sentry)

## 📊 Database Migration

1. **Export Development Data:**
   ```bash
   pg_dump brightnest > backup.sql
   ```

2. **Import to Production:**
   ```bash
   psql $DATABASE_URL < backup.sql
   ```

## 🔍 Health Checks

After deployment, verify:

- [ ] Backend API is accessible: `https://your-backend.com/`
- [ ] Frontend loads: `https://your-frontend.com/`
- [ ] User registration works
- [ ] Database connection is stable
- [ ] AI features are working (if OpenAI key is set)
- [ ] Email notifications work (if configured)

## 📈 Monitoring

Set up monitoring for:

- API response times
- Database performance
- Error rates
- User activity
- AI API usage

## 🆘 Troubleshooting

### Common Issues:

**CORS Errors:**
- Check `BACKEND_CORS_ORIGINS` includes your frontend domain
- Ensure protocol (http/https) matches

**Database Connection:**
- Verify `DATABASE_URL` format
- Check database server is accessible
- Ensure SSL settings if required

**Environment Variables Not Loading:**
- Check file naming (.env.production vs .env)
- Verify environment-specific loading in config
- Restart services after changes

**Build Failures:**
- Check Node.js/Python versions
- Verify all dependencies are listed
- Check for missing environment variables

## 🚨 Emergency Rollback

If issues occur in production:

1. **Quick Rollback:**
   ```bash
   # Revert to previous deployment
   git revert HEAD
   git push origin main
   ```

2. **Database Rollback:**
   ```bash
   # Restore from backup
   psql $DATABASE_URL < backup.sql
   ```

## 📞 Support

For deployment help:
- Check application logs
- Verify environment configuration
- Test individual components
- Use deployment script diagnostics

---

**Next Step:** Continue to Phase 2 - Testing with production-like database! 🎯 