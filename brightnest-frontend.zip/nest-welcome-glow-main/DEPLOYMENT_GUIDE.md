# 🚀 Deployment Guide: Vercel + Railway

## Backend Deployment (Railway)

### 1. Prepare Backend for Railway

The backend is already configured with:
- ✅ `railway.json` - Railway configuration
- ✅ `Procfile` - Process definition
- ✅ Database support for both SQLite (dev) and PostgreSQL (prod)
- ✅ Environment variable handling

### 2. Deploy to Railway

1. **Sign up at [Railway.app](https://railway.app)**
2. **Connect your GitHub repository**
3. **Create a new project**
4. **Add PostgreSQL database:**
   - Click "New" → "Database" → "PostgreSQL"
   - Railway will automatically set `DATABASE_URL`

5. **Set Environment Variables in Railway Dashboard:**
   ```
   ENVIRONMENT=production
   DEBUG=false
   SECRET_KEY=your-super-secret-jwt-key-here
   OPENAI_API_KEY=your-openai-api-key-here
   BACKEND_CORS_ORIGINS=["https://your-app-name.vercel.app"]
   ```

6. **Deploy:**
   - Railway will automatically detect the Python app
   - It will run: `python3 -m uvicorn main:app --host 0.0.0.0 --port $PORT`

### 3. Get Backend URL
- Railway will provide a URL like: `https://your-app-name-production.up.railway.app`
- Copy this URL for frontend configuration

---

## Frontend Deployment (Vercel)

### 1. Prepare Frontend for Vercel

1. **Update API URL in environment config:**
   - Edit `src/config/environment.ts`
   - Change `apiUrl` to your Railway backend URL

2. **Create Vercel configuration:**
   - Create `vercel.json` in the root directory

### 2. Deploy to Vercel

1. **Sign up at [Vercel.com](https://vercel.com)**
2. **Connect your GitHub repository**
3. **Import project**
4. **Set Environment Variables:**
   ```
   VITE_API_URL=https://your-app-name-production.up.railway.app
   ```
5. **Deploy**

---

## Environment Variables Summary

### Backend (Railway)
```
ENVIRONMENT=production
DEBUG=false
DATABASE_URL=(auto-set by Railway)
SECRET_KEY=your-secret-key
OPENAI_API_KEY=your-openai-key
BACKEND_CORS_ORIGINS=["https://your-app.vercel.app"]
```

### Frontend (Vercel)
```
VITE_API_URL=https://your-backend.railway.app
```

---

## Testing Production

1. **Test Backend:**
   - Visit: `https://your-backend.railway.app/health`
   - Should return: `{"status": "healthy"}`

2. **Test Frontend:**
   - Visit your Vercel URL
   - Try logging in and creating habits

---

## Troubleshooting

### Common Issues:

1. **CORS Errors:**
   - Make sure `BACKEND_CORS_ORIGINS` includes your Vercel domain

2. **Database Connection:**
   - Check that `DATABASE_URL` is set correctly in Railway

3. **API Not Found:**
   - Verify `VITE_API_URL` is correct in Vercel

4. **Build Failures:**
   - Check Railway logs for Python errors
   - Check Vercel logs for build issues

---

## Next Steps After Deployment

1. **Set up custom domain** (optional)
2. **Configure monitoring** (Sentry, etc.)
3. **Set up backups** for PostgreSQL
4. **Configure SSL certificates** (handled automatically)
5. **Set up CI/CD** for automatic deployments
