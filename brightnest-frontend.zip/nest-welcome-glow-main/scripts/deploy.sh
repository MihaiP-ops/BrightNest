#!/bin/bash

# BrightNest Deployment Script
# This script helps deploy the app to Vercel + Railway

echo "🚀 BrightNest Deployment Script"
echo "================================"

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: Please run this script from the project root directory"
    exit 1
fi

echo "📋 Pre-deployment checklist:"
echo ""

# Check if backend files exist
if [ -f "backend/railway.json" ]; then
    echo "✅ Backend Railway config found"
else
    echo "❌ Backend Railway config missing"
    exit 1
fi

if [ -f "vercel.json" ]; then
    echo "✅ Frontend Vercel config found"
else
    echo "❌ Frontend Vercel config missing"
    exit 1
fi

echo ""
echo "📝 Next steps:"
echo ""
echo "1. BACKEND (Railway):"
echo "   - Go to https://railway.app"
echo "   - Create new project from GitHub"
echo "   - Add PostgreSQL database"
echo "   - Set environment variables:"
echo "     - ENVIRONMENT=production"
echo "     - SECRET_KEY=your-secret-key"
echo "     - OPENAI_API_KEY=your-openai-key"
echo "     - BACKEND_CORS_ORIGINS=[\"https://your-app.vercel.app\"]"
echo ""
echo "2. FRONTEND (Vercel):"
echo "   - Go to https://vercel.com"
echo "   - Import project from GitHub"
echo "   - Set environment variable:"
echo "     - VITE_API_URL=https://your-backend.railway.app"
echo ""
echo "3. TEST:"
echo "   - Test backend: https://your-backend.railway.app/health"
echo "   - Test frontend: https://your-app.vercel.app"
echo ""
echo "📖 See DEPLOYMENT_GUIDE.md for detailed instructions"
echo ""
echo "🎉 Happy deploying!"