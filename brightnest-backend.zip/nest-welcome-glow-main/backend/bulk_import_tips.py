#!/usr/bin/env python3
"""
Bulk import script for AI tips and habit suggestions.

Usage:
    python bulk_import_tips.py --tips tips.csv
    python bulk_import_tips.py --habits habits.csv
    python bulk_import_tips.py --json data.json

CSV Format for tips:
    age_group,emotion_rating,tip_text,tip_category
    0-3,1,"Tip text here","comfort"
    
CSV Format for habits:
    age_group,emotion_rating,habit_name,habit_description,keywords
    0-3,1,"Habit name","Description","keyword1,keyword2,keyword3"

JSON Format:
    {
        "tips": [
            {"age_group": "0-3", "emotion_rating": 1, "tip_text": "...", "tip_category": "comfort"},
            ...
        ],
        "habits": [
            {"age_group": "0-3", "emotion_rating": 1, "habit_name": "...", "habit_description": "...", "keywords": ["word1", "word2"]},
            ...
        ]
    }
"""

import psycopg2
import csv
import json
import argparse
import sys
from datetime import datetime

def get_db_connection():
    """Get database connection"""
    try:
        return psycopg2.connect('postgresql://postgres:postgres@localhost:5432/brightnest')
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        sys.exit(1)

def import_tips_from_csv(csv_file):
    """Import AI tips from CSV file"""
    conn = get_db_connection()
    cur = conn.cursor()
    
    imported = 0
    try:
        with open(csv_file, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                cur.execute('''
                    INSERT INTO ai_tips (age_group, emotion_rating, tip_text, tip_category)
                    VALUES (%s, %s, %s, %s)
                ''', (
                    row['age_group'],
                    int(row['emotion_rating']),
                    row['tip_text'],
                    row.get('tip_category', 'general')
                ))
                imported += 1
        
        conn.commit()
        print(f"✅ Successfully imported {imported} AI tips from {csv_file}")
        
    except Exception as e:
        conn.rollback()
        print(f"❌ Error importing tips: {e}")
    finally:
        conn.close()

def import_habits_from_csv(csv_file):
    """Import habit suggestions from CSV file"""
    conn = get_db_connection()
    cur = conn.cursor()
    
    imported = 0
    try:
        with open(csv_file, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                # Convert keywords to JSON array format
                keywords = row.get('keywords', '')
                if keywords:
                    keywords_list = [k.strip() for k in keywords.split(',')]
                    keywords_json = json.dumps(keywords_list)
                else:
                    keywords_json = '[]'
                
                cur.execute('''
                    INSERT INTO habit_suggestions (age_group, emotion_rating, habit_name, habit_description, keywords)
                    VALUES (%s, %s, %s, %s, %s)
                ''', (
                    row['age_group'],
                    int(row['emotion_rating']),
                    row['habit_name'],
                    row.get('habit_description', ''),
                    keywords_json
                ))
                imported += 1
        
        conn.commit()
        print(f"✅ Successfully imported {imported} habit suggestions from {csv_file}")
        
    except Exception as e:
        conn.rollback()
        print(f"❌ Error importing habits: {e}")
    finally:
        conn.close()

def import_from_json(json_file):
    """Import both tips and habits from JSON file"""
    conn = get_db_connection()
    cur = conn.cursor()
    
    try:
        with open(json_file, 'r', encoding='utf-8') as file:
            data = json.load(file)
        
        tips_imported = 0
        habits_imported = 0
        
        # Import tips
        if 'tips' in data:
            for tip in data['tips']:
                cur.execute('''
                    INSERT INTO ai_tips (age_group, emotion_rating, tip_text, tip_category)
                    VALUES (%s, %s, %s, %s)
                ''', (
                    tip['age_group'],
                    tip['emotion_rating'],
                    tip['tip_text'],
                    tip.get('tip_category', 'general')
                ))
                tips_imported += 1
        
        # Import habits
        if 'habits' in data:
            for habit in data['habits']:
                keywords_json = json.dumps(habit.get('keywords', []))
                cur.execute('''
                    INSERT INTO habit_suggestions (age_group, emotion_rating, habit_name, habit_description, keywords)
                    VALUES (%s, %s, %s, %s, %s)
                ''', (
                    habit['age_group'],
                    habit['emotion_rating'],
                    habit['habit_name'],
                    habit.get('habit_description', ''),
                    keywords_json
                ))
                habits_imported += 1
        
        conn.commit()
        print(f"✅ Successfully imported {tips_imported} tips and {habits_imported} habits from {json_file}")
        
    except Exception as e:
        conn.rollback()
        print(f"❌ Error importing from JSON: {e}")
    finally:
        conn.close()

def create_sample_csv():
    """Create sample CSV files for reference"""
    
    # Sample tips CSV
    with open('sample_tips.csv', 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(['age_group', 'emotion_rating', 'tip_text', 'tip_category'])
        writer.writerow(['0-3', '1', 'Toddlers need extra comfort when very upset. Try gentle rocking and soft singing.', 'comfort'])
        writer.writerow(['4-7', '5', 'Celebrate their joy! Ask them to teach you their happy dance.', 'celebration'])
        writer.writerow(['8-10', '3', 'Use this calm time for deeper conversations about their interests and dreams.', 'reflection'])
    
    # Sample habits CSV
    with open('sample_habits.csv', 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(['age_group', 'emotion_rating', 'habit_name', 'habit_description', 'keywords'])
        writer.writerow(['0-3', '1', 'Comfort Cuddle Time', 'Set aside 10 minutes for extra cuddles when upset', 'upset,crying,sad'])
        writer.writerow(['4-7', '5', 'Joy Sharing Circle', 'Share happy moments with family at dinner', 'family,sharing,happy'])
        writer.writerow(['8-10', '2', 'Problem-Solving Journal', 'Write about challenges and brainstorm solutions', 'problem,solution,writing'])
    
    print("✅ Created sample_tips.csv and sample_habits.csv for reference")

def show_current_stats():
    """Show current database statistics"""
    conn = get_db_connection()
    cur = conn.cursor()
    
    try:
        # Tips stats
        cur.execute('SELECT age_group, emotion_rating, COUNT(*) FROM ai_tips GROUP BY age_group, emotion_rating ORDER BY age_group, emotion_rating;')
        tips_stats = cur.fetchall()
        
        print("📊 Current AI Tips in Database:")
        for row in tips_stats:
            print(f"  Age {row[0]}, Emotion {row[1]}: {row[2]} tips")
        
        # Habits stats
        cur.execute('SELECT age_group, emotion_rating, COUNT(*) FROM habit_suggestions GROUP BY age_group, emotion_rating ORDER BY age_group, emotion_rating;')
        habits_stats = cur.fetchall()
        
        print("\n📊 Current Habit Suggestions in Database:")
        for row in habits_stats:
            print(f"  Age {row[0]}, Emotion {row[1]}: {row[2]} habits")
        
        # Total counts
        cur.execute('SELECT COUNT(*) FROM ai_tips;')
        total_tips = cur.fetchone()[0]
        cur.execute('SELECT COUNT(*) FROM habit_suggestions;')
        total_habits = cur.fetchone()[0]
        
        print(f"\n🎯 Total: {total_tips} tips, {total_habits} habits")
        
    except Exception as e:
        print(f"❌ Error getting stats: {e}")
    finally:
        conn.close()

def main():
    parser = argparse.ArgumentParser(description='Bulk import AI tips and habit suggestions')
    parser.add_argument('--tips', help='Import tips from CSV file')
    parser.add_argument('--habits', help='Import habits from CSV file')
    parser.add_argument('--json', help='Import both from JSON file')
    parser.add_argument('--sample', action='store_true', help='Create sample CSV files')
    parser.add_argument('--stats', action='store_true', help='Show current database statistics')
    
    args = parser.parse_args()
    
    if args.sample:
        create_sample_csv()
    elif args.stats:
        show_current_stats()
    elif args.tips:
        import_tips_from_csv(args.tips)
    elif args.habits:
        import_habits_from_csv(args.habits)
    elif args.json:
        import_from_json(args.json)
    else:
        parser.print_help()

if __name__ == '__main__':
    main() 