# BrightNest Backend API

This is the backend API for BrightNest, a child development and habit tracking application. Built with FastAPI and PostgreSQL.

## Features

- User authentication with JWT tokens
- Child profile management
- Habit tracking and progress monitoring
- Emotional check-ins with mood tracking
- User feedback system
- RESTful API design
- PostgreSQL database with SQLAlchemy ORM

## Prerequisites

- Python 3.8+
- PostgreSQL 12+
- pip (Python package manager)

## Setup

1. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Create a PostgreSQL database:
   ```sql
   CREATE DATABASE brightnest;
   ```

4. Create a `.env` file in the root directory with the following content:
   ```env
   DATABASE_URL=postgresql://username:password@localhost:5432/brightnest
   SECRET_KEY=your-secret-key-here
   ```

5. Run the application:
   ```bash
   uvicorn main:app --reload
   ```

The API will be available at `http://localhost:8000`

## API Documentation

Once the server is running, you can access:
- Interactive API documentation: `http://localhost:8000/docs`
- Alternative API documentation: `http://localhost:8000/redoc`

## API Endpoints

### Authentication
- POST `/api/v1/auth/register` - Register a new user
- POST `/api/v1/auth/login` - Login and get access token
- GET `/api/v1/auth/me` - Get current user info

### Children
- POST `/api/v1/children` - Create a child profile
- GET `/api/v1/children` - List all children
- GET `/api/v1/children/{child_id}` - Get child details
- PUT `/api/v1/children/{child_id}` - Update child profile
- DELETE `/api/v1/children/{child_id}` - Delete child profile

### Habits
- POST `/api/v1/habits` - Create a habit
- GET `/api/v1/habits/child/{child_id}` - List child's habits
- POST `/api/v1/habits/{habit_id}/complete` - Mark habit as completed
- GET `/api/v1/habits/{habit_id}/progress` - Get habit progress
- PUT `/api/v1/habits/{habit_id}` - Update habit
- DELETE `/api/v1/habits/{habit_id}` - Delete habit

### Check-ins
- POST `/api/v1/checkins` - Create a check-in
- GET `/api/v1/checkins/child/{child_id}` - List child's check-ins
- GET `/api/v1/checkins/child/{child_id}/summary` - Get check-in summary

### Feedback
- POST `/api/v1/feedback` - Submit feedback
- GET `/api/v1/feedback/my` - List user's feedback

## Development

The project structure follows a modular approach:
```
backend/
├── api/
│   ├── auth.py
│   ├── children.py
│   ├── habits.py
│   ├── checkins.py
│   └── feedback.py
├── models.py
├── schemas.py
├── database.py
├── config.py
├── auth.py
└── main.py
```

## Security

- All endpoints (except registration and login) require authentication
- Passwords are hashed using bcrypt
- JWT tokens are used for session management
- CORS is configured for frontend integration
- Database queries are protected against SQL injection through SQLAlchemy

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request 