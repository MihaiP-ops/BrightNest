#!/usr/bin/env python3
"""
Script to update resource content with comprehensive articles
"""

import sqlite3
from datetime import datetime

# Sample comprehensive article content
ARTICLE_CONTENTS = {
    1: {  # Understanding Childhood Anxiety: A Parent's Guide
        "content": """# Understanding Childhood Anxiety: A Parent's Guide

Childhood anxiety is one of the most common mental health challenges facing young people today. As a parent, watching your child struggle with worry, fear, or panic can be heartbreaking and overwhelming. However, understanding the nature of childhood anxiety and learning effective strategies to support your child can make a significant difference in their well-being and development.

## What Is Childhood Anxiety?

Anxiety is a natural human emotion that everyone experiences from time to time. It's our body's way of preparing us for potential threats or challenges. However, when anxiety becomes excessive, persistent, and interferes with a child's daily life, it may indicate an anxiety disorder.

Common signs of childhood anxiety include:

### Physical Symptoms
- Headaches or stomachaches without a medical cause
- Difficulty sleeping or frequent nightmares
- Changes in appetite
- Fatigue or restlessness
- Muscle tension or trembling

### Emotional and Behavioral Signs
- Excessive worry about everyday situations
- Avoidance of certain activities, places, or people
- Difficulty concentrating
- Irritability or mood swings
- Clinginess or separation difficulties
- Perfectionism or fear of making mistakes

## Age-Specific Anxiety Manifestations

### Preschoolers (Ages 3-5)
- Separation anxiety when away from parents
- Fear of the dark, monsters, or imaginary threats
- Regression in toilet training or sleep habits
- Excessive tantrums or emotional outbursts

### School-Age Children (Ages 6-11)
- Worry about school performance or social acceptance
- Physical complaints to avoid school
- Difficulty making decisions
- Seeking constant reassurance from adults

### Adolescents (Ages 12-18)
- Social anxiety and fear of judgment
- Perfectionism and fear of failure
- Body image concerns
- Worry about future events or responsibilities

## Effective Strategies for Supporting Your Anxious Child

### 1. Create a Safe and Supportive Environment

Your home should be a sanctuary where your child feels secure and understood. This means:

- **Listen without judgment**: When your child expresses their fears or worries, resist the urge to dismiss them or offer quick fixes. Instead, listen actively and validate their feelings.

- **Maintain predictable routines**: Consistency helps anxious children feel more secure. Establish regular schedules for meals, homework, and bedtime.

- **Model calm behavior**: Children learn by watching their parents. Demonstrate healthy coping strategies when you're feeling stressed or anxious.

### 2. Teach Coping Strategies

Help your child develop a toolkit of techniques they can use when anxiety strikes:

**Deep Breathing Exercises**
- Practice the "balloon breath" technique: breathe in slowly through the nose (inflating the balloon), hold for a few seconds, then breathe out slowly through the mouth (deflating the balloon).
- Use counting: breathe in for 4 counts, hold for 4, breathe out for 4.

**Progressive Muscle Relaxation**
- Teach your child to tense and then relax different muscle groups, starting from their toes and working up to their head.
- Make it fun by pretending to be different animals (tight like a turtle, then loose like a jellyfish).

**Mindfulness and Grounding Techniques**
- The "5-4-3-2-1" technique: identify 5 things you can see, 4 things you can touch, 3 things you can hear, 2 things you can smell, and 1 thing you can taste.
- Mindful coloring, drawing, or other creative activities.

### 3. Gradual Exposure and Building Confidence

While it's natural to want to protect your anxious child from distressing situations, avoiding feared situations can actually reinforce anxiety. Instead:

- **Start small**: Break down feared situations into manageable steps.
- **Celebrate progress**: Acknowledge and praise your child's efforts, not just the outcomes.
- **Be patient**: Progress may be slow, and setbacks are normal.

For example, if your child is afraid of dogs:
1. Look at pictures of friendly dogs
2. Watch videos of dogs playing
3. Observe dogs from a distance at the park
4. Stand near a calm, leashed dog
5. Eventually, pet a gentle dog with supervision

### 4. Communication Strategies

**Use "Worry Time"**
- Set aside 10-15 minutes each day for your child to express their worries.
- Outside of this time, remind them to save their worries for "worry time."
- This helps contain anxiety rather than letting it dominate the entire day.

**Normalize Anxiety**
- Explain that everyone feels anxious sometimes, and it's a normal part of being human.
- Share age-appropriate examples of times when you felt anxious and how you coped.

**Avoid Reassurance Seeking**
- While it's important to be supportive, constantly providing reassurance can reinforce anxiety.
- Instead of saying "Don't worry, everything will be fine," try "I understand you're worried. What do you think we could do about this?"

## When to Seek Professional Help

While many children experience occasional anxiety, professional help may be needed if:

- Anxiety persists for more than six months
- It significantly interferes with school, friendships, or family life
- Your child experiences panic attacks
- They develop physical symptoms with no medical cause
- Family life becomes centered around avoiding your child's fears
- You feel overwhelmed and unsure how to help

## Treatment Options

### Cognitive Behavioral Therapy (CBT)
CBT is the gold standard treatment for childhood anxiety. It helps children:
- Identify anxious thoughts and feelings
- Challenge unrealistic worries
- Develop coping strategies
- Gradually face their fears in a safe, controlled manner

### Family Therapy
Sometimes involving the whole family can be beneficial, especially when anxiety affects family dynamics or when parents need support in managing their own anxiety about their child's struggles.

### Medication
In some cases, medication may be recommended, particularly for severe anxiety that doesn't respond to therapy alone. This decision should always be made in consultation with a qualified mental health professional.

## Supporting Your Child's School Experience

Anxiety often manifests significantly in school settings. Work with your child's teachers and school counselors to:

- Develop accommodations if needed (extra time for tests, a quiet space to calm down)
- Create a communication plan between home and school
- Ensure your child has trusted adults at school they can turn to
- Address any bullying or social issues that may be contributing to anxiety

## Self-Care for Parents

Supporting an anxious child can be emotionally draining. Remember to:

- Take care of your own mental health
- Seek support from other parents or support groups
- Practice stress management techniques
- Don't blame yourself for your child's anxiety
- Celebrate small victories and progress

## Building Long-Term Resilience

The goal isn't to eliminate anxiety entirely – some anxiety is normal and even helpful. Instead, focus on helping your child develop resilience and coping skills that will serve them throughout their life.

**Encourage Independence**
- Allow your child to solve age-appropriate problems on their own
- Resist the urge to rescue them from every difficult situation
- Build their confidence through successful experiences

**Foster Emotional Intelligence**
- Help your child identify and name their emotions
- Teach them that all feelings are valid, even if all behaviors aren't acceptable
- Model healthy emotional expression

**Maintain Perspective**
- Remember that anxiety is treatable and manageable
- Focus on your child's strengths and positive qualities
- Keep hope alive – with proper support, anxious children can thrive

## Conclusion

Childhood anxiety can feel overwhelming for both children and parents, but with understanding, patience, and the right strategies, it's absolutely manageable. Remember that seeking help is a sign of strength, not weakness, and that early intervention can make a significant difference in your child's long-term well-being.

Every child is unique, and what works for one may not work for another. Be patient with yourself and your child as you navigate this journey together. With love, support, and professional guidance when needed, your child can learn to manage their anxiety and develop into a confident, resilient individual.

If you're concerned about your child's anxiety, don't hesitate to reach out to your pediatrician, school counselor, or a mental health professional who specializes in working with children and families."""
    },
    
    5: {  # Positive Discipline Strategies That Actually Work
        "content": """# Positive Discipline Strategies That Actually Work

Parenting is one of the most rewarding yet challenging experiences in life. When it comes to discipline, many parents find themselves caught between wanting to guide their children's behavior while maintaining a loving, supportive relationship. Positive discipline offers a solution that focuses on teaching rather than punishing, building intrinsic motivation rather than fear-based compliance.

## Understanding Positive Discipline

Positive discipline is an approach to child-rearing that emphasizes mutual respect, understanding, and teaching appropriate behavior through natural consequences and problem-solving. Unlike traditional punishment-based methods, positive discipline focuses on:

- **Teaching life skills** rather than simply stopping unwanted behavior
- **Building emotional intelligence** and self-regulation
- **Maintaining the child's dignity** while addressing behavioral issues
- **Strengthening the parent-child relationship** rather than damaging it
- **Developing intrinsic motivation** for good behavior

## The Science Behind Positive Discipline

Research consistently shows that positive discipline approaches are more effective in the long term than punitive methods. Studies indicate that children raised with positive discipline techniques:

- Show better emotional regulation and social skills
- Have higher self-esteem and confidence
- Demonstrate more empathy and cooperation
- Are less likely to engage in aggressive behavior
- Perform better academically
- Have stronger relationships with their parents

## Core Principles of Positive Discipline

### 1. Mutual Respect
Both parent and child deserve to be treated with dignity. This means avoiding humiliation, name-calling, or power struggles that diminish either person's worth.

### 2. Understanding the Child's World
Every behavior has a purpose. Children may act out because they're seeking attention, autonomy, connection, or trying to communicate a need they can't express verbally.

### 3. Focus on Solutions
Instead of dwelling on what went wrong, positive discipline emphasizes finding solutions and preventing future problems.

### 4. Long-term Thinking
While punishment might stop behavior immediately, positive discipline builds character and life skills that benefit children throughout their lives.

## Age-Appropriate Positive Discipline Strategies

### Toddlers (Ages 1-3)

**Redirection and Distraction**
- When a toddler is engaging in unwanted behavior, redirect their attention to something appropriate
- Example: If they're throwing toys, redirect them to a ball that's meant to be thrown

**Natural Consequences**
- Allow safe, natural consequences to teach lessons
- Example: If they refuse to wear a coat, let them experience being cold (within reason and safety limits)

**Consistent Routines**
- Toddlers thrive on predictability
- Establish clear routines for meals, naps, and bedtime
- Use visual schedules or songs to make transitions easier

**Emotional Validation**
- Acknowledge their feelings even when you can't allow their behavior
- "I see you're angry that we have to leave the park. It's hard to stop playing."

### Preschoolers (Ages 3-5)

**Choice-Giving**
- Offer limited, acceptable choices to give them some control
- "Would you like to brush your teeth first or put on your pajamas first?"

**Problem-Solving Together**
- Include them in finding solutions to recurring problems
- "We keep having trouble getting ready for school on time. What ideas do you have?"

**Logical Consequences**
- Connect consequences directly to the behavior
- If they don't put toys away, those toys are put away for a day

**Emotion Coaching**
- Help them identify and express emotions appropriately
- Teach coping strategies for big feelings

### School-Age Children (Ages 6-11)

**Family Meetings**
- Hold regular family meetings to discuss issues, make plans, and solve problems together
- Give children a voice in family decisions that affect them

**Responsibility and Contribution**
- Assign age-appropriate chores and responsibilities
- Focus on contribution to the family rather than earning rewards

**Collaborative Problem-Solving**
- When conflicts arise, work together to find mutually acceptable solutions
- Teach negotiation and compromise skills

**Mistake-Learning Opportunities**
- Frame mistakes as learning opportunities rather than failures
- Focus on what can be learned and how to do better next time

### Teenagers (Ages 12-18)

**Respect for Autonomy**
- Acknowledge their growing need for independence
- Involve them in setting rules and consequences

**Open Communication**
- Listen more than you talk
- Ask questions to understand their perspective
- Avoid lecturing or preaching

**Natural Consequences**
- Allow them to experience the results of their choices when safe to do so
- Support them in learning from these experiences

**Collaborative Relationship**
- Shift from a controlling relationship to a guiding one
- Respect their opinions even when you disagree

## Practical Positive Discipline Techniques

### 1. Time-In Instead of Time-Out

Rather than isolating a child when they're struggling, try a "time-in" approach:
- Sit with your child until they calm down
- Help them identify their emotions
- Work together to find a solution
- Reconnect before moving forward

### 2. The 4 Rs of Consequences

Effective consequences should be:
- **Related** to the behavior
- **Respectful** of the child
- **Reasonable** in scope and duration
- **Revealed** in advance when possible

### 3. Connection Before Correction

Always prioritize your relationship with your child:
- Make sure they feel heard and understood
- Address their emotional needs first
- Then work on the behavioral issue

### 4. Encourage Rather Than Praise

Focus on effort and improvement rather than just results:
- Instead of "You're so smart!" try "I can see how hard you worked on this!"
- Instead of "Good job!" try "How do you feel about what you accomplished?"

## Common Challenges and Solutions

### "But It Takes Too Long!"

**Challenge**: Positive discipline often requires more time and patience than quick punishments.

**Solution**: 
- Remember that you're investing in long-term character development
- Start with small changes rather than overhauling everything at once
- Be patient with yourself as you learn new approaches

### "My Child Doesn't Respond to Consequences"

**Challenge**: Some children seem unaffected by logical consequences.

**Solution**:
- Examine whether the consequence is truly meaningful to your child
- Make sure you're addressing the underlying need driving the behavior
- Consider whether your child needs additional support (emotional, developmental, etc.)

### "Other People Judge My Parenting"

**Challenge**: Friends, family, or strangers may criticize your positive discipline approach.

**Solution**:
- Stay confident in your choice to parent respectfully
- Educate yourself so you can explain your approach if needed
- Find supportive communities of like-minded parents

### "I Lose My Temper"

**Challenge**: Even with the best intentions, parents sometimes react with anger.

**Solution**:
- Practice self-care to manage your own stress
- Take breaks when you feel overwhelmed
- Apologize to your child when you make mistakes
- Model the behavior you want to see

## Building Emotional Intelligence

One of the greatest gifts of positive discipline is helping children develop emotional intelligence:

### Emotion Identification
- Teach children to name their emotions
- Use emotion charts or books to expand their emotional vocabulary
- Model emotional awareness in yourself

### Emotional Regulation
- Teach calming techniques like deep breathing or counting
- Help them identify their triggers
- Practice problem-solving when emotions are calm

### Empathy Development
- Ask questions like "How do you think your sister felt when that happened?"
- Read books that explore different perspectives
- Model empathy in your daily interactions

## Creating a Positive Family Environment

### Family Values and Rules
- Involve children in creating family rules
- Focus on values rather than rigid rules
- Post family values where everyone can see them

### Routine and Structure
- Maintain consistent daily routines
- Have regular family traditions
- Balance structure with flexibility

### Quality Time
- Spend one-on-one time with each child regularly
- Engage in activities they enjoy
- Be fully present during these times

## Handling Specific Behavioral Challenges

### Tantrums and Meltdowns
- Stay calm and patient
- Validate their emotions while maintaining boundaries
- Help them develop coping strategies for future situations

### Sibling Conflicts
- Avoid taking sides
- Teach conflict resolution skills
- Focus on solutions rather than blame

### Defiance and Power Struggles
- Examine whether the child needs more autonomy
- Offer choices within acceptable limits
- Avoid battles over minor issues

### Lying
- Focus on creating an environment where truth-telling is safe
- Address the underlying reason for the lie
- Model honesty in your own behavior

## The Long-Term Benefits

Children raised with positive discipline tend to become adults who:
- Have strong problem-solving skills
- Show respect for themselves and others
- Are emotionally intelligent and empathetic
- Take responsibility for their actions
- Have healthy relationships
- Are intrinsically motivated
- Can handle life's challenges with resilience

## Getting Started with Positive Discipline

### Begin with Yourself
- Examine your own triggers and reactions
- Practice self-compassion when you make mistakes
- Seek support from other parents or professionals

### Start Small
- Choose one or two strategies to implement first
- Be consistent with these approaches
- Gradually add more techniques as they become natural

### Be Patient
- Remember that change takes time for both you and your child
- Expect setbacks and view them as learning opportunities
- Celebrate small improvements

### Seek Resources
- Read books on positive discipline
- Attend parenting classes or workshops
- Connect with other parents using similar approaches

## Conclusion

Positive discipline isn't about being permissive or letting children do whatever they want. It's about setting clear, consistent boundaries while treating children with respect and dignity. It's about teaching life skills, building character, and maintaining strong, loving relationships.

The journey toward positive discipline is ongoing and requires patience, practice, and self-compassion. There will be challenging days when old patterns resurface or when you question whether you're doing the right thing. Remember that every interaction is an opportunity to teach, connect, and build your child's character.

By choosing positive discipline, you're not just addressing today's behavioral challenges – you're raising tomorrow's emotionally intelligent, respectful, and capable adults. The investment you make now in learning and implementing these strategies will pay dividends for your entire family for years to come.

Remember: parenting is not about perfection. It's about connection, growth, and love. Trust yourself, trust the process, and trust that your commitment to positive discipline is one of the greatest gifts you can give your child."""
    }
}

def update_resource_content():
    """Update resources with comprehensive content"""
    try:
        # Connect to the database
        conn = sqlite3.connect('brightnest.db')
        cursor = conn.cursor()
        
        print("Updating resource content...")
        
        for resource_id, data in ARTICLE_CONTENTS.items():
            cursor.execute(
                "UPDATE resources SET content = ? WHERE id = ?",
                (data["content"], resource_id)
            )
            print(f"Updated resource {resource_id}")
        
        # Commit changes
        conn.commit()
        print(f"Successfully updated {len(ARTICLE_CONTENTS)} resources with comprehensive content!")
        
        # Verify updates
        for resource_id in ARTICLE_CONTENTS.keys():
            cursor.execute("SELECT title, LENGTH(content) as content_length FROM resources WHERE id = ?", (resource_id,))
            result = cursor.fetchone()
            if result:
                title, length = result
                print(f"  - {title}: {length} characters")
        
    except sqlite3.Error as e:
        print(f"Database error: {e}")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    update_resource_content() 