#!/usr/bin/env python3
"""
Seed script to populate the database with sample resources and categories.
Run this after the database tables are created.
"""

import sys
import os
from sqlalchemy.orm import Session

# Add the backend directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from database import SessionLocal
from models import ResourceCategory, Resource

def seed_categories(db: Session):
    """Create sample resource categories"""
    categories = [
        {
            "name": "Anxiety",
            "description": "Resources for managing childhood anxiety and worry",
            "icon": "heart-pulse",
            "color": "#f59e0b"
        },
        {
            "name": "Sleep",
            "description": "Sleep routines, bedtime struggles, and rest strategies",
            "icon": "moon",
            "color": "#6366f1"
        },
        {
            "name": "Behavior",
            "description": "Managing challenging behaviors and promoting positive habits",
            "icon": "users",
            "color": "#10b981"
        },
        {
            "name": "Emotional Regulation",
            "description": "Helping children understand and manage their emotions",
            "icon": "heart",
            "color": "#ef4444"
        },
        {
            "name": "Social Skills",
            "description": "Building friendships and social confidence",
            "icon": "user-group",
            "color": "#8b5cf6"
        },
        {
            "name": "School & Learning",
            "description": "Academic support, homework help, and learning challenges",
            "icon": "academic-cap",
            "color": "#06b6d4"
        },
        {
            "name": "Family Dynamics",
            "description": "Sibling relationships, family communication, and household harmony",
            "icon": "home",
            "color": "#f97316"
        },
        {
            "name": "Self-Esteem",
            "description": "Building confidence and positive self-image",
            "icon": "star",
            "color": "#eab308"
        }
    ]
    
    created_categories = {}
    for cat_data in categories:
        # Check if category already exists
        existing = db.query(ResourceCategory).filter(ResourceCategory.name == cat_data["name"]).first()
        if not existing:
            category = ResourceCategory(**cat_data)
            db.add(category)
            db.commit()
            db.refresh(category)
            created_categories[cat_data["name"]] = category
            print(f"✅ Created category: {cat_data['name']}")
        else:
            created_categories[cat_data["name"]] = existing
            print(f"⚠️  Category already exists: {cat_data['name']}")
    
    return created_categories

def seed_resources(db: Session, categories: dict):
    """Create sample resources"""
    resources = [
        # Anxiety Resources
        {
            "title": "Understanding Childhood Anxiety: A Parent's Guide",
            "description": "Learn to recognize anxiety symptoms in children and discover practical strategies to help them cope with worry and fear.",
            "content": "This comprehensive guide covers the signs of childhood anxiety, age-appropriate coping strategies, and when to seek professional help.",
            "resource_type": "article",
            "category": "Anxiety",
            "min_age": 4,
            "max_age": 12,
            "tags": "anxiety, worry, fear, coping-strategies",
            "author": "Dr. Sarah Johnson, Child Psychologist",
            "read_time_minutes": 15,
            "difficulty_level": "beginner",
            "is_featured": True
        },
        {
            "title": "Breathing Exercises for Anxious Kids",
            "description": "Simple breathing techniques that children can use to calm themselves during anxious moments.",
            "resource_type": "pdf",
            "file_path": "/resources/breathing-exercises-kids.pdf",
            "category": "Anxiety",
            "min_age": 5,
            "max_age": 10,
            "tags": "breathing, relaxation, calm, anxiety",
            "read_time_minutes": 5,
            "difficulty_level": "beginner",
            "is_featured": True
        },
        
        # Sleep Resources
        {
            "title": "Creating the Perfect Bedtime Routine",
            "description": "Step-by-step guide to establishing consistent bedtime routines that help children fall asleep easier and sleep better.",
            "content": "A structured bedtime routine is crucial for good sleep. This guide provides age-specific routines and troubleshooting tips.",
            "resource_type": "article",
            "category": "Sleep",
            "min_age": 2,
            "max_age": 10,
            "tags": "bedtime, routine, sleep, consistency",
            "author": "Dr. Michael Chen, Sleep Specialist",
            "read_time_minutes": 12,
            "difficulty_level": "beginner"
        },
        {
            "title": "Overcoming Bedtime Fears and Nightmares",
            "description": "Practical strategies for helping children cope with bedtime fears, monsters under the bed, and recurring nightmares.",
            "resource_type": "video",
            "url": "https://youtube.com/watch?v=example-bedtime-fears",
            "thumbnail_url": "/images/bedtime-fears-thumb.jpg",
            "category": "Sleep",
            "min_age": 3,
            "max_age": 8,
            "tags": "fears, nightmares, bedtime, comfort",
            "author": "Child Sleep Solutions",
            "read_time_minutes": 20,
            "difficulty_level": "intermediate"
        },
        
        # Behavior Resources
        {
            "title": "Positive Discipline Strategies That Actually Work",
            "description": "Evidence-based discipline techniques that build cooperation while maintaining clear boundaries.",
            "content": "Move beyond punishment to positive discipline approaches that teach children self-control and responsibility.",
            "resource_type": "article",
            "category": "Behavior",
            "min_age": 2,
            "max_age": 12,
            "tags": "discipline, positive-parenting, boundaries, cooperation",
            "author": "Dr. Lisa Rodriguez, Family Therapist",
            "read_time_minutes": 18,
            "difficulty_level": "intermediate",
            "is_featured": True
        },
        {
            "title": "Managing Meltdowns: A Quick Reference Guide",
            "description": "What to do before, during, and after a child's emotional meltdown. Includes prevention strategies and de-escalation techniques.",
            "resource_type": "pdf",
            "file_path": "/resources/meltdown-guide.pdf",
            "category": "Behavior",
            "min_age": 2,
            "max_age": 8,
            "tags": "meltdowns, tantrums, emotional-regulation, de-escalation",
            "read_time_minutes": 8,
            "difficulty_level": "beginner"
        },
        
        # Emotional Regulation Resources
        {
            "title": "Teaching Kids to Name Their Emotions",
            "description": "Help children develop emotional vocabulary and awareness through games, activities, and daily practices.",
            "resource_type": "article",
            "category": "Emotional Regulation",
            "min_age": 3,
            "max_age": 10,
            "tags": "emotions, feelings, vocabulary, awareness",
            "author": "Dr. Emma Thompson, Child Development Specialist",
            "read_time_minutes": 10,
            "difficulty_level": "beginner"
        },
        {
            "title": "The Emotion Regulation Toolkit",
            "description": "Printable activities, emotion cards, and coping strategy cards to help children manage big feelings.",
            "resource_type": "pdf",
            "file_path": "/resources/emotion-toolkit.pdf",
            "category": "Emotional Regulation",
            "min_age": 4,
            "max_age": 12,
            "tags": "toolkit, activities, coping, feelings",
            "read_time_minutes": 30,
            "difficulty_level": "intermediate",
            "is_featured": True
        },
        
        # Social Skills Resources
        {
            "title": "Making Friends: A Guide for Shy Children",
            "description": "Strategies to help introverted and shy children build social confidence and develop meaningful friendships.",
            "resource_type": "article",
            "category": "Social Skills",
            "min_age": 5,
            "max_age": 12,
            "tags": "friendship, shy, social-skills, confidence",
            "author": "Dr. James Park, Social Skills Specialist",
            "read_time_minutes": 14,
            "difficulty_level": "intermediate"
        },
        
        # School & Learning Resources
        {
            "title": "Homework Without Tears: Making Study Time Peaceful",
            "description": "Transform homework battles into collaborative learning time with these proven strategies.",
            "resource_type": "article",
            "category": "School & Learning",
            "min_age": 6,
            "max_age": 12,
            "tags": "homework, study, learning, cooperation",
            "author": "Dr. Karen Williams, Educational Psychologist",
            "read_time_minutes": 16,
            "difficulty_level": "beginner"
        },
        
        # Family Dynamics Resources
        {
            "title": "Sibling Rivalry: Promoting Cooperation Over Competition",
            "description": "Reduce sibling conflicts and foster positive relationships between brothers and sisters.",
            "resource_type": "article",
            "category": "Family Dynamics",
            "min_age": 2,
            "max_age": 12,
            "tags": "siblings, rivalry, cooperation, family",
            "author": "Dr. Rachel Green, Family Counselor",
            "read_time_minutes": 12,
            "difficulty_level": "intermediate"
        },
        
        # Self-Esteem Resources
        {
            "title": "Building Unshakeable Confidence in Your Child",
            "description": "Daily practices and mindset shifts that help children develop genuine self-confidence and resilience.",
            "resource_type": "article",
            "category": "Self-Esteem",
            "min_age": 4,
            "max_age": 12,
            "tags": "confidence, self-esteem, resilience, growth-mindset",
            "author": "Dr. Amanda Foster, Child Psychologist",
            "read_time_minutes": 20,
            "difficulty_level": "intermediate",
            "is_featured": True
        }
    ]
    
    created_count = 0
    for resource_data in resources:
        # Get the category
        category_name = resource_data.pop("category")
        category = categories.get(category_name)
        
        if not category:
            print(f"❌ Category '{category_name}' not found for resource: {resource_data['title']}")
            continue
        
        # Check if resource already exists
        existing = db.query(Resource).filter(Resource.title == resource_data["title"]).first()
        if not existing:
            resource_data["category_id"] = category.id
            resource = Resource(**resource_data)
            db.add(resource)
            created_count += 1
            print(f"✅ Created resource: {resource_data['title']}")
        else:
            print(f"⚠️  Resource already exists: {resource_data['title']}")
    
    if created_count > 0:
        db.commit()
        print(f"\n🎉 Successfully created {created_count} resources!")
    else:
        print("\n⚠️  No new resources were created.")

def main():
    """Main seeding function"""
    print("🌱 Starting Resource Hub database seeding...")
    
    db = SessionLocal()
    try:
        # Create categories first
        print("\n📂 Creating resource categories...")
        categories = seed_categories(db)
        
        # Create resources
        print("\n📚 Creating sample resources...")
        seed_resources(db, categories)
        
        print("\n✅ Resource Hub seeding completed successfully!")
        
    except Exception as e:
        print(f"\n❌ Error during seeding: {e}")
        db.rollback()
        raise
    finally:
        db.close()

if __name__ == "__main__":
    main() 