"""
AI Suggestion Variety Manager
=============================

This module provides functions to manage suggestion variety and prevent repetitive
AI recommendations by tracking history and implementing smart selection algorithms.
"""

from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import desc, and_
import models
import random
from ai_config import config

def get_recent_suggestions(db: Session, child_id: int, suggestion_type: str, days: int = 7) -> List[models.SuggestionHistory]:
    """Get recent suggestions for a child within the specified number of days."""
    cutoff_date = datetime.utcnow() - timedelta(days=days)
    
    return db.query(models.SuggestionHistory).filter(
        and_(
            models.SuggestionHistory.child_id == child_id,
            models.SuggestionHistory.suggestion_type == suggestion_type,
            models.SuggestionHistory.suggested_at >= cutoff_date
        )
    ).order_by(desc(models.SuggestionHistory.suggested_at)).all()

def track_suggestion(db: Session, child_id: int, suggestion_type: str, suggestion_id: int, 
                    suggestion_text: str, emotion_rating: int, notes: Optional[str] = None):
    """Track a suggestion in the history."""
    # Create new history entry
    history_entry = models.SuggestionHistory(
        child_id=child_id,
        suggestion_type=suggestion_type,
        suggestion_id=suggestion_id,
        suggestion_text=suggestion_text,
        emotion_rating=emotion_rating,
        notes=notes
    )
    
    db.add(history_entry)
    
    # Clean up old history entries (keep only the most recent ones)
    cleanup_old_suggestions(db, child_id, suggestion_type)
    
    db.commit()

def cleanup_old_suggestions(db: Session, child_id: int, suggestion_type: str):
    """Keep only the most recent suggestions, delete older ones."""
    # Get count of current suggestions
    total_suggestions = db.query(models.SuggestionHistory).filter(
        and_(
            models.SuggestionHistory.child_id == child_id,
            models.SuggestionHistory.suggestion_type == suggestion_type
        )
    ).count()
    
    # If we exceed the limit, delete the oldest ones
    if total_suggestions >= config.SUGGESTION_HISTORY_LIMIT:
        # Get the oldest suggestions to delete
        suggestions_to_delete = db.query(models.SuggestionHistory).filter(
            and_(
                models.SuggestionHistory.child_id == child_id,
                models.SuggestionHistory.suggestion_type == suggestion_type
            )
        ).order_by(models.SuggestionHistory.suggested_at).limit(
            total_suggestions - config.SUGGESTION_HISTORY_LIMIT + 1
        ).all()
        
        for suggestion in suggestions_to_delete:
            db.delete(suggestion)

def apply_variety_scoring(tips_or_habits: List[Any], recent_suggestions: List[models.SuggestionHistory], 
                         base_scores: Dict[int, int]) -> Dict[int, int]:
    """Apply variety penalties to recently used suggestions."""
    if not config.VARIETY_BOOST_ENABLED:
        return base_scores
    
    # Create sets of recently used suggestion IDs for fast lookup
    very_recent_ids = set()  # Within 3 days
    recent_ids = set()  # Within 7 days
    
    cutoff_very_recent = datetime.utcnow() - timedelta(days=3)
    cutoff_recent = datetime.utcnow() - timedelta(days=config.SUGGESTION_COOLDOWN_DAYS)
    
    for suggestion in recent_suggestions:
        if suggestion.suggested_at >= cutoff_very_recent:
            very_recent_ids.add(suggestion.suggestion_id)
        elif suggestion.suggested_at >= cutoff_recent:
            recent_ids.add(suggestion.suggestion_id)
    
    # Apply penalties
    modified_scores = base_scores.copy()
    
    for item in tips_or_habits:
        item_id = item.id
        if item_id in very_recent_ids:
            # Heavy penalty for very recent suggestions
            modified_scores[item_id] = max(0, modified_scores.get(item_id, 0) - config.VARIETY_PENALTY_VERY_RECENT)
        elif item_id in recent_ids:
            # Lighter penalty for recent suggestions
            modified_scores[item_id] = max(0, modified_scores.get(item_id, 0) - config.VARIETY_PENALTY_RECENT)
    
    return modified_scores

def apply_category_rotation(tips_or_habits: List[Any], recent_suggestions: List[models.SuggestionHistory], 
                           base_scores: Dict[int, int]) -> Dict[int, int]:
    """Apply category rotation logic to encourage variety in suggestion categories."""
    if not config.ENABLE_CATEGORY_ROTATION:
        return base_scores
    
    # Count recent categories used
    recent_categories = {}
    cutoff_date = datetime.utcnow() - timedelta(days=config.SUGGESTION_COOLDOWN_DAYS)
    
    for suggestion in recent_suggestions:
        if suggestion.suggested_at >= cutoff_date:
            # Extract category from suggestion - we'll need to enhance this
            # For now, we'll use a simple approach
            category = getattr(suggestion, 'category', 'general')
            recent_categories[category] = recent_categories.get(category, 0) + 1
    
    # Apply category rotation boost
    modified_scores = base_scores.copy()
    
    for item in tips_or_habits:
        item_category = getattr(item, 'tip_category', getattr(item, 'category', 'general'))
        if item_category:
            category_usage = recent_categories.get(item_category, 0)
            
            # If a category has been used too much recently, reduce its score
            if category_usage >= config.CATEGORY_ROTATION_THRESHOLD:
                penalty = category_usage * 2  # Increasing penalty for overused categories
                item_id = item.id
                modified_scores[item_id] = max(0, modified_scores.get(item_id, 0) - penalty)
            # If a category hasn't been used recently, give it a small boost
            elif category_usage == 0:
                item_id = item.id
                modified_scores[item_id] = modified_scores.get(item_id, 0) + 2
    
    return modified_scores

def select_with_variety(tips_or_habits: List[Any], scores: Dict[int, int], 
                       exclude_ids: set = None, min_score: int = 0) -> Any:
    """Select a suggestion with variety considerations."""
    if not tips_or_habits:
        return None
    
    # Filter out excluded suggestions
    if exclude_ids:
        available_items = [item for item in tips_or_habits if item.id not in exclude_ids]
    else:
        available_items = tips_or_habits
    
    # Filter out items with scores below minimum threshold
    if min_score > 0:
        available_items = [item for item in available_items if scores.get(item.id, 0) >= min_score]
    
    if not available_items:
        # If all suggestions are excluded, fall back to original list but still respect min_score
        if min_score > 0:
            available_items = [item for item in tips_or_habits if scores.get(item.id, 0) >= min_score]
        if not available_items:
            available_items = tips_or_habits  # Ultimate fallback
    
    # If randomization is enabled, sometimes pick a random good suggestion
    if config.ENABLE_RANDOMIZATION and random.random() < config.RANDOMIZATION_FACTOR:
        # Get items with decent scores (above 1 or min_score, whichever is higher)
        threshold = max(1, min_score)
        good_items = [item for item in available_items if scores.get(item.id, 0) >= threshold]
        if good_items:
            return random.choice(good_items)
    
    # Otherwise, pick the highest scoring item
    best_item = None
    best_score = -1
    
    for item in available_items:
        item_score = scores.get(item.id, 0)
        if item_score > best_score:
            best_score = item_score
            best_item = item
    
    return best_item if best_item else random.choice(available_items)

def get_excluded_suggestion_ids(recent_suggestions: List[models.SuggestionHistory]) -> set:
    """Get set of suggestion IDs that should be excluded due to cooldown period."""
    excluded_ids = set()
    cutoff_date = datetime.utcnow() - timedelta(days=config.SUGGESTION_COOLDOWN_DAYS)
    
    for suggestion in recent_suggestions:
        if suggestion.suggested_at >= cutoff_date:
            excluded_ids.add(suggestion.suggestion_id)
    
    return excluded_ids 