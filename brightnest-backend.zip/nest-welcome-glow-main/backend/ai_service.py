import os
import openai
import logging
from typing import Optional, Dict, Any
import asyncio
import re
from ai_config import config
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

class AIService:
    def __init__(self):
        """
        Initialize AI service with configurable settings.
        This handles all AI interactions for personalizing tips and generating content.
        """
        self.client = None
        self.enabled = config.ENABLED
        self.setup_client()
        
        # Load configuration from ai_config.py
        self.max_response_length = config.MAX_RESPONSE_LENGTH
        self.timeout_seconds = config.TIMEOUT_SECONDS
        self.forbidden_words = config.FORBIDDEN_WORDS + config.FORBIDDEN_CONCEPTS
        self.openai_model = config.OPENAI_MODEL
    
    def setup_client(self):
        """Setup OpenAI client if API key is available"""
        api_key = os.getenv("OPENAI_API_KEY")
        if api_key:
            try:
                # Initialize OpenAI client with just the API key
                self.client = openai.OpenAI(api_key=api_key)
                self.enabled = True
                logger.info("AI service enabled with OpenAI")
            except TypeError as e:
                if "proxies" in str(e):
                    # Handle the proxies argument issue by disabling AI
                    logger.warning(f"OpenAI client initialization failed due to version compatibility: {e}")
                    logger.warning("AI features will be disabled. Consider updating OpenAI library or checking environment.")
                    self.client = None
                    self.enabled = False
                else:
                    logger.error(f"Failed to initialize OpenAI client: {e}")
                    self.client = None
                    self.enabled = False
            except Exception as e:
                logger.error(f"Failed to initialize OpenAI client: {e}")
                self.client = None
                self.enabled = False
        else:
            logger.warning("OPENAI_API_KEY not found. AI personalization disabled.")
            self.client = None
            self.enabled = False
    
    async def personalize_tip(self, base_tip: str, child_age: str, situation_notes: str) -> str:
        """
        Enhance a curated tip with AI personalization based on specific situation.
        
        Args:
            base_tip: Your carefully curated base tip
            child_age: Age group (e.g., "4-7")
            situation_notes: Parent's description of the situation
            
        Returns:
            Personalized version of the tip, or original tip if AI fails
        """
        if not self.enabled or not situation_notes or len(situation_notes) < 10:
            return base_tip  # Return original tip if AI unavailable or insufficient context
        
        try:
            prompt = f"""
You are a child psychology expert. Take this proven parenting tip and personalize it for the specific situation described.

ORIGINAL TIP: "{base_tip}"

CHILD AGE: {child_age} years old
SITUATION: {situation_notes}

Instructions:
- Keep the core advice from the original tip unchanged
- Add 1-2 specific details that relate to the child's situation
- Keep response under 120 words
- Make it actionable and age-appropriate
- Do NOT suggest medical treatment, therapy, or professional intervention
- Do NOT use complex psychological terms

Personalized tip:"""

            response = await self._call_ai_safely(prompt)
            
            if response and self._is_safe_content(response):
                # Ensure response isn't too different from original
                if len(response) <= self.max_response_length:
                    return response.strip()
            
            return base_tip  # Fallback to original on any issues
            
        except Exception as e:
            logger.error(f"AI personalization failed: {e}")
            return base_tip  # Always fallback to curated content
    
    async def generate_contextual_habit(self, age_group: str, emotion_rating: int, 
                                      situation_notes: str, existing_habits: list) -> Optional[Dict[str, Any]]:
        """
        Generate a new habit suggestion when database doesn't have a perfect match.
        This is used as a last resort when curated content doesn't fit.
        
        Args:
            age_group: Child's age group
            emotion_rating: 1-5 emotional state
            situation_notes: Detailed situation description
            existing_habits: List of habits already suggested (to avoid duplicates)
            
        Returns:
            New habit suggestion or None if generation fails
        """
        if not self.enabled or len(situation_notes) < 20:
            if not self.enabled:
                logger.warning("AI service is disabled")
            else:
                logger.warning(f"Situation notes too short ({len(situation_notes)} chars), skipping AI generation")
            return None  # Only generate for detailed situations
        
        try:
            logger.info(f"Generating habit for age {age_group}, emotion {emotion_rating}, notes: {situation_notes[:50]}...")
            
            emotions = {1: "very sad", 2: "sad", 3: "neutral", 4: "happy", 5: "very happy"}
            emotion_desc = emotions.get(emotion_rating, "neutral")
            
            existing_names = [h.get('name', '') for h in existing_habits]
            
            # Determine the best habit category based on the situation and emotion
            category = self._determine_habit_category(emotion_rating, situation_notes)
            
            prompt = f"""
You are a child development expert. Create ONE specific habit recommendation for:

AGE: {age_group} years old
EMOTION: {emotion_desc} ({emotion_rating}/5)
SITUATION: {situation_notes}
SUGGESTED CATEGORY: {category}

AVOID these already suggested habits: {', '.join(existing_names)}

Requirements:
- Create a simple, specific habit (not general advice)
- Make it age-appropriate and achievable
- Focus on the {category} category (see category guidelines below)
- Keep name under 15 words (be descriptive and specific)
- Keep description under 40 words (very concise!)
- Include both a short description and detailed explanation
- Make it UNIQUE and avoid generic names like "Daily Check-in" or "Deep Breathing"
- Be creative and situation-specific

CATEGORY GUIDELINES:
- EMOTIONAL: Focus on feelings, emotional regulation, self-awareness, empathy, gratitude
- PHYSICAL: Focus on movement, exercise, health, body awareness, gross/fine motor skills
- LEARNING: Focus on curiosity, problem-solving, creativity, academic skills, exploration
- OTHER: Focus on practical life skills, responsibility, independence, social skills, routines

Format your response as:
NAME: [habit name]
DESCRIPTION: [1-2 sentence description, max 40 words]
DETAILED_EXPLANATION: [longer explanation for parents, max 80 words]
KEYWORDS: [keyword1, keyword2, keyword3]"""

            response = await self._call_ai_safely(prompt)
            
            if response and self._is_safe_content(response):
                logger.info(f"AI response received: {response[:100]}...")
                parsed_result = self._parse_habit_response(response)
                if parsed_result:
                    logger.info(f"Successfully parsed habit: {parsed_result.get('name', 'Unknown')}")
                    return parsed_result
                else:
                    logger.warning("Failed to parse AI response")
                    return None
            elif response:
                logger.warning("AI response failed safety check")
                return None
            else:
                logger.warning("No response from AI")
                return None
            
        except Exception as e:
            logger.error(f"AI habit generation failed: {e}")
            return None
    
    def _determine_habit_category(self, emotion_rating: int, situation_notes: str) -> str:
        """
        Intelligently determine the best habit category based on the check-in context.
        This ensures a balanced mix of habit types rather than always suggesting emotional habits.
        """
        text = situation_notes.lower()
        
        # Physical activity indicators
        physical_keywords = [
            'tired', 'energy', 'active', 'play', 'run', 'jump', 'dance', 'exercise', 
            'outdoor', 'park', 'sports', 'movement', 'restless', 'hyper', 'calm down',
            'bedtime', 'sleep', 'nap', 'relax', 'stretch', 'yoga', 'walk'
        ]
        
        # Learning/curiosity indicators  
        learning_keywords = [
            'school', 'homework', 'study', 'read', 'book', 'learn', 'curious', 'question',
            'creative', 'art', 'draw', 'paint', 'music', 'instrument', 'build', 'explore',
            'discover', 'experiment', 'problem', 'challenge', 'academic'
        ]
        
        # Practical life skills indicators
        other_keywords = [
            'chore', 'clean', 'organize', 'help', 'responsibility', 'independence', 
            'routine', 'schedule', 'time', 'plan', 'prepare', 'cook', 'garden',
            'sibling', 'friend', 'share', 'cooperate', 'listen', 'follow'
        ]
        
        # Emotional indicators (keep as fallback)
        emotional_keywords = [
            'sad', 'angry', 'frustrated', 'worried', 'anxious', 'scared', 'upset',
            'happy', 'excited', 'proud', 'grateful', 'feelings', 'emotion', 'mood'
        ]
        
        # Count keyword matches for each category
        physical_score = sum(1 for keyword in physical_keywords if keyword in text)
        learning_score = sum(1 for keyword in learning_keywords if keyword in text)
        other_score = sum(1 for keyword in other_keywords if keyword in text)
        emotional_score = sum(1 for keyword in emotional_keywords if keyword in text)
        
        # Special rules for certain emotions
        if emotion_rating <= 2:  # Sad/upset emotions
            # For sad emotions, prioritize physical (movement/calming) or practical (routine) over emotional
            if physical_score > 0:
                return "PHYSICAL"
            elif other_score > 0:
                return "OTHER"
            elif learning_score > 0:
                return "LEARNING"
            else:
                return "EMOTIONAL"  # Fallback
                
        elif emotion_rating >= 4:  # Happy/excited emotions
            # For happy emotions, suggest learning or physical activities to channel energy
            if learning_score > 0:
                return "LEARNING"
            elif physical_score > 0:
                return "PHYSICAL"
            elif other_score > 0:
                return "OTHER"
            else:
                return "LEARNING"  # Default to learning for happy kids
                
        else:  # Neutral emotions
            # For neutral emotions, balance across all categories
            if learning_score > physical_score and learning_score > other_score:
                return "LEARNING"
            elif physical_score > other_score:
                return "PHYSICAL"
            elif other_score > 0:
                return "OTHER"
            else:
                return "EMOTIONAL"  # Fallback
    
    async def _call_ai_safely(self, prompt: str) -> Optional[str]:
        """Make safe AI API call with timeout and error handling"""
        if not self.client:
            return None
        
        try:
            # Use asyncio timeout for safety
            response = await asyncio.wait_for(
                asyncio.to_thread(
                    self.client.chat.completions.create,
                    model=self.openai_model,
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=200,
                    temperature=0.7
                ),
                timeout=self.timeout_seconds
            )
            
            return response.choices[0].message.content
            
        except asyncio.TimeoutError:
            logger.warning("AI API call timed out")
            return None
        except Exception as e:
            logger.error(f"AI API call failed: {e}")
            return None
    
    def _is_safe_content(self, content: str) -> bool:
        """Check if AI-generated content is safe for children/parents"""
        content_lower = content.lower()
        
        # Check for forbidden words
        for word in self.forbidden_words:
            if word in content_lower:
                logger.warning(f"AI content rejected: contains '{word}'")
                return False
        
        # Basic length check
        if len(content) > self.max_response_length:
            logger.warning("AI content rejected: too long")
            return False
        
        return True
    
    def _parse_habit_response(self, response: str) -> Optional[Dict[str, Any]]:
        """Parse AI response into structured habit data"""
        try:
            lines = response.strip().split('\n')
            habit_data = {}
            
            for line in lines:
                if line.startswith('NAME:'):
                    habit_data['name'] = line.replace('NAME:', '').strip()
                elif line.startswith('DESCRIPTION:'):
                    habit_data['description'] = line.replace('DESCRIPTION:', '').strip()
                elif line.startswith('DETAILED_EXPLANATION:'):
                    habit_data['detailed_explanation'] = line.replace('DETAILED_EXPLANATION:', '').strip()
                elif line.startswith('KEYWORDS:'):
                    keywords_text = line.replace('KEYWORDS:', '').strip()
                    # Parse keywords, handling various formats
                    keywords = [k.strip() for k in re.split(r'[,;]', keywords_text) if k.strip()]
                    habit_data['keywords'] = keywords[:5]  # Limit to 5 keywords
            
            # Validate required fields
            if 'name' in habit_data and 'description' in habit_data:
                return habit_data
            
            return None
            
        except Exception as e:
            logger.error(f"Failed to parse habit response: {e}")
            return None

# Global AI service instance
ai_service = AIService() 