# AI-Powered Personalization Setup

## Overview

Your app now has **hybrid AI capabilities** that enhance your curated content with personalization and generate new suggestions when needed.

## How It Works

### 🎯 **Tip Personalization**
- **Your curated tips remain the foundation** (safety & quality)
- **AI adds personalization** when parents provide detailed situation notes (15+ characters)
- **Always falls back** to your original tip if AI fails

### 🧠 **Smart Habit Generation** 
- **Only activates** when your database doesn't have good matches (score < 2)
- **Only for detailed situations** (20+ characters of notes)
- **Always shows your original suggestion** alongside AI-generated one

## Setup Instructions

### 1. Install Requirements
```bash
cd backend
pip install -r requirements.txt
```

### 2. Add OpenAI API Key (Optional)
Add to your `.env` file:
```
OPENAI_API_KEY=sk-your-api-key-here
```

**Without API key:** App works normally with your curated content only
**With API key:** App adds AI personalization layer

### 3. Configuration Options

Edit `backend/config.py` to control AI behavior:

```python
class AIConfig:
    ENABLED = True  # Master switch for all AI features
    PERSONALIZATION_MIN_NOTES_LENGTH = 15  # When to personalize tips
    GENERATION_MIN_NOTES_LENGTH = 20  # When to generate new habits
    LOW_MATCH_THRESHOLD = 2  # When to try AI generation
```

## Safety Features

✅ **Content Filtering**: Blocks medical/therapy suggestions
✅ **Length Limits**: Prevents overly long responses  
✅ **Timeout Protection**: 10-second maximum per AI call
✅ **Graceful Fallbacks**: Always returns your curated content on errors
✅ **Rate Limiting**: Configurable limits to control costs

## Testing the Features

1. **Test Tip Personalization:**
   - Do a check-in with detailed notes (20+ chars)
   - Compare the tip response with/without notes

2. **Test Habit Generation:**
   - Use a situation that doesn't match your existing habits well
   - Provide detailed notes
   - See if AI generates a relevant alternative

## API Response Format

### Enhanced Tip Response
```json
{
  "tip": "Your curated tip, possibly personalized",
  "ai_personalized": true,
  "original_tip": "Your original curated tip",
  "age_group": "4-7",
  "child_name": "Emma"
}
```

### Enhanced Habit Response  
```json
{
  "habit_name": "Bedtime Comfort Routine",
  "habit_description": "Create a special stuffed animal check...",
  "match_type": "ai_generated",
  "original_suggestion": {
    "name": "Your curated habit name",
    "description": "Your curated description"
  }
}
```

## Cost Management

- AI only activates for detailed situations
- Configured rate limits prevent runaway costs
- Most responses still come from your curated database
- Average cost: $0.001-0.005 per AI-enhanced response

## Monitoring

Check logs for AI usage:
```bash
grep "AI personalization" backend.log
grep "AI habit generation" backend.log
``` 