from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

# User schemas
class UserBase(BaseModel):
    email: EmailStr
    full_name: str

class UserCreate(UserBase):
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class User(UserBase):
    id: int
    is_active: bool
    is_first_time: bool
    created_at: datetime

    class Config:
        from_attributes = True

# Child schemas
class ChildBase(BaseModel):
    name: str
    age: int
    photo_url: Optional[str] = None

class ChildCreate(ChildBase):
    pass

class Child(ChildBase):
    id: int
    parent_id: int
    created_at: datetime

    class Config:
        from_attributes = True

# Habit schemas
class HabitBase(BaseModel):
    name: str
    description: Optional[str] = None
    total_days: int

class HabitCreate(HabitBase):
    child_id: int

class HabitUpdate(HabitBase):
    is_active: Optional[bool] = None

class Habit(HabitBase):
    id: int
    child_id: int
    created_at: datetime
    is_active: bool
    completed_days: Optional[int] = 0

    class Config:
        from_attributes = True

# Check-in schemas
class CheckInBase(BaseModel):
    emotion_rating: int  # 1-5
    notes: Optional[str] = None

class CheckInCreate(CheckInBase):
    child_id: int

class CheckIn(CheckInBase):
    id: int
    child_id: int
    created_at: datetime

    class Config:
        from_attributes = True

# CheckIn Tip schemas
class CheckInTipBase(BaseModel):
    ai_tip: str
    habit_suggestion: str
    is_tip_personalized: bool = False
    tip_score: Optional[float] = None

class CheckInTipCreate(CheckInTipBase):
    check_in_id: int

class CheckInTip(CheckInTipBase):
    id: int
    check_in_id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

# Extended CheckIn schema with tips
class CheckInWithTips(CheckIn):
    cached_tip: Optional[CheckInTip] = None

# Feedback schemas
class FeedbackBase(BaseModel):
    content: str
    rating: Optional[float] = None

class FeedbackCreate(FeedbackBase):
    pass

class Feedback(FeedbackBase):
    id: int
    user_id: int
    created_at: datetime

    class Config:
        from_attributes = True

# Token schemas
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: Optional[str] = None

# AI Tips schemas
class AITipBase(BaseModel):
    age_group: str
    emotion_rating: int
    tip_text: str
    tip_category: Optional[str] = None

class AITipCreate(AITipBase):
    pass

class AITip(AITipBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

# Habit Suggestion schemas
class HabitSuggestionBase(BaseModel):
    age_group: str
    emotion_rating: int
    habit_name: str
    habit_description: Optional[str] = None
    keywords: Optional[str] = None

class HabitSuggestionCreate(HabitSuggestionBase):
    pass

class HabitSuggestion(HabitSuggestionBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

# Resource Schemas
class ResourceCategoryBase(BaseModel):
    name: str
    description: Optional[str] = None
    icon: Optional[str] = None
    color: Optional[str] = None

class ResourceCategoryCreate(ResourceCategoryBase):
    pass

class ResourceCategory(ResourceCategoryBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

class ResourceBase(BaseModel):
    title: str
    description: str
    content: Optional[str] = None
    resource_type: str  # "article", "video", "pdf", "guide"
    url: Optional[str] = None
    file_path: Optional[str] = None
    thumbnail_url: Optional[str] = None
    category_id: int
    min_age: Optional[int] = None
    max_age: Optional[int] = None
    tags: Optional[str] = None
    author: Optional[str] = None
    read_time_minutes: Optional[int] = None
    difficulty_level: Optional[str] = None
    is_featured: bool = False
    is_active: bool = True

class ResourceCreate(ResourceBase):
    pass

class ResourceUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    content: Optional[str] = None
    resource_type: Optional[str] = None
    url: Optional[str] = None
    file_path: Optional[str] = None
    thumbnail_url: Optional[str] = None
    category_id: Optional[int] = None
    min_age: Optional[int] = None
    max_age: Optional[int] = None
    tags: Optional[str] = None
    author: Optional[str] = None
    read_time_minutes: Optional[int] = None
    difficulty_level: Optional[str] = None
    is_featured: Optional[bool] = None
    is_active: Optional[bool] = None

class Resource(ResourceBase):
    id: int
    view_count: int
    created_at: datetime
    updated_at: datetime
    category: ResourceCategory

    class Config:
        from_attributes = True

class ResourceRecommendationBase(BaseModel):
    resource_id: int
    child_id: Optional[int] = None
    reason: Optional[str] = None
    confidence_score: Optional[float] = None
    based_on_data: Optional[str] = None

class ResourceRecommendationCreate(ResourceRecommendationBase):
    pass

class ResourceRecommendation(ResourceRecommendationBase):
    id: int
    user_id: int
    is_viewed: bool
    is_bookmarked: bool
    is_helpful: Optional[bool] = None
    created_at: datetime
    viewed_at: Optional[datetime] = None
    resource: Resource

    class Config:
        from_attributes = True 