"""
Database migration script to create the check_in_tips table for caching AI tips
"""

from sqlalchemy import create_engine
from config import settings
from models import Base
from database import engine

def create_checkin_tips_table():
    """Create the check_in_tips table using SQLAlchemy models"""
    
    try:
        # This will create all tables defined in models.py that don't exist yet
        Base.metadata.create_all(bind=engine)
        print("Successfully created/updated database tables including check_in_tips")
        
        # For SQLite, we can add indexes manually if needed
        if "sqlite" in str(engine.url):
            print("Detected SQLite database - tables created successfully")
        else:
            print("Detected PostgreSQL database - tables created successfully")
            
    except Exception as e:
        print(f"Error creating tables: {e}")
        raise

if __name__ == "__main__":
    create_checkin_tips_table() 