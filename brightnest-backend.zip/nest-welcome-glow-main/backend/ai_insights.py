def get_contextual_score(notes: str, content: str, child_age: int) -> tuple[int, bool]:
    """
    Universal contextual matching that works for all age groups.
    Returns (score_boost, context_detected)
    """
    if not notes or not notes.strip():
        return 0, False
    
    notes_lower = notes.lower()
    content_lower = content.lower()
    context_detected = False
    score_boost = 0
    
    # Sleep/bedtime related issues (universal across all ages)
    sleep_triggers = ['sleep', 'nap', 'woke', 'wake', 'nightmare', 'tired', 'bedtime', 'teething']
    if child_age <= 3:
        sleep_triggers.extend(['cranky', 'fussy', 'overtired'])
    elif child_age <= 7:
        sleep_triggers.extend(['bad dreams', 'scared', 'restless'])
    else:  # 8-10
        sleep_triggers.extend(['insomnia', 'anxious', 'worry', 'stress'])
    
    if any(word in notes_lower for word in sleep_triggers):
        sleep_solutions = ['sleep', 'rest', 'bedtime', 'quiet', 'calm', 'routine', 'nap', 'soothe']
        if child_age <= 3:
            sleep_solutions.extend(['rock', 'cuddle', 'lullaby'])
        elif child_age <= 7:
            sleep_solutions.extend(['story', 'soft music', 'comfort'])
        else:  # 8-10
            sleep_solutions.extend(['relaxation', 'breathing', 'mindfulness'])
            
        if any(word in content_lower for word in sleep_solutions):
            score_boost += 5
            context_detected = True
        # Penalize irrelevant content
        elif any(word in content_lower for word in ['goodbye', 'leaving', 'separation', 'school friends', 'homework']):
            score_boost -= 3
            
    # Eating/food related issues (universal)
    elif any(word in notes_lower for word in ['eat', 'food', 'hungry', 'meal', 'lunch', 'dinner', 'breakfast', 'picky', 'refuse']):
        food_solutions = ['eat', 'food', 'meal', 'hungry', 'feed', 'nutrition']
        if child_age <= 3:
            food_solutions.extend(['bottle', 'spoon', 'finger food'])
        elif child_age <= 7:
            food_solutions.extend(['try new', 'colorful', 'fun'])
        else:  # 8-10
            food_solutions.extend(['healthy choices', 'balanced', 'cooking'])
            
        if any(word in content_lower for word in food_solutions):
            score_boost += 5
            context_detected = True
        elif any(word in content_lower for word in ['sleep', 'goodbye', 'friend', 'school']):
            score_boost -= 3
            
    # Social/friendship/school issues (age-appropriate)
    elif any(word in notes_lower for word in ['friend', 'play', 'social', 'classmate', 'school', 'nursery', 'teacher', 'peer']):
        social_solutions = ['friend', 'social', 'play', 'school', 'share', 'together']
        if child_age <= 3:
            social_solutions.extend(['parallel play', 'turn taking', 'sharing'])
        elif child_age <= 7:
            social_solutions.extend(['cooperation', 'teamwork', 'inclusion', 'kindness'])
        else:  # 8-10
            social_solutions.extend(['communication', 'conflict resolution', 'empathy', 'peer relationships'])
            
        if any(word in content_lower for word in social_solutions):
            score_boost += 5
            context_detected = True
        elif any(word in content_lower for word in ['sleep', 'eat', 'bedtime']):
            score_boost -= 3
            
    # Academic/homework issues (mainly for older children)
    elif any(word in notes_lower for word in ['homework', 'study', 'test', 'grade', 'learning', 'reading', 'math']):
        academic_solutions = ['homework', 'study', 'learning', 'practice', 'reading', 'focus']
        if child_age <= 3:
            academic_solutions = ['learning', 'explore', 'discover']  # Simple for toddlers
        elif child_age <= 7:
            academic_solutions.extend(['fun learning', 'games', 'creative'])
        else:  # 8-10
            academic_solutions.extend(['organization', 'time management', 'study skills'])
            
        if any(word in content_lower for word in academic_solutions):
            score_boost += 5
            context_detected = True
        elif any(word in content_lower for word in ['sleep', 'eat', 'goodbye']):
            score_boost -= 3
            
    # Separation/goodbye issues (universal but age-appropriate)
    elif any(word in notes_lower for word in ['goodbye', 'leaving', 'separation', 'miss', 'away', 'drop off']):
        separation_solutions = ['goodbye', 'separation', 'leaving', 'miss', 'comfort']
        if child_age <= 3:
            separation_solutions.extend(['transition', 'routine', 'lovey'])
        elif child_age <= 7:
            separation_solutions.extend(['independence', 'confidence', 'security'])
        else:  # 8-10
            separation_solutions.extend(['coping', 'understanding', 'communication'])
            
        if any(word in content_lower for word in separation_solutions):
            score_boost += 5
            context_detected = True
        elif any(word in content_lower for word in ['sleep', 'eat', 'friend']):
            score_boost -= 3
            
    # Behavioral issues (age-appropriate)
    elif any(word in notes_lower for word in ['tantrum', 'meltdown', 'angry', 'frustrated', 'defiant', 'aggressive']):
        behavior_solutions = ['calm', 'patience', 'understanding', 'boundaries']
        if child_age <= 3:
            behavior_solutions.extend(['redirect', 'distraction', 'comfort'])
        elif child_age <= 7:
            behavior_solutions.extend(['choices', 'consequences', 'emotions'])
        else:  # 8-10
            behavior_solutions.extend(['self-regulation', 'problem-solving', 'communication'])
            
        if any(word in content_lower for word in behavior_solutions):
            score_boost += 5
            context_detected = True
            
    # General emotional distress (universal)
    elif any(word in notes_lower for word in ['crying', 'upset', 'sad', 'worried', 'anxious']):
        emotional_solutions = ['comfort', 'calm', 'soothe', 'support', 'listen']
        if child_age <= 3:
            emotional_solutions.extend(['hold', 'cuddle', 'rock'])
        elif child_age <= 7:
            emotional_solutions.extend(['validate', 'understand', 'talk'])
        else:  # 8-10
            emotional_solutions.extend(['express', 'feelings', 'coping strategies'])
            
        if any(word in content_lower for word in emotional_solutions):
            score_boost += 4
            context_detected = True
    
    # Penalize generic validation when specific context exists
    if context_detected and len([word for word in ['validate', 'acknowledge', 'understand'] if word in content_lower]) > 0:
        # Check if it's ONLY generic validation without specific context
        if not any(word in content_lower for word in ['sleep', 'eat', 'friend', 'comfort', 'calm', 'soothe', 'play', 'school']):
            score_boost -= 2
    
    return score_boost, context_detected 