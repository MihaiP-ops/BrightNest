#!/usr/bin/env python3

import csv
import psycopg2
import json
from config import get_settings

def import_habits_from_csv(csv_file):
    """Import habit suggestions from CSV file"""
    settings = get_settings()
    conn = psycopg2.connect(settings.DATABASE_URL)
    cur = conn.cursor()
    
    imported_count = 0
    
    try:
        with open(csv_file, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            
            for row in reader:
                age_group = row['age_group'].strip()
                emotion_rating = int(row['emotion_rating'])
                habit_name = row['habit_name'].strip()
                habit_description = row['habit_description'].strip()
                
                # Parse keywords JSON string to Python list
                keywords_str = row['keywords'].strip()
                try:
                    keywords = json.loads(keywords_str)
                except json.JSONDecodeError:
                    print(f"Warning: Invalid JSON for keywords: {keywords_str}")
                    keywords = []
                
                # Insert into database
                cur.execute("""
                    INSERT INTO habit_suggestions (age_group, emotion_rating, habit_name, habit_description, keywords)
                    VALUES (%s, %s, %s, %s, %s)
                """, (age_group, emotion_rating, habit_name, habit_description, keywords))
                
                imported_count += 1
        
        conn.commit()
        print(f"✅ Successfully imported {imported_count} habit suggestions from {csv_file}")
        
    except Exception as e:
        print(f"❌ Error importing habits: {e}")
        conn.rollback()
    finally:
        cur.close()
        conn.close()

def show_stats():
    """Show current database statistics"""
    settings = get_settings()
    conn = psycopg2.connect(settings.DATABASE_URL)
    cur = conn.cursor()
    
    print("\n📊 Current Habit Suggestions in Database:")
    cur.execute("""
        SELECT age_group, emotion_rating, COUNT(*) as count
        FROM habit_suggestions 
        GROUP BY age_group, emotion_rating 
        ORDER BY age_group, emotion_rating
    """)
    
    results = cur.fetchall()
    for age_group, emotion, count in results:
        emotion_names = {1: "Very Sad", 2: "Sad", 3: "Neutral", 4: "Happy", 5: "Very Happy"}
        emotion_name = emotion_names.get(emotion, f"Emotion {emotion}")
        print(f"  Age {age_group}, {emotion_name}: {count} habits")
    
    # Total count
    cur.execute("SELECT COUNT(*) FROM habit_suggestions")
    result = cur.fetchone()
    total = result[0] if result else 0
    print(f"\n🎯 Total: {total} habit suggestions")
    
    cur.close()
    conn.close()

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) != 2:
        print("Usage: python import_habits_8-10.py <csv_file>")
        print("       python import_habits_8-10.py --stats")
        sys.exit(1)
    
    if sys.argv[1] == "--stats":
        show_stats()
    else:
        import_habits_from_csv(sys.argv[1])
        show_stats() 