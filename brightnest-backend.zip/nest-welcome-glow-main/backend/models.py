from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Text, Float, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base
from datetime import datetime

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    full_name = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    is_active = Column(Boolean, default=True)
    is_first_time = Column(Boolean, default=True)

    children = relationship("Child", back_populates="parent")
    feedback = relationship("Feedback", back_populates="user")

class Child(Base):
    __tablename__ = "children"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    age = Column(Integer)
    photo_url = Column(String, nullable=True)
    parent_id = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    parent = relationship("User", back_populates="children")
    habits = relationship("Habit", back_populates="child")
    check_ins = relationship("CheckIn", back_populates="child")
    suggestion_history = relationship("SuggestionHistory", back_populates="child")

class Habit(Base):
    __tablename__ = "habits"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    description = Column(Text, nullable=True)
    total_days = Column(Integer)  # Target days per week
    child_id = Column(Integer, ForeignKey("children.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    is_active = Column(Boolean, default=True)

    child = relationship("Child", back_populates="habits")
    completions = relationship("HabitCompletion", back_populates="habit")

class HabitCompletion(Base):
    __tablename__ = "habit_completions"

    id = Column(Integer, primary_key=True, index=True)
    habit_id = Column(Integer, ForeignKey("habits.id"))
    completed_at = Column(DateTime(timezone=True), server_default=func.now())

    habit = relationship("Habit", back_populates="completions")

class CheckIn(Base):
    __tablename__ = "check_ins"

    id = Column(Integer, primary_key=True, index=True)
    child_id = Column(Integer, ForeignKey("children.id"))
    emotion_rating = Column(Integer)  # 1-5 scale
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    child = relationship("Child", back_populates="check_ins")
    cached_tip = relationship("CheckInTip", back_populates="check_in", uselist=False)

class Feedback(Base):
    __tablename__ = "feedback"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    content = Column(Text)
    rating = Column(Float, nullable=True)  # Optional rating
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="feedback")

class AITip(Base):
    __tablename__ = "ai_tips"

    id = Column(Integer, primary_key=True, index=True)
    age_group = Column(String, nullable=False)  # '0-3', '4-7', '8-10'
    emotion_rating = Column(Integer, nullable=False)  # 1-5
    tip_text = Column(Text, nullable=False)
    tip_category = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class HabitSuggestion(Base):
    __tablename__ = "habit_suggestions"

    id = Column(Integer, primary_key=True, index=True)
    age_group = Column(String, nullable=False)
    emotion_rating = Column(Integer, nullable=False)
    habit_name = Column(String, nullable=False)
    habit_description = Column(Text, nullable=True)
    keywords = Column(Text, nullable=True)  # JSON array as text
    created_at = Column(DateTime(timezone=True), server_default=func.now()) 

class SuggestionHistory(Base):
    __tablename__ = "suggestion_history"
    
    id = Column(Integer, primary_key=True, index=True)
    child_id = Column(Integer, ForeignKey("children.id"), nullable=False)
    suggestion_type = Column(String, nullable=False)  # "tip" or "habit"
    suggestion_id = Column(Integer, nullable=False)  # ID of the tip or habit
    suggestion_text = Column(Text, nullable=False)  # The actual suggestion text
    emotion_rating = Column(Integer, nullable=False)
    notes = Column(Text)
    suggested_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    child = relationship("Child", back_populates="suggestion_history")

class CheckInTip(Base):
    __tablename__ = "check_in_tips"
    
    id = Column(Integer, primary_key=True, index=True)
    check_in_id = Column(Integer, ForeignKey("check_ins.id"), nullable=False, unique=True)
    ai_tip = Column(Text, nullable=False)  # The AI generated tip
    habit_suggestion = Column(Text, nullable=False)  # The AI generated habit suggestion
    is_tip_personalized = Column(Boolean, default=False)  # Whether the tip was personalized
    tip_score = Column(Float, nullable=True)  # Score for the selected tip
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    # Relationships - use uselist=False for one-to-one relationship
    check_in = relationship("CheckIn", back_populates="cached_tip")

class ResourceCategory(Base):
    __tablename__ = "resource_categories"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)  # e.g., "Anxiety", "Sleep", "Behavior"
    description = Column(Text, nullable=True)
    icon = Column(String, nullable=True)  # Icon name for UI
    color = Column(String, nullable=True)  # Color code for UI
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    resources = relationship("Resource", back_populates="category")

class Resource(Base):
    __tablename__ = "resources"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    description = Column(Text)
    content = Column(Text, nullable=True)  # Full article content (optional)
    resource_type = Column(String)  # "article", "video", "pdf", "guide"
    url = Column(String, nullable=True)  # External URL for videos/articles
    file_path = Column(String, nullable=True)  # Local file path for PDFs/guides
    thumbnail_url = Column(String, nullable=True)
    
    # Targeting
    category_id = Column(Integer, ForeignKey("resource_categories.id"))
    min_age = Column(Integer, nullable=True)  # Minimum child age
    max_age = Column(Integer, nullable=True)  # Maximum child age
    tags = Column(String, nullable=True)  # Comma-separated tags for filtering
    
    # Metadata
    author = Column(String, nullable=True)
    read_time_minutes = Column(Integer, nullable=True)
    difficulty_level = Column(String, nullable=True)  # "beginner", "intermediate", "advanced"
    is_featured = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    view_count = Column(Integer, default=0)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    category = relationship("ResourceCategory", back_populates="resources")
    recommendations = relationship("ResourceRecommendation", back_populates="resource")

class ResourceRecommendation(Base):
    __tablename__ = "resource_recommendations"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    child_id = Column(Integer, ForeignKey("children.id"), nullable=True)  # Can be child-specific
    resource_id = Column(Integer, ForeignKey("resources.id"))
    
    # AI recommendation metadata
    reason = Column(Text, nullable=True)  # Why this was recommended
    confidence_score = Column(Float, nullable=True)  # AI confidence in recommendation
    based_on_data = Column(Text, nullable=True)  # What data drove this recommendation
    
    # User interaction
    is_viewed = Column(Boolean, default=False)
    is_bookmarked = Column(Boolean, default=False)
    is_helpful = Column(Boolean, nullable=True)  # User feedback
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    viewed_at = Column(DateTime(timezone=True), nullable=True)
    
    user = relationship("User")
    child = relationship("Child")
    resource = relationship("Resource", back_populates="recommendations") 