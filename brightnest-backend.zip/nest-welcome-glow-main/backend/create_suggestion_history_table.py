#!/usr/bin/env python3
"""
Database Migration: Add Suggestion History Table
===============================================

This script creates the suggestion_history table to track AI suggestions
and prevent repetitive recommendations.

Run this script once to add the table to your database.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from sqlalchemy import create_engine, text
from config import get_settings
import models
from database import Base

def create_suggestion_history_table():
    """Create the suggestion_history table"""
    settings = get_settings()
    engine = create_engine(settings.DATABASE_URL)
    
    print("🗄️ Creating suggestion_history table...")
    
    try:
        # Create the table
        Base.metadata.create_all(bind=engine, tables=[models.SuggestionHistory.__table__])
        
        print("✅ Successfully created suggestion_history table!")
        
        # Verify the table was created
        with engine.connect() as connection:
            result = connection.execute(text(
                "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'suggestion_history'"
            ))
            table_count = result.scalar()
            
            if table_count > 0:
                print("✅ Table verification successful!")
                print("\n📊 Table structure:")
                
                # Show table structure
                result = connection.execute(text(
                    "SELECT column_name, data_type, is_nullable FROM information_schema.columns WHERE table_name = 'suggestion_history' ORDER BY ordinal_position"
                ))
                
                for row in result:
                    nullable = "NULL" if row[2] == "YES" else "NOT NULL"
                    print(f"  • {row[0]}: {row[1]} {nullable}")
            else:
                print("❌ Table verification failed!")
                
    except Exception as e:
        print(f"❌ Error creating table: {e}")
        return False
    
    return True

if __name__ == "__main__":
    print("🚀 BrightNest Database Migration")
    print("================================")
    
    success = create_suggestion_history_table()
    
    if success:
        print("\n🎉 Migration completed successfully!")
        print("\nThe suggestion variety system is now ready to use.")
        print("Restart your backend server to begin tracking suggestions.")
    else:
        print("\n💥 Migration failed!")
        print("Please check the error messages above and try again.")
        sys.exit(1) 