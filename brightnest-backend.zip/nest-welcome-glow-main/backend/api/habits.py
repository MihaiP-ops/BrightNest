from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List
from datetime import datetime, timedelta
import models, schemas, auth
from database import get_db

router = APIRouter(prefix="/habits", tags=["habits"])

@router.post("/", response_model=schemas.Habit)
def create_habit(
    habit: schemas.HabitCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    # Verify child belongs to current user
    child = db.query(models.Child)\
        .filter(models.Child.id == habit.child_id, models.Child.parent_id == current_user.id)\
        .first()
    if not child:
        raise HTTPException(status_code=404, detail="Child not found")
    
    db_habit = models.Habit(**habit.model_dump())
    db.add(db_habit)
    db.commit()
    db.refresh(db_habit)
    return db_habit

@router.get("/child/{child_id}", response_model=List[schemas.Habit])
def read_child_habits(
    child_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    # Verify child belongs to current user
    child = db.query(models.Child)\
        .filter(models.Child.id == child_id, models.Child.parent_id == current_user.id)\
        .first()
    if not child:
        raise HTTPException(status_code=404, detail="Child not found")
    
    # Get habits with completion counts
    habits = db.query(models.Habit)\
        .filter(models.Habit.child_id == child_id, models.Habit.is_active == True)\
        .all()
    
    # Add completion counts to each habit
    habits_with_completions = []
    for habit in habits:
        # Count completions for this week (last 7 days)
        from datetime import datetime, timedelta
        week_ago = datetime.utcnow() - timedelta(days=7)
        
        weekly_completions = db.query(models.HabitCompletion)\
            .filter(
                models.HabitCompletion.habit_id == habit.id,
                models.HabitCompletion.completed_at >= week_ago
            )\
            .count()
        
        # Create habit dict with completion data
        habit_dict = {
            "id": habit.id,
            "name": habit.name,
            "description": habit.description,
            "total_days": habit.total_days,
            "child_id": habit.child_id,
            "created_at": habit.created_at,
            "is_active": habit.is_active,
            "completed_days": weekly_completions  # Add this field
        }
        habits_with_completions.append(habit_dict)
    
    return habits_with_completions

@router.get("/child/{child_id}/with-completions")
def read_child_habits_with_completions(
    child_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    """Get habits with detailed completion data for the current week"""
    # Verify child belongs to current user
    child = db.query(models.Child)\
        .filter(models.Child.id == child_id, models.Child.parent_id == current_user.id)\
        .first()
    if not child:
        raise HTTPException(status_code=404, detail="Child not found")
    
    # Get habits
    habits = db.query(models.Habit)\
        .filter(models.Habit.child_id == child_id, models.Habit.is_active == True)\
        .all()
    
    # Add detailed completion data to each habit
    habits_with_detailed_completions = []
    for habit in habits:
        from datetime import datetime, timedelta
        import calendar
        
        # Get current week's completion dates
        today = datetime.utcnow()
        week_start = today - timedelta(days=today.weekday() + 1)  # Start from Sunday
        week_end = week_start + timedelta(days=6)  # End on Saturday
        
        # Get completions for this week
        completions = db.query(models.HabitCompletion)\
            .filter(
                models.HabitCompletion.habit_id == habit.id,
                models.HabitCompletion.completed_at >= week_start,
                models.HabitCompletion.completed_at <= week_end
            )\
            .all()
        
        # Map completions to days of the week
        completed_days = []
        days_of_week = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
        
        for completion in completions:
            day_of_week = completion.completed_at.weekday()
            # Convert Monday=0 to Sunday=0 format
            sunday_based_day = (day_of_week + 1) % 7
            day_name = days_of_week[sunday_based_day]
            if day_name not in completed_days:
                completed_days.append(day_name)
        
        # Create habit dict with detailed completion data
        habit_dict = {
            "id": habit.id,
            "name": habit.name,
            "description": habit.description,
            "total_days": habit.total_days,
            "child_id": habit.child_id,
            "created_at": habit.created_at,
            "is_active": habit.is_active,
            "completed_days": len(completed_days),
            "completed_days_detail": completed_days  # Add detailed day information
        }
        habits_with_detailed_completions.append(habit_dict)
    
    return habits_with_detailed_completions

@router.post("/{habit_id}/complete", response_model=schemas.Habit)
def complete_habit(
    habit_id: int,
    completion_date: str = Query(None),  # Optional date in YYYY-MM-DD format as query parameter
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    # Verify habit belongs to current user's child
    habit = db.query(models.Habit)\
        .join(models.Child)\
        .filter(
            models.Habit.id == habit_id,
            models.Child.parent_id == current_user.id,
            models.Habit.is_active == True
        ).first()
    if not habit:
        raise HTTPException(status_code=404, detail="Habit not found")
    
    # Parse completion date if provided
    if completion_date:
        try:
            from datetime import datetime
            parsed_date = datetime.strptime(completion_date, "%Y-%m-%d")
            # Set to noon to avoid timezone issues
            completion_datetime = parsed_date.replace(hour=12, minute=0, second=0)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid date format. Use YYYY-MM-DD")
    else:
        completion_datetime = None
    
    # Check if habit is already completed for this date
    if completion_date:
        existing_completion = db.query(models.HabitCompletion)\
            .filter(
                models.HabitCompletion.habit_id == habit_id,
                func.date(models.HabitCompletion.completed_at) == parsed_date.date()
            ).first()
        if existing_completion:
            raise HTTPException(status_code=400, detail="Habit already completed for this date")
    
    # Create completion record
    if completion_datetime:
        completion = models.HabitCompletion(habit_id=habit_id, completed_at=completion_datetime)
    else:
        completion = models.HabitCompletion(habit_id=habit_id)
    
    db.add(completion)
    
    # Get the count of completions for this habit
    completed_days = db.query(models.HabitCompletion)\
        .filter(models.HabitCompletion.habit_id == habit_id)\
        .count()
    
    db.commit()
    
    # Return the updated habit with completion count
    return {
        "id": habit.id,
        "name": habit.name,
        "description": habit.description,
        "total_days": habit.total_days,
        "child_id": habit.child_id,
        "created_at": habit.created_at,
        "is_active": habit.is_active,
        "completed_days": completed_days
    }

@router.get("/{habit_id}/progress")
def get_habit_progress(
    habit_id: int,
    days: int = 7,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    # Verify habit belongs to current user's child
    habit = db.query(models.Habit)\
        .join(models.Child)\
        .filter(
            models.Habit.id == habit_id,
            models.Child.parent_id == current_user.id
        ).first()
    if not habit:
        raise HTTPException(status_code=404, detail="Habit not found")
    
    # Calculate date range
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=days)
    
    # Get completions within date range
    completions = db.query(
        func.date(models.HabitCompletion.completed_at).label('date'),
        func.count().label('count')
    ).filter(
        models.HabitCompletion.habit_id == habit_id,
        models.HabitCompletion.completed_at >= start_date,
        models.HabitCompletion.completed_at <= end_date
    ).group_by(
        func.date(models.HabitCompletion.completed_at)
    ).all()
    
    # Format results
    progress = {
        "habit_id": habit_id,
        "name": habit.name,
        "total_days": habit.total_days,
        "completions": [
            {"date": str(c.date), "count": c.count}
            for c in completions
        ]
    }
    
    return progress

@router.put("/{habit_id}", response_model=schemas.Habit)
def update_habit(
    habit_id: int,
    habit_update: schemas.HabitUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    # Verify habit belongs to current user's child
    habit = db.query(models.Habit)\
        .join(models.Child)\
        .filter(
            models.Habit.id == habit_id,
            models.Child.parent_id == current_user.id
        ).first()
    if not habit:
        raise HTTPException(status_code=404, detail="Habit not found")
    
    for key, value in habit_update.model_dump(exclude_unset=True).items():
        setattr(habit, key, value)
    
    db.commit()
    db.refresh(habit)
    return habit

@router.delete("/{habit_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_habit(
    habit_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    # Verify habit belongs to current user's child
    habit = db.query(models.Habit)\
        .join(models.Child)\
        .filter(
            models.Habit.id == habit_id,
            models.Child.parent_id == current_user.id
        ).first()
    if not habit:
        raise HTTPException(status_code=404, detail="Habit not found")
    
    # Soft delete by marking as inactive
    habit.is_active = False
    db.commit()
    return None 