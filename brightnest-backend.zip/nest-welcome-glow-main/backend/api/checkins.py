from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime, timedelta, timezone
import models, schemas, auth
from database import get_db
from ai_service import ai_service
from ai_config import config
from ai_insights import get_contextual_score
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/checkins", tags=["checkins"])

@router.post("/", response_model=schemas.CheckIn)
def create_checkin(
    checkin: schemas.CheckInCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    # Verify child belongs to current user
    child = db.query(models.Child)\
        .filter(models.Child.id == checkin.child_id, models.Child.parent_id == current_user.id)\
        .first()
    if not child:
        raise HTTPException(status_code=404, detail="Child not found")
    
    # Validate emotion rating
    if not 1 <= checkin.emotion_rating <= 5:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Emotion rating must be between 1 and 5"
        )
    
    db_checkin = models.CheckIn(**checkin.model_dump())
    db.add(db_checkin)
    db.commit()
    db.refresh(db_checkin)
    return db_checkin

@router.get("/child/{child_id}", response_model=List[schemas.CheckIn])
def read_child_checkins(
    child_id: int,
    days: int = 7,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    # Verify child belongs to current user
    child = db.query(models.Child)\
        .filter(models.Child.id == child_id, models.Child.parent_id == current_user.id)\
        .first()
    if not child:
        raise HTTPException(status_code=404, detail="Child not found")
    
    # Calculate date threshold
    date_threshold = datetime.now(timezone.utc) - timedelta(days=days)
    
    # Get check-ins for the child within the date range
    checkins = db.query(models.CheckIn)\
        .filter(models.CheckIn.child_id == child_id, models.CheckIn.created_at >= date_threshold)\
        .order_by(models.CheckIn.created_at.desc())\
        .all()
    
    return checkins

@router.get("/child/{child_id}/with-tips", response_model=List[schemas.CheckInWithTips])
async def read_child_checkins_with_tips(
    child_id: int,
    days: int = 7,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    """Get check-ins with AI tips (cached or generated on-demand)"""
    
    # Verify child belongs to current user
    child = db.query(models.Child)\
        .filter(models.Child.id == child_id, models.Child.parent_id == current_user.id)\
        .first()
    if not child:
        raise HTTPException(status_code=404, detail="Child not found")
    
    # Calculate date threshold
    date_threshold = datetime.now(timezone.utc) - timedelta(days=days)
    
    # Get check-ins for the child within the date range with cached tips
    checkins = db.query(models.CheckIn)\
        .filter(models.CheckIn.child_id == child_id, models.CheckIn.created_at >= date_threshold)\
        .order_by(models.CheckIn.created_at.desc())\
        .all()
    
    # Process each check-in to ensure it has cached tips
    result = []
    for checkin in checkins:
        # Check if we already have cached tips for this check-in
        cached_tip = db.query(models.CheckInTip)\
            .filter(models.CheckInTip.check_in_id == checkin.id)\
            .first()
        
        if not cached_tip:
            # Generate AI tips if not cached
            try:
                # Use AI service directly to generate personalized tips
                ai_tip_text = await generate_ai_tip_direct(
                    child_age=child.age,
                    emotion_rating=checkin.emotion_rating,
                    notes=checkin.notes or ""
                )
                
                habit_suggestion_text = await generate_habit_suggestion_direct(
                    child_age=child.age,
                    emotion_rating=checkin.emotion_rating,
                    notes=checkin.notes or ""
                )
                
                # Determine if tip was personalized (if notes were provided and substantial)
                is_personalized = bool(checkin.notes and len(checkin.notes.strip()) > 15)
                
                # Create cached tip entry
                cached_tip = models.CheckInTip(
                    check_in_id=checkin.id,
                    ai_tip=ai_tip_text,
                    habit_suggestion=habit_suggestion_text,
                    is_tip_personalized=is_personalized,
                    tip_score=1.0  # AI generated tip gets a score of 1.0
                )
                
                db.add(cached_tip)
                db.commit()
                db.refresh(cached_tip)
                
            except Exception as e:
                print(f"Failed to generate AI tips for check-in {checkin.id}: {e}")
                # Create fallback cached tip
                cached_tip = models.CheckInTip(
                    check_in_id=checkin.id,
                    ai_tip=generate_fallback_tip(checkin.emotion_rating, checkin.notes or ""),
                    habit_suggestion=generate_fallback_habit(checkin.emotion_rating, checkin.notes or ""),
                    is_tip_personalized=False,
                    tip_score=0.0
                )
                
                db.add(cached_tip)
                db.commit()
                db.refresh(cached_tip)
        
        # Append to result - the relationship will automatically include cached_tip
        result.append(checkin)
    
    return result

def generate_fallback_tip(emotion_rating: int, notes: str) -> str:
    """Generate fallback tip when AI service fails"""
    if emotion_rating <= 2:
        return "It's important to acknowledge difficult emotions. Try validating their feelings and offering comfort through your presence and understanding."
    elif emotion_rating >= 4:
        return "Celebrate these positive moments! Ask about what specifically made them happy to reinforce positive experiences."
    return "Mixed emotions are completely normal. Continue providing consistent support and emotional validation."

# Removed generate_fallback_habit - replaced with generate_varied_fallback_habit for better variety

async def generate_ai_tip_direct(child_age: int, emotion_rating: int, notes: str) -> str:
    """Generate AI tip directly using the AI service"""
    try:
        # Determine age group
        if child_age <= 3:
            age_group = "0-3"
        elif child_age <= 7:
            age_group = "4-7"
        else:
            age_group = "8-10"
        
        # Create context for AI generation
        emotion_labels = {1: "very sad", 2: "sad", 3: "neutral", 4: "happy", 5: "very happy"}
        emotion_label = emotion_labels.get(emotion_rating, "neutral")
        
        # Generate AI tip using the AI service
        if notes and len(notes.strip()) > 15:
            # Use personalized tip generation if detailed notes provided
            tip = await ai_service.personalize_tip(
                base_tip=f"Support your {child_age}-year-old who is feeling {emotion_label}.",
                child_age=age_group,
                situation_notes=notes
            )
        else:
            # Use basic personalized tip with minimal context
            tip = await ai_service.personalize_tip(
                base_tip=f"Your {child_age}-year-old is feeling {emotion_label}. Provide appropriate support.",
                child_age=age_group,
                situation_notes=notes if notes else f"Child is feeling {emotion_label}"
            )
        
        return tip
        
    except Exception as e:
        print(f"AI tip generation failed: {e}")
        return generate_fallback_tip(emotion_rating, notes)

async def generate_habit_suggestion_direct(child_age: int, emotion_rating: int, notes: str) -> str:
    """Generate habit suggestion directly using the AI service"""
    try:
        # Determine age group
        if child_age <= 3:
            age_group = "0-3"
        elif child_age <= 7:
            age_group = "4-7"
        else:
            age_group = "8-10"
        
        # Create context for AI generation
        emotion_labels = {1: "very sad", 2: "sad", 3: "neutral", 4: "happy", 5: "very happy"}
        emotion_label = emotion_labels.get(emotion_rating, "neutral")
        
        # Get recent habit suggestions to avoid duplicates
        recent_habits = []
        try:
            from database import get_db
            db = next(get_db())
            
            # Get recent habit suggestions from the last 14 days
            from datetime import datetime, timedelta, timezone
            recent_date = datetime.now(timezone.utc) - timedelta(days=14)
            
            recent_tips = db.query(models.CheckInTip)\
                .join(models.CheckIn)\
                .filter(models.CheckIn.created_at >= recent_date)\
                .order_by(models.CheckInTip.created_at.desc())\
                .limit(10)\
                .all()
            
            # Extract habit names from recent suggestions
            for tip in recent_tips:
                if tip.habit_suggestion:
                    # Extract just the habit name (before the colon if present)
                    habit_name = tip.habit_suggestion.split(':')[0].strip()
                    if habit_name:
                        recent_habits.append({'name': habit_name})
            
            db.close()
        except Exception as e:
            logger.warning(f"Could not fetch recent habits: {e}")
            recent_habits = []
        
        # Generate habit suggestion using the AI service
        try:
            # First try the detailed habit generation method
            habit_result = await ai_service.generate_contextual_habit(
                age_group=age_group,
                emotion_rating=emotion_rating,
                situation_notes=notes if notes else f"Child is feeling {emotion_label}",
                existing_habits=recent_habits  # Pass recent habits to avoid duplicates
            )
            
            # Extract habit text from the result
            if habit_result and isinstance(habit_result, dict):
                habit_name = habit_result.get('name', '')  # Changed from 'habit_name' to 'name'
                habit_description = habit_result.get('description', '')  # Changed from 'habit_description' to 'description'
                detailed_explanation = habit_result.get('detailed_explanation', '')
                
                if habit_name and habit_description:
                    # Use the detailed explanation if available, otherwise use description
                    full_description = detailed_explanation if detailed_explanation else habit_description
                    habit = f"{habit_name}: {full_description}"
                else:
                    raise ValueError("Incomplete habit result")
            else:
                raise ValueError("No habit result from detailed method")
        
        except Exception as e:
            logger.warning(f"AI habit generation failed: {e}")
            # Fallback: Use personalize_tip method to generate a habit suggestion
            try:
                # Create a more specific base tip for habit generation
                if emotion_rating <= 2:  # Sad emotions
                    base_tip = f"Suggest a comforting daily routine for a {child_age}-year-old who needs emotional support"
                elif emotion_rating >= 4:  # Happy emotions
                    base_tip = f"Suggest a positive daily activity for a {child_age}-year-old to maintain their good mood"
                else:  # Neutral
                    base_tip = f"Suggest a balanced daily habit for a {child_age}-year-old to support emotional well-being"
                
                habit = await ai_service.personalize_tip(
                    base_tip=base_tip,
                    child_age=age_group,
                    situation_notes=notes if notes else f"Child experiencing {emotion_label} emotions"
                )
                
                # Clean up the response to make it more habit-like
                if habit and not any(habit.startswith(prefix) for prefix in ['Daily', 'Morning', 'Evening', 'Bedtime', 'Weekly']):
                    # If it doesn't start with a time indicator, add one based on content
                    if 'bedtime' in habit.lower() or 'sleep' in habit.lower():
                        habit = f"Bedtime Routine: {habit}"
                    elif 'morning' in habit.lower() or 'wake' in habit.lower():
                        habit = f"Morning Habit: {habit}"
                    else:
                        habit = f"Daily Practice: {habit}"
                        
            except Exception as fallback_error:
                logger.warning(f"Fallback habit generation also failed: {fallback_error}")
                # Ultimate fallback with more variety based on recent habits
                habit = generate_varied_fallback_habit(emotion_rating, notes, child_age, recent_habits)
        
        return habit
        
    except Exception as e:
        logger.error(f"Habit suggestion generation failed: {e}")
        return generate_varied_fallback_habit(emotion_rating, notes, child_age, [])

def generate_varied_fallback_habit(emotion_rating: int, notes: str, child_age: int, recent_habits: list) -> str:
    """Generate varied fallback habit suggestions to avoid repetition"""
    import random
    
    # Extract recent habit names to avoid
    recent_names = [h.get('name', '') for h in recent_habits]
    
    if emotion_rating <= 2:  # Sad/difficult emotions
        if child_age <= 3:
            options = [
                "Comfort Cuddles: 5 minutes of gentle hugs and soothing words each day",
                "Soft Music Time: Listen to calming songs together when feeling upset",
                "Favorite Toy Helper: Use a special stuffed animal for comfort during tough moments",
                "Gentle Rocking: Rock together in a chair while talking about feelings",
                "Story Comfort: Read a favorite book together when emotions feel big"
            ]
        elif child_age <= 7:
            options = [
                "Feelings Check-In: Daily chat about emotions with a trusted grown-up",
                "Emotion Drawing: Draw or color feelings in a special feelings journal",
                "Calm Corner Time: Create a cozy space for quiet time when overwhelmed",
                "Helper Activities: Do simple chores together to feel useful and connected",
                "Nature Comfort Walk: Take short walks outside to feel better"
            ]
        else:
            options = [
                "Quiet Reflection Time: 10 minutes daily in a peaceful space for thinking",
                "Emotion Journaling: Write about feelings in a private journal each day",
                "Mindful Movement: Gentle stretching or yoga when feeling stressed",
                "Problem-Solving Chat: Weekly discussion about challenges and solutions",
                "Creative Expression: Use art, music, or writing to process emotions"
            ]
    elif emotion_rating >= 4:  # Happy emotions
        if child_age <= 3:
            options = [
                "Happy Dance Party: Daily celebration dance to favorite music",
                "Gratitude Hugs: Give extra hugs while sharing what made you happy",
                "Joy Clapping: Clap and cheer together about good things that happened",
                "Smile Photos: Take pictures of happy moments throughout the day",
                "Celebration Songs: Sing special songs when something good happens"
            ]
        elif child_age <= 7:
            options = [
                "Gratitude Sharing: Tell someone one good thing from your day",
                "Happy Memory Box: Collect small items that remind you of good times",
                "Joy Journal: Draw or write one happy moment each day",
                "Kindness Actions: Do something nice for others when feeling good",
                "Achievement Celebration: Create special ways to celebrate successes"
            ]
        else:
            options = [
                "Success Reflection: Write about accomplishments and positive experiences",
                "Gratitude Practice: List three things you're thankful for each day",
                "Joy Sharing: Tell friends or family about positive experiences",
                "Goal Setting: Plan new exciting activities when feeling confident",
                "Positive Impact: Find ways to help others when feeling happy"
            ]
    else:  # Neutral emotions
        if child_age <= 3:
            options = [
                "Story Time Together: Daily reading for 10 minutes",
                "Gentle Play: Quiet activities like puzzles or blocks",
                "Routine Songs: Sing the same song during daily activities",
                "Snuggle Time: Regular cuddle time without distractions",
                "Simple Exploration: Look at books or toys together quietly"
            ]
        elif child_age <= 7:
            options = [
                "Nature Discovery Walk: Short daily outdoor exploration",
                "Creative Building: Use blocks, Legos, or crafts for focused play",
                "Routine Helper: Participate in daily household activities",
                "Quiet Game Time: Play calm games like puzzles or matching",
                "Learning Together: Explore new topics through books or videos"
            ]
        else:
            options = [
                "Mindful Moments: 5 minutes of quiet breathing or meditation",
                "Skill Practice: Work on a hobby or interest for 15 minutes daily",
                "Organization Time: Tidy up space while listening to music",
                "Reading Adventure: Explore new books or topics regularly",
                "Planning Session: Think about and plan upcoming activities"
            ]
    
    # Filter out recently used habits
    available_options = []
    for option in options:
        option_name = option.split(':')[0].strip()
        if not any(recent_name.lower() in option_name.lower() or option_name.lower() in recent_name.lower() 
                  for recent_name in recent_names):
            available_options.append(option)
    
    # If all options were recently used, use all options (better than nothing)
    if not available_options:
        available_options = options
    
    return random.choice(available_options)

@router.get("/child/{child_id}/summary")
def get_checkin_summary(
    child_id: int,
    days: int = 7,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    # Verify child belongs to current user
    child = db.query(models.Child)\
        .filter(models.Child.id == child_id, models.Child.parent_id == current_user.id)\
        .first()
    if not child:
        raise HTTPException(status_code=404, detail="Child not found")
    
    # Calculate date range
    end_date = datetime.now(timezone.utc)
    start_date = end_date - timedelta(days=days)
    
    # Get check-ins for the period
    checkins = db.query(models.CheckIn)\
        .filter(
            models.CheckIn.child_id == child_id,
            models.CheckIn.created_at >= start_date,
            models.CheckIn.created_at <= end_date
        )\
        .all()
    
    if not checkins:
        return {
            "average_rating": None,
            "total_checkins": 0,
            "mood_distribution": {str(i): 0 for i in range(1, 6)}
        }
    
    # Calculate statistics
    total_checkins = len(checkins)
    average_rating = sum(c.emotion_rating for c in checkins) / total_checkins
    
    # Calculate mood distribution
    mood_distribution = {str(i): 0 for i in range(1, 6)}
    for checkin in checkins:
        mood_distribution[str(checkin.emotion_rating)] += 1
    
    return {
        "average_rating": round(average_rating, 2),
        "total_checkins": total_checkins,
        "mood_distribution": mood_distribution
    } 