from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
import models, schemas, auth
from database import get_db

router = APIRouter(prefix="/children", tags=["children"])

@router.post("/", response_model=schemas.Child)
def create_child(
    child: schemas.ChildCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    db_child = models.Child(
        **child.model_dump(),
        parent_id=current_user.id
    )
    db.add(db_child)
    db.commit()
    db.refresh(db_child)
    return db_child

@router.get("/", response_model=List[schemas.Child])
def read_children(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    children = db.query(models.Child)\
        .filter(models.Child.parent_id == current_user.id)\
        .offset(skip)\
        .limit(limit)\
        .all()
    return children

@router.get("/{child_id}", response_model=schemas.Child)
def read_child(
    child_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    child = db.query(models.Child)\
        .filter(models.Child.id == child_id, models.Child.parent_id == current_user.id)\
        .first()
    if child is None:
        raise HTTPException(status_code=404, detail="Child not found")
    return child

@router.put("/{child_id}", response_model=schemas.Child)
def update_child(
    child_id: int,
    child_update: schemas.ChildBase,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    db_child = db.query(models.Child)\
        .filter(models.Child.id == child_id, models.Child.parent_id == current_user.id)\
        .first()
    if db_child is None:
        raise HTTPException(status_code=404, detail="Child not found")
    
    for key, value in child_update.model_dump().items():
        setattr(db_child, key, value)
    
    db.commit()
    db.refresh(db_child)
    return db_child

@router.delete("/{child_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_child(
    child_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    db_child = db.query(models.Child)\
        .filter(models.Child.id == child_id, models.Child.parent_id == current_user.id)\
        .first()
    if db_child is None:
        raise HTTPException(status_code=404, detail="Child not found")
    
    db.delete(db_child)
    db.commit()
    return None 