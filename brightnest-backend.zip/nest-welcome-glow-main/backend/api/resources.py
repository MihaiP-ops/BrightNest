from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_
from typing import List, Optional
from datetime import datetime, timedelta
import json

from database import get_db
from auth import get_current_user
import models
import schemas
from ai_service import ai_service

router = APIRouter()

# Resource Categories
@router.get("/categories/", response_model=List[schemas.ResourceCategory])
def get_resource_categories(db: Session = Depends(get_db)):
    """Get all resource categories"""
    categories = db.query(models.ResourceCategory).all()
    return categories

@router.post("/categories/", response_model=schemas.ResourceCategory)
def create_resource_category(
    category: schemas.ResourceCategoryCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """Create a new resource category (admin only for now)"""
    db_category = models.ResourceCategory(**category.dict())
    db.add(db_category)
    db.commit()
    db.refresh(db_category)
    return db_category

# Resources
@router.get("/", response_model=List[schemas.Resource])
def get_resources(
    category_id: Optional[int] = Query(None, description="Filter by category ID"),
    resource_type: Optional[str] = Query(None, description="Filter by resource type"),
    min_age: Optional[int] = Query(None, description="Child's age for age-appropriate filtering"),
    max_age: Optional[int] = Query(None, description="Maximum age for filtering"),
    tags: Optional[str] = Query(None, description="Comma-separated tags to search for"),
    is_featured: Optional[bool] = Query(None, description="Filter featured resources"),
    search: Optional[str] = Query(None, description="Search in title and description"),
    limit: int = Query(20, description="Maximum number of resources to return"),
    offset: int = Query(0, description="Number of resources to skip"),
    db: Session = Depends(get_db)
):
    """Get resources with optional filtering"""
    query = db.query(models.Resource).options(joinedload(models.Resource.category))
    
    # Apply filters
    if category_id:
        query = query.filter(models.Resource.category_id == category_id)
    
    if resource_type:
        query = query.filter(models.Resource.resource_type == resource_type)
    
    if is_featured is not None:
        query = query.filter(models.Resource.is_featured == is_featured)
    
    # Age filtering
    if min_age is not None:
        query = query.filter(
            or_(
                models.Resource.min_age == None,
                models.Resource.min_age <= min_age
            )
        )
    
    if max_age is not None:
        query = query.filter(
            or_(
                models.Resource.max_age == None,
                models.Resource.max_age >= max_age
            )
        )
    
    # Tags filtering
    if tags:
        tag_list = [tag.strip().lower() for tag in tags.split(",")]
        for tag in tag_list:
            query = query.filter(models.Resource.tags.ilike(f"%{tag}%"))
    
    # Search filtering
    if search:
        search_term = f"%{search}%"
        query = query.filter(
            or_(
                models.Resource.title.ilike(search_term),
                models.Resource.description.ilike(search_term),
                models.Resource.tags.ilike(search_term)
            )
        )
    
    # Only active resources
    query = query.filter(models.Resource.is_active == True)
    
    # Order by featured first, then by creation date
    query = query.order_by(models.Resource.is_featured.desc(), models.Resource.created_at.desc())
    
    resources = query.offset(offset).limit(limit).all()
    return resources

@router.get("/{resource_id}", response_model=schemas.Resource)
def get_resource(
    resource_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """Get a specific resource by ID"""
    resource = db.query(models.Resource)\
        .options(joinedload(models.Resource.category))\
        .filter(models.Resource.id == resource_id)\
        .filter(models.Resource.is_active == True)\
        .first()
    
    if not resource:
        raise HTTPException(status_code=404, detail="Resource not found")
    
    # Increment view count
    resource.view_count += 1
    db.commit()
    
    return resource

@router.post("/", response_model=schemas.Resource)
def create_resource(
    resource: schemas.ResourceCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """Create a new resource (admin only for now)"""
    # Verify category exists
    category = db.query(models.ResourceCategory).filter(
        models.ResourceCategory.id == resource.category_id
    ).first()
    if not category:
        raise HTTPException(status_code=400, detail="Category not found")
    
    db_resource = models.Resource(**resource.dict())
    db.add(db_resource)
    db.commit()
    db.refresh(db_resource)
    
    # Load the category relationship
    db.refresh(db_resource, ["category"])
    return db_resource

# AI Recommendations
@router.get("/recommendations/{child_id}", response_model=List[schemas.ResourceRecommendation])
def get_child_resource_recommendations(
    child_id: int,
    limit: int = Query(5, description="Maximum number of recommendations"),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """Get AI-powered resource recommendations for a specific child"""
    # Verify child belongs to current user
    child = db.query(models.Child).filter(
        models.Child.id == child_id,
        models.Child.parent_id == current_user.id
    ).first()
    
    if not child:
        raise HTTPException(status_code=404, detail="Child not found")
    
    # Check for existing recent recommendations (within last 24 hours)
    recent_recommendations = db.query(models.ResourceRecommendation)\
        .filter(
            models.ResourceRecommendation.user_id == current_user.id,
            models.ResourceRecommendation.child_id == child_id,
            models.ResourceRecommendation.created_at >= datetime.utcnow() - timedelta(hours=24)
        )\
        .options(joinedload(models.ResourceRecommendation.resource).joinedload(models.Resource.category))\
        .limit(limit)\
        .all()
    
    if recent_recommendations:
        return recent_recommendations
    
    # Generate new AI recommendations
    recommendations = generate_ai_recommendations(child, current_user, db, limit)
    return recommendations

def generate_ai_recommendations(
    child: models.Child,
    user: models.User,
    db: Session,
    limit: int = 5
) -> List[models.ResourceRecommendation]:
    """Generate AI-powered resource recommendations based on child's data"""
    
    # Analyze child's recent data (last 30 days)
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=30)
    
    # Get mood trends
    recent_checkins = db.query(models.CheckIn)\
        .filter(
            models.CheckIn.child_id == child.id,
            models.CheckIn.created_at >= start_date
        )\
        .all()
    
    # Get habit completion patterns
    habit_completions = db.query(models.HabitCompletion)\
        .join(models.Habit)\
        .filter(
            models.Habit.child_id == child.id,
            models.HabitCompletion.completed_at >= start_date
        )\
        .all()
    
    # Analyze patterns for AI recommendations
    mood_scores = [checkin.emotion_rating for checkin in recent_checkins]
    avg_mood = sum(mood_scores) / len(mood_scores) if mood_scores else 3.0
    
    # Identify concerning patterns
    concerns = []
    if avg_mood < 2.5:
        concerns.extend(["anxiety", "sadness", "emotional-support"])
    elif avg_mood < 3.5:
        concerns.extend(["mood-regulation", "coping-strategies"])
    
    # Check habit completion rates
    if habit_completions:
        total_expected = len(recent_checkins) * 2  # Assuming ~2 habits per day
        completion_rate = len(habit_completions) / total_expected if total_expected > 0 else 0
        if completion_rate < 0.6:
            concerns.extend(["motivation", "routine-building", "consistency"])
    
    # Age-appropriate filtering
    concerns.append(f"age-{child.age}")
    
    # Generate AI prompt for recommendations
    try:
        prompt = f"""
        Based on a {child.age}-year-old child's recent patterns, recommend relevant parenting resources:
        
        Child Profile:
        - Age: {child.age}
        - Recent average mood: {avg_mood:.1f}/5
        - Identified concerns: {', '.join(concerns)}
        - Number of recent check-ins: {len(recent_checkins)}
        
        Recommend up to {limit} specific resource topics that would help parents support this child.
        Focus on practical, actionable guidance.
        
        Return as JSON array with objects containing:
        - topic: Brief topic name
        - reason: Why this is recommended for this child
        - confidence: Score 0-1 for recommendation confidence
        """
        
        response = ai_service.client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=500
        )
        
        ai_suggestions = json.loads(response.choices[0].message.content)
    except Exception as e:
        # Fallback to rule-based recommendations
        ai_suggestions = [
            {
                "topic": "Managing anxiety in young children",
                "reason": f"Child shows signs that could benefit from anxiety management strategies",
                "confidence": 0.7
            }
        ]
    
    # Match AI suggestions to actual resources
    recommendations = []
    
    for suggestion in ai_suggestions[:limit]:
        # Find matching resources
        matching_resources = db.query(models.Resource)\
            .options(joinedload(models.Resource.category))\
            .filter(
                models.Resource.is_active == True,
                or_(
                    models.Resource.min_age == None,
                    models.Resource.min_age <= child.age
                ),
                or_(
                    models.Resource.max_age == None,
                    models.Resource.max_age >= child.age
                ),
                or_(
                    models.Resource.title.ilike(f"%{suggestion['topic'][:20]}%"),
                    models.Resource.description.ilike(f"%{suggestion['topic'][:20]}%"),
                    models.Resource.tags.ilike(f"%{concerns[0]}%")
                )
            )\
            .first()
        
        if matching_resources:
            # Create recommendation record
            recommendation = models.ResourceRecommendation(
                user_id=user.id,
                child_id=child.id,
                resource_id=matching_resources.id,
                reason=suggestion.get("reason", "AI recommended based on child's patterns"),
                confidence_score=suggestion.get("confidence", 0.5),
                based_on_data=f"Mood average: {avg_mood:.1f}, Concerns: {', '.join(concerns[:3])}"
            )
            
            db.add(recommendation)
            recommendations.append(recommendation)
    
    # If no matches found, get some general age-appropriate resources
    if not recommendations:
        general_resources = db.query(models.Resource)\
            .options(joinedload(models.Resource.category))\
            .filter(
                models.Resource.is_active == True,
                or_(
                    models.Resource.min_age == None,
                    models.Resource.min_age <= child.age
                ),
                or_(
                    models.Resource.max_age == None,
                    models.Resource.max_age >= child.age
                )
            )\
            .limit(3)\
            .all()
        
        for resource in general_resources:
            recommendation = models.ResourceRecommendation(
                user_id=user.id,
                child_id=child.id,
                resource_id=resource.id,
                reason="General age-appropriate resource",
                confidence_score=0.3,
                based_on_data=f"Age: {child.age}"
            )
            db.add(recommendation)
            recommendations.append(recommendation)
    
    db.commit()
    
    # Refresh to get the resource relationships
    for rec in recommendations:
        db.refresh(rec, ["resource"])
    
    return recommendations

# Recommendation feedback
@router.post("/recommendations/{recommendation_id}/feedback")
def update_recommendation_feedback(
    recommendation_id: int,
    is_helpful: bool,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """Update user feedback on a recommendation"""
    recommendation = db.query(models.ResourceRecommendation)\
        .filter(
            models.ResourceRecommendation.id == recommendation_id,
            models.ResourceRecommendation.user_id == current_user.id
        )\
        .first()
    
    if not recommendation:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    
    recommendation.is_helpful = is_helpful
    if not recommendation.is_viewed:
        recommendation.is_viewed = True
        recommendation.viewed_at = datetime.utcnow()
    
    db.commit()
    return {"message": "Feedback updated successfully"}

@router.post("/recommendations/{recommendation_id}/bookmark")
def toggle_bookmark(
    recommendation_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """Toggle bookmark status for a recommendation"""
    recommendation = db.query(models.ResourceRecommendation)\
        .filter(
            models.ResourceRecommendation.id == recommendation_id,
            models.ResourceRecommendation.user_id == current_user.id
        )\
        .first()
    
    if not recommendation:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    
    recommendation.is_bookmarked = not recommendation.is_bookmarked
    if not recommendation.is_viewed:
        recommendation.is_viewed = True
        recommendation.viewed_at = datetime.utcnow()
    
    db.commit()
    return {"message": "Bookmark updated successfully", "is_bookmarked": recommendation.is_bookmarked} 