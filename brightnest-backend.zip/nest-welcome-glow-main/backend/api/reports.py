from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, desc
from typing import List, Optional
from datetime import datetime, timedelta, date
import models, schemas, auth
from database import get_db
from ai_service import ai_service
import io
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT

router = APIRouter(prefix="/reports", tags=["reports"])

@router.get("/child/{child_id}/progress")
def get_child_progress_report(
    child_id: int,
    period: str = Query("week", regex="^(week|month|quarter)$"),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    """Get comprehensive progress report for a child"""
    
    # Verify child belongs to current user
    child = db.query(models.Child)\
        .filter(
            models.Child.id == child_id,
            models.Child.parent_id == current_user.id
        ).first()
    if not child:
        raise HTTPException(status_code=404, detail="Child not found")
    
    # Calculate date range
    end_dt = datetime.utcnow()
    if period == "week":
        start_dt = end_dt - timedelta(days=7)
    elif period == "month":
        start_dt = end_dt - timedelta(days=30)
    else:  # quarter
        start_dt = end_dt - timedelta(days=90)
    
    # Get simple mood data
    checkins = db.query(models.CheckIn)\
        .filter(
            models.CheckIn.child_id == child_id,
            models.CheckIn.created_at >= start_dt
        ).all()
    
    mood_trends = []
    if checkins:
        for checkin in checkins:
            mood_trends.append({
                "date": checkin.created_at.strftime("%Y-%m-%d"),
                "avg_mood": float(checkin.emotion_rating),
                "checkin_count": 1
            })
    
    # Get habit data
    habits = db.query(models.Habit)\
        .filter(
            models.Habit.child_id == child_id,
            models.Habit.is_active == True
        ).all()
    
    habit_stats = []
    for habit in habits:
        completions = db.query(models.HabitCompletion)\
            .filter(
                models.HabitCompletion.habit_id == habit.id,
                models.HabitCompletion.completed_at >= start_dt
            ).count()
        
        # For weekly reports, always use 7 days (days of the week) regardless of habit frequency
        # For other periods, calculate based on the actual period length
        if period == "week":
            expected_completions = 7  # Always 7 days for weekly view
        else:
            # For month/quarter, use the habit's frequency per week scaled to the period
            weeks_in_period = (end_dt - start_dt).days / 7
            expected_completions = int(habit.total_days * weeks_in_period)
        
        completion_rate = (completions / expected_completions * 100) if expected_completions > 0 else 0
        
        habit_stats.append({
            "habit_id": habit.id,
            "habit_name": habit.name,
            "completions": completions,
            "expected_completions": expected_completions,
            "completion_rate": round(completion_rate, 1)
        })
    
    # Generate AI summary
    user_name = current_user.full_name or current_user.email.split('@')[0].title()
    ai_summary = generate_ai_summary(child.name, period, mood_trends, habit_stats, user_name)
    
    # Simple insights
    insights = []
    if habit_stats:
        high_performers = [h for h in habit_stats if h["completion_rate"] >= 80]
        if high_performers:
            insights.append({
                "type": "positive",
                "title": "Great Progress!",
                "description": f"{len(high_performers)} habit(s) showing excellent consistency"
            })
    
    return {
        "child_id": child_id,
        "child_name": child.name,
        "period": period,
        "start_date": start_dt.strftime("%Y-%m-%d"),
        "end_date": end_dt.strftime("%Y-%m-%d"),
        "mood_trends": mood_trends,
        "habit_stats": habit_stats,
        "insights": insights,
        "ai_summary": ai_summary,
        "summary": {
            "avg_mood": round(sum(m["avg_mood"] for m in mood_trends) / len(mood_trends), 1) if mood_trends else 0,
            "total_checkins": len(mood_trends),
            "active_habits": len(habit_stats),
            "avg_completion_rate": round(sum(h["completion_rate"] for h in habit_stats) / len(habit_stats), 1) if habit_stats else 0
        }
    }

@router.get("/child/{child_id}/progress/pdf")
async def get_child_progress_report_pdf(
    child_id: int,
    period: str = Query("week", regex="^(week|month|quarter)$"),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    """Generate and download a PDF progress report for a child"""
    
    # Get the same data as the regular progress report
    # Verify child belongs to current user
    child = db.query(models.Child)\
        .filter(
            models.Child.id == child_id,
            models.Child.parent_id == current_user.id
        ).first()
    if not child:
        raise HTTPException(status_code=404, detail="Child not found")
    
    # Calculate date range
    end_dt = datetime.utcnow()
    if period == "week":
        start_dt = end_dt - timedelta(days=7)
    elif period == "month":
        start_dt = end_dt - timedelta(days=30)
    else:  # quarter
        start_dt = end_dt - timedelta(days=90)
    
    # Get mood data
    checkins = db.query(models.CheckIn)\
        .filter(
            models.CheckIn.child_id == child_id,
            models.CheckIn.created_at >= start_dt
        ).all()
    
    mood_trends = []
    for checkin in checkins:
        mood_trends.append({
            "date": checkin.created_at.strftime("%Y-%m-%d"),
            "avg_mood": float(checkin.emotion_rating),
            "checkin_count": 1
        })
    
    # Get habit data
    habits = db.query(models.Habit)\
        .filter(
            models.Habit.child_id == child_id,
            models.Habit.is_active == True
        ).all()
    
    habit_stats = []
    for habit in habits:
        completions = db.query(models.HabitCompletion)\
            .filter(
                models.HabitCompletion.habit_id == habit.id,
                models.HabitCompletion.completed_at >= start_dt
            ).count()
        
        expected_completions = habit.total_days * ((end_dt - start_dt).days // 7 + 1)
        completion_rate = (completions / expected_completions * 100) if expected_completions > 0 else 0
        
        habit_stats.append({
            "habit_id": habit.id,
            "habit_name": habit.name,
            "completions": completions,
            "expected_completions": expected_completions,
            "completion_rate": round(completion_rate, 1)
        })
    
    # Generate AI summary
    user_name = current_user.full_name or current_user.email.split('@')[0].title()
    ai_summary = generate_ai_summary(child.name, period, mood_trends, habit_stats, user_name)
    
    # Generate PDF
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)
    
    # Container for the 'Flowable' objects
    elements = []
    
    # Define styles
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        spaceAfter=30,
        alignment=TA_CENTER,
        textColor=colors.HexColor('#2563eb')
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=16,
        spaceAfter=12,
        textColor=colors.HexColor('#1f2937')
    )
    
    # Title
    period_name = {"week": "Weekly", "month": "Monthly", "quarter": "Quarterly"}[period]
    title = Paragraph(f"{period_name} Progress Report for {child.name}", title_style)
    elements.append(title)
    elements.append(Spacer(1, 20))
    
    # Report period
    period_text = Paragraph(f"<b>Report Period:</b> {start_dt.strftime('%B %d, %Y')} - {end_dt.strftime('%B %d, %Y')}", styles['Normal'])
    elements.append(period_text)
    elements.append(Spacer(1, 20))
    
    # AI Summary
    ai_heading = Paragraph("AI Generated Summary", heading_style)
    elements.append(ai_heading)
    
    # Clean up the AI summary text for PDF
    clean_summary = ai_summary.replace('\n', '<br/>')
    summary_para = Paragraph(clean_summary, styles['Normal'])
    elements.append(summary_para)
    elements.append(Spacer(1, 20))
    
    # Summary Statistics
    stats_heading = Paragraph("Summary Statistics", heading_style)
    elements.append(stats_heading)
    
    avg_mood = round(sum(m["avg_mood"] for m in mood_trends) / len(mood_trends), 1) if mood_trends else 0
    avg_completion = round(sum(h["completion_rate"] for h in habit_stats) / len(habit_stats), 1) if habit_stats else 0
    
    stats_data = [
        ['Metric', 'Value'],
        ['Average Mood', f"{avg_mood}/5.0"],
        ['Total Check-ins', str(len(mood_trends))],
        ['Active Habits', str(len(habit_stats))],
        ['Average Completion Rate', f"{avg_completion}%"]
    ]
    
    stats_table = Table(stats_data)
    stats_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#f3f4f6')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.white),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    elements.append(stats_table)
    elements.append(Spacer(1, 20))
    
    # Habit Performance
    if habit_stats:
        habits_heading = Paragraph("Habit Performance", heading_style)
        elements.append(habits_heading)
        
        habits_data = [['Habit Name', 'Completions', 'Expected', 'Rate']]
        for habit in habit_stats:
            habits_data.append([
                habit['habit_name'],
                str(habit['completions']),
                str(habit['expected_completions']),
                f"{habit['completion_rate']}%"
            ])
        
        habits_table = Table(habits_data)
        habits_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#f3f4f6')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.white),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(habits_table)
    
    # Build PDF
    doc.build(elements)
    
    # Get PDF data
    buffer.seek(0)
    
    # Generate filename
    filename = f"{child.name}_{period}_report_{datetime.now().strftime('%Y%m%d')}.pdf"
    
    return StreamingResponse(
        io.BytesIO(buffer.read()),
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

def generate_report_insights(mood_trends, habit_stats, streak_data, period):
    """Generate AI-like insights from the data"""
    insights = []
    
    if mood_trends:
        # Mood trend analysis
        recent_moods = [m["avg_mood"] for m in mood_trends[-3:]]  # Last 3 data points
        if len(recent_moods) >= 2:
            if recent_moods[-1] > recent_moods[0]:
                insights.append({
                    "type": "positive",
                    "title": "Mood Improvement",
                    "description": f"Mood has improved by {round((recent_moods[-1] - recent_moods[0]) / recent_moods[0] * 100, 1)}% in recent days"
                })
            elif recent_moods[-1] < recent_moods[0] * 0.8:
                insights.append({
                    "type": "alert",
                    "title": "Mood Decline",
                    "description": "Recent mood scores show a declining trend. Consider checking in more frequently."
                })
    
    # Habit performance analysis
    if habit_stats:
        high_performers = [h for h in habit_stats if h["completion_rate"] >= 80]
        low_performers = [h for h in habit_stats if h["completion_rate"] < 50]
        
        if high_performers:
            insights.append({
                "type": "positive",
                "title": "Strong Habits",
                "description": f"{len(high_performers)} habit(s) showing excellent consistency (80%+ completion rate)"
            })
        
        if low_performers:
            insights.append({
                "type": "suggestion",
                "title": "Habits Need Attention",
                "description": f"{len(low_performers)} habit(s) may need adjustment or more support"
            })
    
    # Streak analysis
    if streak_data:
        best_streak = max(streak_data, key=lambda x: x["longest_streak"])
        if best_streak["longest_streak"] >= 7:
            insights.append({
                "type": "achievement",
                "title": "Great Consistency!",
                "description": f"Achieved a {best_streak['longest_streak']}-day streak with '{best_streak['habit_name']}'"
            })
    
    return insights

@router.get("/child/{child_id}/summary")
def get_child_summary_stats(
    child_id: int,
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    """Get quick summary statistics for a child"""
    
    # Verify child belongs to current user
    child = db.query(models.Child)\
        .filter(
            models.Child.id == child_id,
            models.Child.parent_id == current_user.id
        ).first()
    if not child:
        raise HTTPException(status_code=404, detail="Child not found")
    
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=days)
    
    # Quick stats
    total_checkins = db.query(func.count(models.CheckIn.id))\
        .filter(
            models.CheckIn.child_id == child_id,
            models.CheckIn.created_at >= start_date
        ).scalar()
    
    avg_mood = db.query(func.avg(models.CheckIn.emotion_rating))\
        .filter(
            models.CheckIn.child_id == child_id,
            models.CheckIn.created_at >= start_date
        ).scalar()
    
    total_habit_completions = db.query(func.count(models.HabitCompletion.id))\
        .join(models.Habit)\
        .filter(
            models.Habit.child_id == child_id,
            models.HabitCompletion.completed_at >= start_date
        ).scalar()
    
    active_habits = db.query(func.count(models.Habit.id))\
        .filter(
            models.Habit.child_id == child_id,
            models.Habit.is_active == True
        ).scalar()
    
    return {
        "child_id": child_id,
        "child_name": child.name,
        "period_days": days,
        "total_checkins": total_checkins or 0,
        "avg_mood": round(float(avg_mood), 1) if avg_mood else 0,
        "total_habit_completions": total_habit_completions or 0,
        "active_habits": active_habits or 0,
        "checkin_frequency": round((total_checkins or 0) / days, 1)
    }

def generate_ai_summary(child_name: str, period: str, mood_trends: list, habit_stats: list, user_name: str) -> str:
    """Generate an AI-powered summary of the child's progress"""
    
    try:
        # Check if AI service is available
        if not ai_service.enabled or not ai_service.client:
            # Use fallback logic
            period_name = {"week": "week", "month": "month", "quarter": "quarter"}[period]
            fallback = f"Dear {user_name},\n\nDuring this {period_name}, {child_name} has been working on building positive habits and emotional awareness. "
            
            if mood_trends:
                avg_mood = sum(m["avg_mood"] for m in mood_trends) / len(mood_trends)
                if avg_mood >= 4:
                    fallback += "Their mood has been generally positive, showing good emotional well-being. "
                elif avg_mood >= 3:
                    fallback += "Their mood has been stable, with room for continued growth. "
                else:
                    fallback += "They're navigating some emotional challenges and would benefit from extra support. "
            
            if habit_stats:
                avg_completion = sum(h["completion_rate"] for h in habit_stats) / len(habit_stats)
                if avg_completion >= 70:
                    fallback += "They're showing great consistency with their daily habits and routines."
                elif avg_completion >= 40:
                    fallback += "They're making steady progress with their habits, with opportunities to build stronger routines."
                else:
                    fallback += "Building consistent habits is a work in progress - small steps forward are still meaningful achievements."
            
            return fallback
        
        # Prepare data summary for AI
        mood_summary = ""
        if mood_trends:
            avg_mood = sum(m["avg_mood"] for m in mood_trends) / len(mood_trends)
            total_checkins = len(mood_trends)
            mood_summary = f"Average mood: {avg_mood:.1f}/5.0 across {total_checkins} check-ins."
            
            # Mood trend analysis
            if len(mood_trends) > 1:
                first_mood = mood_trends[0]["avg_mood"]
                last_mood = mood_trends[-1]["avg_mood"]
                if last_mood > first_mood:
                    mood_summary += f" Mood improved from {first_mood:.1f} to {last_mood:.1f}."
                elif last_mood < first_mood:
                    mood_summary += f" Mood decreased from {first_mood:.1f} to {last_mood:.1f}."
                else:
                    mood_summary += " Mood remained stable."
        else:
            mood_summary = "No mood data recorded during this period."
        
        habit_summary = ""
        if habit_stats:
            total_habits = len(habit_stats)
            avg_completion = sum(h["completion_rate"] for h in habit_stats) / len(habit_stats)
            high_performers = [h for h in habit_stats if h["completion_rate"] >= 80]
            low_performers = [h for h in habit_stats if h["completion_rate"] < 50]
            
            habit_summary = f"Tracking {total_habits} habits with {avg_completion:.1f}% average completion rate. "
            
            if high_performers:
                habit_names = [h["habit_name"] for h in high_performers[:2]]  # Top 2
                habit_summary += f"Strong performance in: {', '.join(habit_names)}. "
            
            if low_performers:
                habit_names = [h["habit_name"] for h in low_performers[:2]]  # Bottom 2
                habit_summary += f"Needs attention: {', '.join(habit_names)}. "
        else:
            habit_summary = "No habits tracked during this period."
        
        # Create AI prompt
        period_name = {"week": "weekly", "month": "monthly", "quarter": "quarterly"}[period]
        
        prompt = f"""Write a warm, encouraging {period_name} progress summary for {child_name}, addressed to {user_name}. 

Start with "Dear {user_name}," and write as a supportive child development specialist.

Data Summary:
- {mood_summary}
- {habit_summary}

Please write a 2-3 paragraph summary that:
1. Celebrates achievements and positive trends
2. Acknowledges challenges with empathy and support
3. Provides actionable, age-appropriate suggestions
4. Uses encouraging, professional language suitable for sharing with therapists/teachers
5. Focuses on growth and progress rather than perfection

Keep it concise but meaningful, around 100-150 words."""

        response = ai_service.client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a child development expert writing progress summaries for parents, teachers, and therapists. Focus on being encouraging, supportive, and actionable."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=200,
            temperature=0.7
        )
        
        return response.choices[0].message.content.strip()
        
    except Exception as e:
        print(f"Error generating AI summary: {e}")
        # Fallback summary
        period_name = {"week": "week", "month": "month", "quarter": "quarter"}[period]
        fallback = f"Dear {user_name},\n\nDuring this {period_name}, {child_name} has been working on building positive habits and emotional awareness. "
        
        if mood_trends:
            avg_mood = sum(m["avg_mood"] for m in mood_trends) / len(mood_trends)
            if avg_mood >= 4:
                fallback += "Their mood has been generally positive, showing good emotional well-being. "
            elif avg_mood >= 3:
                fallback += "Their mood has been stable, with room for continued growth. "
            else:
                fallback += "They're navigating some emotional challenges and would benefit from extra support. "
        
        if habit_stats:
            avg_completion = sum(h["completion_rate"] for h in habit_stats) / len(habit_stats)
            if avg_completion >= 70:
                fallback += "They're showing great consistency with their daily habits and routines."
            elif avg_completion >= 40:
                fallback += "They're making steady progress with their habits, with opportunities to build stronger routines."
            else:
                fallback += "Building consistent habits is a work in progress - small steps forward are still meaningful achievements."
        
        return fallback 