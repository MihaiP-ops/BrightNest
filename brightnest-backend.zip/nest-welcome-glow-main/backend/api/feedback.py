from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
import models, schemas, auth
from database import get_db

router = APIRouter(prefix="/feedback", tags=["feedback"])

@router.post("/", response_model=schemas.Feedback)
def create_feedback(
    feedback: schemas.FeedbackCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    db_feedback = models.Feedback(
        **feedback.model_dump(),
        user_id=current_user.id
    )
    db.add(db_feedback)
    db.commit()
    db.refresh(db_feedback)
    return db_feedback

@router.get("/my", response_model=List[schemas.Feedback])
def read_my_feedback(
    skip: int = 0,
    limit: int = 10,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    feedback = db.query(models.Feedback)\
        .filter(models.Feedback.user_id == current_user.id)\
        .order_by(models.Feedback.created_at.desc())\
        .offset(skip)\
        .limit(limit)\
        .all()
    return feedback 