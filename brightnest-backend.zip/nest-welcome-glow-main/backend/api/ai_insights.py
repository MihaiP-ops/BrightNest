from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
import models, schemas, auth
from database import get_db
import random
import json
from ai_service import ai_service
from ai_config import config
from ai_variety import (
    get_recent_suggestions, 
    track_suggestion, 
    apply_variety_scoring, 
    apply_category_rotation,
    select_with_variety,
    get_excluded_suggestion_ids
)

router = APIRouter(prefix="/ai-insights", tags=["ai-insights"])

def get_age_group(age: int) -> str:
    """Determine age group based on child's age"""
    if age <= 3:
        return "0-3"
    elif age <= 7:
        return "4-7"
    else:
        return "8-10"

@router.get("/tip/{child_id}/{emotion_rating}")
async def get_ai_tip(
    child_id: int,
    emotion_rating: int,
    notes: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    """Get an age-appropriate AI tip based on child's age and emotion rating"""
    
    # Verify child belongs to current user
    child = db.query(models.Child)\
        .filter(models.Child.id == child_id, models.Child.parent_id == current_user.id)\
        .first()
    if not child:
        raise HTTPException(status_code=404, detail="Child not found")
    
    # Validate emotion rating
    if not 1 <= emotion_rating <= 5:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Emotion rating must be between 1 and 5"
        )
    
    # Determine age group
    age_group = get_age_group(child.age)
    
    # Get recent tip history for variety checking
    recent_suggestions = get_recent_suggestions(db, child_id, "tip", config.SUGGESTION_COOLDOWN_DAYS)
    excluded_tip_ids = get_excluded_suggestion_ids(recent_suggestions)
    
    # Get all tips for this age group and emotion
    tips = db.query(models.AITip)\
        .filter(
            models.AITip.age_group == age_group,
            models.AITip.emotion_rating == emotion_rating
        )\
        .all()
    
    if not tips:
        # Fallback to generic tip if no specific tip found
        return {
            "tip": f"Every emotion is valid. Support your {child.age}-year-old through this feeling with patience and understanding.",
            "age_group": age_group,
            "child_name": child.name,
            "child_age": child.age
        }
    
    # Calculate base scores for all tips
    tip_scores = {}
    
    for tip in tips:
        current_score = 0
        tip_content = tip.tip_text.lower()
        
        # Universal contextual matching for all age groups
        context_score, context_detected = get_contextual_score(notes, tip.tip_text, child.age)
        current_score += context_score
        
        # Emotion-specific tip prioritization (reduced impact)
        if emotion_rating == 1:  # Very Sad - prioritize immediate comfort
            comfort_words = ['comfort', 'hold', 'safe', 'calm', 'gentle', 'soothe', 'immediately']
            if any(word in tip_content for word in comfort_words):
                current_score += 2  # Reduced from 3
                
        elif emotion_rating == 2:  # Sad - focus on validation and support
            support_words = ['validate', 'understand', 'listen', 'acknowledge', 'feelings', 'normal']
            if any(word in tip_content for word in support_words):
                current_score += 2  # Reduced from 3
                
        elif emotion_rating == 3:  # Neutral - educational/developmental
            growth_words = ['learn', 'explore', 'develop', 'routine', 'practice', 'skill']
            if any(word in tip_content for word in growth_words):
                current_score += 2
                
        elif emotion_rating == 4:  # Happy - social connection and building
            social_words = ['share', 'celebrate', 'connect', 'together', 'social', 'friends']
            if any(word in tip_content for word in social_words):
                current_score += 2
                
        elif emotion_rating == 5:  # Very Happy - celebration and channeling energy
            energy_words = ['celebrate', 'achievement', 'energy', 'creative', 'express', 'proud']
            if any(word in tip_content for word in energy_words):
                current_score += 2
        
        # Age-specific relevance
        if child.age <= 3:
            toddler_words = ['simple', 'basic', 'routine', 'consistency', 'physical', 'sensory']
            if any(word in tip_content for word in toddler_words):
                current_score += 2
        elif child.age <= 7:
            preschool_words = ['play', 'imaginative', 'creative', 'social', 'learning', 'cooperation']
            if any(word in tip_content for word in preschool_words):
                current_score += 2
        else:
            school_words = ['independence', 'responsibility', 'problem-solving', 'communication', 'peers']
            if any(word in tip_content for word in school_words):
                current_score += 2
        
        # Practical vs theoretical tips - prefer practical for immediate situations
        practical_words = ['try', 'practice', 'do', 'create', 'make', 'start', 'begin']
        if any(word in tip_content for word in practical_words):
            current_score += 1
            
        tip_scores[tip.id] = current_score
    
    # Apply variety scoring to reduce repetition
    variety_scores = apply_variety_scoring(tips, recent_suggestions, tip_scores)
    
    # Apply category rotation to encourage different types of suggestions
    final_scores = apply_category_rotation(tips, recent_suggestions, variety_scores)
    
    # Filter out tips with scores below minimum threshold
    qualified_tips = [tip for tip in tips if final_scores.get(tip.id, 0) >= config.MINIMUM_TIP_SCORE]
    
    # If no tips meet the minimum score, lower the threshold and try again
    if not qualified_tips:
        qualified_tips = [tip for tip in tips if final_scores.get(tip.id, 0) >= 0]
    
    # Select the best tip using variety management from qualified tips
    best_tip = select_with_variety(qualified_tips, final_scores, excluded_tip_ids)
    
    # If no tip was selected, fall back to best scoring tip from all tips
    if not best_tip:
        # Find highest scoring tip
        best_score = max(final_scores.values()) if final_scores else 0
        for tip in tips:
            if final_scores.get(tip.id, 0) == best_score:
                best_tip = tip
                break
        
        # Ultimate fallback
        if not best_tip:
            best_tip = random.choice(tips)
    
    selection_method = "contextual_filtered" if qualified_tips != tips else "variety_based"
    tip_score = final_scores.get(best_tip.id, 0)
    
    # AI Enhancement: Personalize the tip if detailed notes are provided
    final_tip = best_tip.tip_text
    personalization_used = False
    
    if notes and len(notes.strip()) > config.TIP_PERSONALIZATION_MIN_NOTES:  # Only personalize for detailed situations
        try:
            personalized_tip = await ai_service.personalize_tip(
                base_tip=str(best_tip.tip_text),
                child_age=age_group,
                situation_notes=notes.strip()
            )
            
            # Use personalized version if it's different from original
            if personalized_tip != best_tip.tip_text:
                final_tip = personalized_tip
                personalization_used = True
                
        except Exception as e:
            # Log error but continue with original tip
            print(f"AI personalization failed: {e}")
    
    # Track this suggestion in history for future variety management
    try:
        track_suggestion(
            db=db,
            child_id=child_id, 
            suggestion_type="tip",
            suggestion_id=best_tip.id,
            suggestion_text=final_tip,
            emotion_rating=emotion_rating,
            notes=notes
        )
    except Exception as e:
        print(f"Failed to track suggestion: {e}")
    
    return {
        "tip": final_tip,
        "age_group": age_group,
        "child_name": child.name,
        "child_age": child.age,
        "category": best_tip.tip_category,
        "selection_method": selection_method,
        "tip_score": tip_score,
        "total_tips_available": len(tips),
        "excluded_tips": len(excluded_tip_ids),
        "ai_personalized": personalization_used,
        "original_tip": best_tip.tip_text if personalization_used else None
    }

@router.get("/habit-suggestion/{child_id}/{emotion_rating}")
async def get_habit_suggestion(
    child_id: int,
    emotion_rating: int,
    notes: str = "",
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    """Get an age-appropriate habit suggestion based on child's age, emotion, and notes"""
    
    # Verify child belongs to current user
    child = db.query(models.Child)\
        .filter(models.Child.id == child_id, models.Child.parent_id == current_user.id)\
        .first()
    if not child:
        raise HTTPException(status_code=404, detail="Child not found")
    
    # Validate emotion rating
    if not 1 <= emotion_rating <= 5:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Emotion rating must be between 1 and 5"
        )
    
    # Determine age group
    age_group = get_age_group(child.age)
    
    # Get recent habit suggestion history for variety checking
    recent_suggestions = get_recent_suggestions(db, child_id, "habit", config.SUGGESTION_COOLDOWN_DAYS)
    excluded_habit_ids = get_excluded_suggestion_ids(recent_suggestions)
    
    # Get habit suggestions for this age group and emotion
    suggestions = db.query(models.HabitSuggestion)\
        .filter(
            models.HabitSuggestion.age_group == age_group,
            models.HabitSuggestion.emotion_rating == emotion_rating
        )\
        .all()
    
    if not suggestions:
        # Fallback suggestion
        return {
            "habit_name": f"Daily Check-in Chat",
            "habit_description": f"Spend 5 minutes talking about feelings with your {child.age}-year-old each day",
            "age_group": age_group,
            "child_name": child.name,
            "child_age": child.age
        }
    
    # Calculate base scores for all habit suggestions
    suggestion_scores = {}
    
    for suggestion in suggestions:
        current_score = 0
        
        if notes and notes.strip():
            notes_lower = notes.lower()
            
            # Safe keyword processing
            keywords = []
            try:
                if suggestion.keywords:
                    if isinstance(suggestion.keywords, list):
                        keywords = suggestion.keywords
                    else:
                        keywords_str = str(suggestion.keywords)
                        if keywords_str.startswith('['):
                            keywords = json.loads(keywords_str)
                        else:
                            keywords = keywords_str.split(',')
            except Exception:
                # Skip keyword matching if parsing fails
                keywords = []
            
            # Keyword matching with scoring
            for keyword in keywords:
                if keyword and isinstance(keyword, str):
                    keyword_clean = keyword.strip().lower()
                    if keyword_clean in notes_lower:
                        current_score += 3  # Exact match
                    elif any(word in notes_lower for word in keyword_clean.split()):
                        current_score += 1  # Partial match
            
            # Contextual semantic matching based on emotion and scenarios
            habit_content = (suggestion.habit_name + " " + suggestion.habit_description).lower()
            
            # Universal contextual matching for all age groups
            context_score, context_detected = get_contextual_score(notes, suggestion.habit_name + " " + suggestion.habit_description, child.age)
            current_score += context_score
            
            # Additional emotion-specific contextual matching (reduced scores since universal function handles main logic)
            if emotion_rating == 1:  # Very Sad
                sad_triggers = ['cry', 'crying', 'tears', 'upset', 'scared', 'afraid', 'overwhelmed', 'clung', 'clingy']
                comfort_responses = ['comfort', 'hug', 'cuddle', 'calm', 'soothe', 'gentle', 'quiet', 'safe']
                
                if any(trigger in notes_lower for trigger in sad_triggers):
                    if any(response in habit_content for response in comfort_responses):
                        current_score += 1  # Reduced from 2
                        
            elif emotion_rating == 2:  # Sad
                social_issues = ['friends', 'friend', 'play', 'join', 'left out', 'excluded', 'skipping', 'game', 'lonely']
                social_solutions = ['social', 'friend', 'play', 'together', 'connect', 'include', 'group']
                
                if any(issue in notes_lower for issue in social_issues):
                    if any(solution in habit_content for solution in social_solutions):
                        current_score += 1  # Reduced from 2
                        
                # Missing family
                family_issues = ['miss', 'missed', 'daddy', 'mommy', 'parent', 'away', 'gone']
                connection_solutions = ['connection', 'call', 'photo', 'memory', 'love', 'family', 'talk']
                
                if any(issue in notes_lower for issue in family_issues):
                    if any(solution in habit_content for solution in connection_solutions):
                        current_score += 1  # Reduced from 2
                        
            elif emotion_rating == 4:  # Happy
                social_success = ['friend', 'new', 'made', 'class', 'school', 'played', 'together']
                celebrate_responses = ['celebrate', 'share', 'social', 'friend', 'success', 'proud']
                
                if any(success in notes_lower for success in social_success):
                    if any(response in habit_content for response in celebrate_responses):
                        current_score += 1  # Reduced from 2
                        
                # High energy/active
                energy_indicators = ['energy', 'excited', 'active', 'moving', 'running', 'dancing', 'giggled']
                active_responses = ['active', 'movement', 'dance', 'play', 'physical', 'exercise', 'run']
                
                if any(indicator in notes_lower for indicator in energy_indicators):
                    if any(response in habit_content for response in active_responses):
                        current_score += 1  # Reduced from 2
                        
            elif emotion_rating == 5:  # Very Happy
                achievement_words = ['gymnastics', 'sports', 'achievement', 'proud', 'accomplished', 'learned', 'cartwheel', 'gold star']
                celebration_responses = ['celebrate', 'achievement', 'proud', 'success', 'accomplishment', 'praise']
                
                if any(word in notes_lower for word in achievement_words):
                    if any(response in habit_content for response in celebration_responses):
                        current_score += 1  # Reduced from 2
                        
                # Creative/expressive joy
                creative_indicators = ['singing', 'music', 'dance', 'creative', 'song', 'baking', 'cookies', 'art']
                creative_responses = ['music', 'creative', 'art', 'sing', 'dance', 'express', 'make']
                
                if any(indicator in notes_lower for indicator in creative_indicators):
                    if any(response in habit_content for response in creative_responses):
                        current_score += 1  # Reduced from 2
        
        suggestion_scores[suggestion.id] = current_score
    
    # Apply variety scoring to reduce repetition
    variety_scores = apply_variety_scoring(suggestions, recent_suggestions, suggestion_scores)
    
    # Apply category rotation to encourage different types of suggestions
    final_scores = apply_category_rotation(suggestions, recent_suggestions, variety_scores)
    
    # Filter out habits with scores below minimum threshold
    qualified_habits = [habit for habit in suggestions if final_scores.get(habit.id, 0) >= config.MINIMUM_HABIT_SCORE]
    
    # If no habits meet the minimum score, lower the threshold
    if not qualified_habits:
        qualified_habits = [habit for habit in suggestions if final_scores.get(habit.id, 0) >= 0]
    
    # Select the best habit suggestion using variety management from qualified habits
    best_suggestion = select_with_variety(qualified_habits, final_scores, excluded_habit_ids, config.MINIMUM_HABIT_SCORE)
    
    # If no suggestion was selected, fall back to best scoring habit
    if not best_suggestion:
        # Find highest scoring habit
        best_score = max(final_scores.values()) if final_scores else 0
        for habit in suggestions:
            if final_scores.get(habit.id, 0) == best_score:
                best_suggestion = habit
                break
        
        # Ultimate fallback
        if not best_suggestion:
            best_suggestion = random.choice(suggestions)
    
    match_score = final_scores.get(best_suggestion.id, 0)
    match_type = "contextual_filtered" if qualified_habits != suggestions else "variety_based"
    
    # Track this suggestion in history for future variety management
    try:
        track_suggestion(
            db=db,
            child_id=child_id, 
            suggestion_type="habit",
            suggestion_id=best_suggestion.id,
            suggestion_text=f"{best_suggestion.habit_name}: {best_suggestion.habit_description}",
            emotion_rating=emotion_rating,
            notes=notes
        )
    except Exception as e:
        print(f"Failed to track habit suggestion: {e}")
    
    return {
        "habit_name": best_suggestion.habit_name,
        "habit_description": best_suggestion.habit_description,
        "age_group": age_group,
        "child_name": child.name,
        "child_age": child.age,
        "match_score": match_score,
        "match_type": match_type,
        "total_suggestions_available": len(suggestions),
        "excluded_suggestions": len(excluded_habit_ids),
        "category": getattr(best_suggestion, 'category', 'general')
    }

@router.post("/tips", response_model=schemas.AITip)
def create_ai_tip(
    tip: schemas.AITipCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    """Create a new AI tip (admin functionality)"""
    
    db_tip = models.AITip(**tip.model_dump())
    db.add(db_tip)
    db.commit()
    db.refresh(db_tip)
    return db_tip

@router.post("/habit-suggestions", response_model=schemas.HabitSuggestion)
def create_habit_suggestion(
    suggestion: schemas.HabitSuggestionCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    """Create a new habit suggestion (admin functionality)"""
    
    db_suggestion = models.HabitSuggestion(**suggestion.model_dump())
    db.add(db_suggestion)
    db.commit()
    db.refresh(db_suggestion)
    return db_suggestion

@router.get("/tips")
def list_ai_tips(
    age_group: str = None,
    emotion_rating: int = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_active_user)
):
    """List AI tips with optional filtering"""
    
    query = db.query(models.AITip)
    
    if age_group:
        query = query.filter(models.AITip.age_group == age_group)
    if emotion_rating:
        query = query.filter(models.AITip.emotion_rating == emotion_rating)
    
    tips = query.all()
    return tips 