from pydantic_settings import BaseSettings
from functools import lru_cache
import os
from typing import List

class Settings(BaseSettings):
    PROJECT_NAME: str = "BrightNest"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    
    # Environment
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    
    # Logging
    LOG_LEVEL: str = "INFO"
    
    # Database
    DATABASE_URL: str = "sqlite:///./brightnest.db"  # Default to SQLite for development
    
    # JWT
    SECRET_KEY: str = "your-secret-key-here"  # Change in production
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # CORS
    BACKEND_CORS_ORIGINS: List[str] = ["*"]
    
    # AI Configuration
    OPENAI_API_KEY: str = ""
    
    # Email Configuration
    SMTP_SERVER: str = ""
    SMTP_PORT: int = 587
    SMTP_USERNAME: str = ""
    SMTP_PASSWORD: str = ""
    FROM_EMAIL: str = "noreply@brightnest.com"
    
    # Rate Limiting
    RATE_LIMIT_REQUESTS_PER_MINUTE: int = 60
    
    # File Upload
    MAX_UPLOAD_SIZE_MB: int = 10
    ALLOWED_FILE_TYPES: List[str] = ["pdf", "jpg", "jpeg", "png"]
    
    # Production-specific
    SENTRY_DSN: str = ""
    REDIS_URL: str = ""
    
    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT.lower() == "production"
    
    @property
    def is_development(self) -> bool:
        return self.ENVIRONMENT.lower() == "development"
    
    class Config:
        env_file = ".env"
        case_sensitive = True
        
        @classmethod
        def customise_sources(cls, init_settings, env_settings, file_secret_settings):
            # Load environment-specific .env file if it exists
            env = os.getenv("ENVIRONMENT", "development")
            env_file = f".env.{env}"
            if os.path.exists(env_file):
                return (
                    init_settings,
                    env_settings,
                    cls._env_file_settings_source(env_file),
                    file_secret_settings,
                )
            return init_settings, env_settings, file_secret_settings

@lru_cache()
def get_settings():
    return Settings()

settings = get_settings() 

# AI Configuration
class AIConfig:
    """Configuration for AI-powered features"""
    
    # AI Service Settings
    ENABLED = True  # Set to False to disable all AI features
    PERSONALIZATION_MIN_NOTES_LENGTH = 15  # Minimum notes length to trigger tip personalization
    GENERATION_MIN_NOTES_LENGTH = 20  # Minimum notes length to trigger habit generation
    
    # Safety Settings
    MAX_RESPONSE_LENGTH = 150
    TIMEOUT_SECONDS = 10
    FORBIDDEN_WORDS = [
        "medication", "therapy", "doctor", "psychologist", 
        "diagnosis", "disorder", "prescription", "treatment"
    ]
    
    # Fallback Behavior
    LOW_MATCH_THRESHOLD = 2  # If match score below this, try AI generation
    ALWAYS_SHOW_ORIGINAL = True  # Include original curated content in response
    
    # Rate Limiting (to control costs)
    MAX_AI_CALLS_PER_USER_PER_HOUR = 50
    MAX_AI_CALLS_PER_USER_PER_DAY = 200

ai_config = AIConfig() 