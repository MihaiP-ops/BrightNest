"""
AI Configuration Settings for Nest Welcome Glow
==================================================

This file contains all the adjustable thresholds and settings for the AI-powered
features in your application. You can easily modify these values to fine-tune
how the AI behaves.

IMPORTANT: After making changes, restart your backend server for changes to take effect.
"""

class AIConfig:
    """
    🎯 AI Feature Control
    =====================
    Control when and how AI features are used.
    """
    
    # Master switch - set to False to disable ALL AI features
    ENABLED = True
    
    # API Configuration (you'll need to set OPENAI_API_KEY environment variable)
    OPENAI_MODEL = "gpt-3.5-turbo"  # Options: "gpt-3.5-turbo", "gpt-4", "gpt-4o-mini"
    
    """
    📝 TIP PERSONALIZATION SETTINGS
    ================================
    Controls when AI enhances your curated tips with personalized details.
    """
    
    # Minimum characters in parent notes to trigger tip personalization
    TIP_PERSONALIZATION_MIN_NOTES = 15  # Increase to be more selective
    
    # Only personalize tips if the parent provides contextual details
    TIP_REQUIRE_SITUATION_CONTEXT = True
    
    """
    🔄 SUGGESTION VARIETY SETTINGS
    ===============================
    Controls how varied and diverse the AI suggestions are.
    """
    
    # Prevent same suggestion from being shown within X days
    SUGGESTION_COOLDOWN_DAYS = 7  # Default: 7 days
    
    # How many recent suggestions to track per child
    SUGGESTION_HISTORY_LIMIT = 50  # Keep last 50 suggestions per child
    
    # Variety boost - randomly lower scores of recently used suggestions
    VARIETY_BOOST_ENABLED = True
    VARIETY_PENALTY_RECENT = 3  # Reduce score by 3 for recent suggestions
    VARIETY_PENALTY_VERY_RECENT = 5  # Reduce score by 5 for very recent (within 3 days)
    
    # Randomization settings
    ENABLE_RANDOMIZATION = True
    RANDOMIZATION_FACTOR = 0.3  # 30% chance to pick a random good suggestion instead of the best
    
    # Rotation settings - ensure different categories are used
    ENABLE_CATEGORY_ROTATION = True
    CATEGORY_ROTATION_THRESHOLD = 3  # If same category used 3+ times recently, prefer others
    
    # Relevance filtering
    MINIMUM_TIP_SCORE = 1  # Tips with score below this are excluded
    MINIMUM_HABIT_SCORE = 1  # Habits with score below this are excluded
    
    """
    🧠 HABIT GENERATION SETTINGS
    =============================
    Controls when AI generates new habit suggestions.
    """
    
    # Minimum characters in notes to trigger AI habit generation
    HABIT_GENERATION_MIN_NOTES = 20  # Increase to be more selective
    
    # Only generate habits if database match score is below this threshold
    HABIT_LOW_MATCH_THRESHOLD = 2  # Range: 0-5 (lower = more selective)
    
    # Whether to show AI-generated habits alongside your curated ones
    HABIT_SHOW_BOTH_AI_AND_CURATED = True
    
    """
    🛡️ SAFETY & QUALITY SETTINGS
    =============================
    Safety controls to ensure appropriate content.
    """
    
    # Maximum length of AI responses (prevents overly long suggestions)
    MAX_RESPONSE_LENGTH = 50000  # Characters - increased for more detailed tips
    
    # Timeout for AI API calls (prevents long waits)
    TIMEOUT_SECONDS = 10
    
    # Words that trigger safety filtering (AI won't suggest anything with these)
    FORBIDDEN_WORDS = [
        "medication", "therapy", "doctor", "psychologist", 
        "diagnosis", "disorder", "prescription", "treatment",
        "medical", "clinic", "hospital", "pills"
    ]
    
    # Age-inappropriate content filters
    FORBIDDEN_CONCEPTS = [
        "adult content", "violence", "scary", "frightening",
        "mature themes", "inappropriate behavior"
    ]
    
    """
    💰 COST CONTROL SETTINGS
    ========================
    Manage AI usage to control costs.
    """
    
    # Maximum AI calls per user per day (0 = unlimited)
    MAX_AI_CALLS_PER_USER_PER_DAY = 50
    
    # Minimum time between AI calls from same user (seconds)
    AI_CALL_COOLDOWN_SECONDS = 5
    
    # Cache AI responses to avoid repeat calls for same input
    ENABLE_RESPONSE_CACHING = True
    CACHE_DURATION_HOURS = 24
    
    """
    🎯 CONTEXT MATCHING THRESHOLDS
    ==============================
    Fine-tune how AI matches context and situations.
    """
    
    # Keyword matching scores
    KEYWORD_EXACT_MATCH_SCORE = 3    # Points for exact keyword match
    KEYWORD_PARTIAL_MATCH_SCORE = 1  # Points for partial keyword match
    
    # Contextual matching scores
    EMOTIONAL_CONTEXT_BONUS = 2      # Bonus for emotion-appropriate suggestions
    SCENARIO_MATCH_BONUS = 2         # Bonus for situation-specific matches
    AGE_APPROPRIATE_BONUS = 1        # Bonus for age-appropriate content
    
    """
    🎨 PERSONALIZATION DEPTH
    ========================
    Control how much AI personalizes responses.
    """
    
    # How specific should personalization be?
    PERSONALIZATION_STYLE = "gentle"  # Options: "minimal", "gentle", "detailed"
    
    # Include child's name in personalized responses?
    INCLUDE_CHILD_NAME = True
    
    # Include specific situation details from notes?
    INCLUDE_SITUATION_CONTEXT = True
    
    # Include emotional validation in responses?
    INCLUDE_EMOTIONAL_VALIDATION = True
    
    """
    🔄 FALLBACK BEHAVIOR
    ====================
    What happens when AI fails or is unavailable.
    """
    
    # Always show your original curated content even when AI is used
    ALWAYS_SHOW_ORIGINAL_CONTENT = True
    
    # What to do when AI fails
    FALLBACK_BEHAVIOR = "use_curated"  # Options: "use_curated", "show_error", "hide_feature"
    
    # Generic fallback messages when AI and database both fail
    FALLBACK_TIP = "Take a moment to breathe and connect with your child. Every feeling is valid."
    FALLBACK_HABIT = "Daily Check-in Chat: Spend 5 minutes talking about feelings each day."
    
    """
    📊 DEBUGGING & MONITORING
    =========================
    Settings for debugging and monitoring AI performance.
    """
    
    # Log all AI interactions for debugging?
    ENABLE_AI_LOGGING = True
    
    # Log detailed debugging information?
    ENABLE_DEBUG_LOGGING = False
    
    # Track AI response quality metrics?
    ENABLE_QUALITY_METRICS = True


# 🎛️ QUICK PRESETS
# ================
# Use these presets for common scenarios:

class AIPresets:
    """Pre-configured settings for different use cases."""
    
    @staticmethod
    def conservative():
        """Conservative AI usage - minimal AI, maximum safety."""
        return {
            'ENABLED': True,
            'TIP_PERSONALIZATION_MIN_NOTES': 30,
            'HABIT_GENERATION_MIN_NOTES': 40,
            'HABIT_LOW_MATCH_THRESHOLD': 1,
            'MAX_AI_CALLS_PER_USER_PER_DAY': 20,
            'PERSONALIZATION_STYLE': 'minimal'
        }
    
    @staticmethod
    def balanced():
        """Balanced AI usage - good mix of AI and curated content."""
        return {
            'ENABLED': True,
            'TIP_PERSONALIZATION_MIN_NOTES': 15,
            'HABIT_GENERATION_MIN_NOTES': 20,
            'HABIT_LOW_MATCH_THRESHOLD': 2,
            'MAX_AI_CALLS_PER_USER_PER_DAY': 50,
            'PERSONALIZATION_STYLE': 'gentle'
        }
    
    @staticmethod
    def ai_powered():
        """AI-powered mode - maximum AI personalization."""
        return {
            'ENABLED': True,
            'TIP_PERSONALIZATION_MIN_NOTES': 10,
            'HABIT_GENERATION_MIN_NOTES': 15,
            'HABIT_LOW_MATCH_THRESHOLD': 3,
            'MAX_AI_CALLS_PER_USER_PER_DAY': 100,
            'PERSONALIZATION_STYLE': 'detailed'
        }
    
    @staticmethod
    def curated_only():
        """Curated content only - AI disabled."""
        return {
            'ENABLED': False
        }


# 🚀 EASY CONFIGURATION
# ====================
# To change settings, modify this section:

# Choose your preset (uncomment one):
# ACTIVE_CONFIG = AIPresets.conservative()
ACTIVE_CONFIG = AIPresets.balanced()  # ← Currently active
# ACTIVE_CONFIG = AIPresets.ai_powered()
# ACTIVE_CONFIG = AIPresets.curated_only()

# Or customize individual settings:
# ACTIVE_CONFIG = {
#     'ENABLED': True,
#     'TIP_PERSONALIZATION_MIN_NOTES': 20,
#     'HABIT_GENERATION_MIN_NOTES': 25,
#     'HABIT_LOW_MATCH_THRESHOLD': 2,
#     'PERSONALIZATION_STYLE': 'gentle'
# }


def get_config():
    """Get the active AI configuration."""
    # Start with default values
    config = {}
    for attr in dir(AIConfig):
        if not attr.startswith('_'):
            config[attr] = getattr(AIConfig, attr)
    
    # Apply active configuration overrides
    if ACTIVE_CONFIG:
        config.update(ACTIVE_CONFIG)
    
    return type('Config', (), config)()


# Export the active configuration
config = get_config() 